using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2130_ValueVsReferenceTypes {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private int functionCallAmount = 0;
        private int correctAmount = 0;
        private float timer;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting for function calls...", ref timer, add: false);
        }

        private void Start() {
            FunctionTimer.Create(() => {
                if (functionCallAmount < 2) {
                    // Function was not called twice
                    ExerciseUtils.TimedMessage(textMeshUI, "Function was not called twice!", ref timer);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                if (correctAmount < 2) {
                    // Did not get both correct
                    return;
                }

                // All correct!
                FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
            }, .01f);
        }

        public void ExerciseValidate(int test, int validate) {
            ExerciseUtils.TimedMessage(textMeshUI, $"Exercise Validate: {test} == {validate}", ref timer);

            functionCallAmount++;

            if (test == validate) {
                correctAmount++;
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            } else {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
            }
        }

    }

}
