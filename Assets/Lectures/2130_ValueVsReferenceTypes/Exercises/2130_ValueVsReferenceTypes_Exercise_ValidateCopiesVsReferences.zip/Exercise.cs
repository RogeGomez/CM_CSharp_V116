using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2130_ValueVsReferenceTypes {


    public class Exercise : MonoBehaviour {

        // struct is a value type
        private struct MyStruct {

            public int score;

        }

        // class is a reference type
        private class MyClass {

            public int score;

        }


        private void Start() {
            MyStruct myStruct = new MyStruct();
            myStruct.score = 5;
            MyClass myClass = new MyClass();
            myClass.score = 5;

            ModifyScore(myStruct, myClass);

            // Validate the second parameter in these two functions, is it 5 or 12?
            ExerciseValidate(myStruct.score, 0);
            ExerciseValidate(myClass.score, 0);
        }

        private void ModifyScore(MyStruct myStruct, MyClass myClass) {
            myStruct.score = 12;
            myClass.score = 12;
        }




        private void ExerciseValidate(int test, int validate) {
            ExerciseSceneTester.Instance.ExerciseValidate(test, validate);
        }

    }

}
