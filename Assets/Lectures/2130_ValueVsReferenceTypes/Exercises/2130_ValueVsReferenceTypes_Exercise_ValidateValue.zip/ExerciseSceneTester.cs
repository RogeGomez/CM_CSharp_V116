using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2130_ValueVsReferenceTypes {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private int correctAmount = 0;
        private float timer;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting for function call...", ref timer, add: false);
        }

        private void Start() {
            FunctionTimer.Create(() => {
                if (correctAmount < 1) {
                    // Did not get correct
                    return;
                }

                // All correct!
                FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
            }, .01f);
        }

        public void ExerciseValidate(int test, int validate) {
            ExerciseUtils.TimedMessage(textMeshUI, $"Exercise Validate: {test} == {validate}", ref timer);

            if (test == validate) {
                correctAmount++;
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            } else {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
            }
        }

    }

}
