using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2130_ValueVsReferenceTypes {


    public class Exercise : MonoBehaviour {


        private void Start() {
            int[] intArray = new int[1];
            intArray[0] = 12;

            ModifyArray(intArray);

            // Validate the second parameter, is it 12 or 56?
            ExerciseValidate(intArray[0], 56);
        }

        private void ModifyArray(int[] intArray) {
            intArray[0] = 56;
        }




        private void ExerciseValidate(int test, int validate) {
            ExerciseSceneTester.Instance.ExerciseValidate(test, validate);
        }

    }

}
