using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2170_IsAsCasting {


    public class Exercise {



        // Write a function RefuelVehicle(); that takes in a Vehicle and calls .Refuel(); on that vehicle but only if it's a car.
        


        // Don't modify this code
        public class Car : Vehicle {
            public void Refuel() {
                Debug.Log("Car.Refuel()");
            }
        }

        public class Bycicle : Vehicle {
        }

        public class Vehicle {
        }

    }

}
