using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2170_IsAsCasting {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private string lastMessage;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for RefuelVehicle function...", ref timer, add: false);

            MethodInfo refuelVehicleMethodInfo = typeof(Exercise).GetMethod("RefuelVehicle", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (refuelVehicleMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'RefuelVehicle' function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found RefuelVehicle function...", ref timer);

            if (refuelVehicleMethodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "RefuelVehicle function does not have one parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (refuelVehicleMethodInfo.GetParameters()[0].ParameterType != typeof(Exercise.Vehicle)) {
                ExerciseUtils.TimedMessage(textMeshUI, "RefuelVehicle function parameter is NOT of type Vehicle!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "RefuelVehicle function correctly has one parameter of type Vehicle...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling RefuelVehicle with a Car...", ref timer);

            Exercise.Car car = new Exercise.Car();
            Exercise exercise = new Exercise();

            Application.logMessageReceived += Application_logMessageReceived;
            refuelVehicleMethodInfo.Invoke(exercise, new object[] { car });
            Application.logMessageReceived -= Application_logMessageReceived;

            if (lastMessage != "Car.Refuel()") {
                ExerciseUtils.TimedMessage(textMeshUI, "Car.Refuel() function was not called!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Car was correctly refueled...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling RefuelVehicle with a Bycicle...", ref timer);

            refuelVehicleMethodInfo.Invoke(exercise, new object[] { new Exercise.Bycicle() });


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        private void Application_logMessageReceived(string condition, string stackTrace, LogType type) {
            lastMessage = condition;
        }
    }

}
