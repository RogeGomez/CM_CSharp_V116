using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2170_IsAsCasting {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            Exercise.Player player = new Exercise.Player();
            Exercise.Enemy enemy = new Exercise.Enemy();
            Exercise.NPC npc = new Exercise.NPC();
            Exercise.Unit unit = new Exercise.Unit();

            ExerciseUtils.TimedMessage(textMeshUI, $"Calling GetUnitType() with Player", ref timer, add: false);
            ExerciseUtils.TimedMessage(textMeshUI, $"Output: {exercise.GetUnitType(player)}, expected IsPlayer", ref timer);

            if (exercise.GetUnitType(player) != Exercise.UnitType.IsPlayer) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Calling GetUnitType() with Enemy", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, $"Output: {exercise.GetUnitType(enemy)}, expected IsEnemy", ref timer);

            if (exercise.GetUnitType(enemy) != Exercise.UnitType.IsEnemy) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Calling GetUnitType() with NPC", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, $"Output: {exercise.GetUnitType(npc)}, expected IsNPC", ref timer);

            if (exercise.GetUnitType(npc) != Exercise.UnitType.IsNPC) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Calling GetUnitType() with Unit", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, $"Output: {exercise.GetUnitType(unit)}, expected IsUnit", ref timer);

            if (exercise.GetUnitType(unit) != Exercise.UnitType.IsUnit) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
