using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2170_IsAsCasting {


    public class Exercise : MonoBehaviour {



        // Edit this function to check the type of 'unit' and return the correct UnitType
        public UnitType GetUnitType(Unit unit) {
            if (unit is Player) {
                return UnitType.IsPlayer;
            }
            if (unit is Enemy) {
                return UnitType.IsEnemy;
            }
            if (unit is NPC) {
                return UnitType.IsNPC;
            }
            return UnitType.IsUnit;
        }


        public enum UnitType {
            IsUnit,
            IsPlayer,
            IsEnemy,
            IsNPC,
        }

        public class Unit { }

        public class Player : Unit { }

        public class Enemy : Unit { }

        public class NPC : Unit { }


    }

}
