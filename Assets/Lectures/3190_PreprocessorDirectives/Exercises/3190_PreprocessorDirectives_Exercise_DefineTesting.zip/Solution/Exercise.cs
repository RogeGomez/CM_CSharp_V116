#define TESTING

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3190_PreprocessorDirectives {


    public class Exercise {


        public void ExerciseValidate() {
#if TESTING
            ExerciseSceneTester.Instance.CompleteExercise();
#endif
        }

    }

}
