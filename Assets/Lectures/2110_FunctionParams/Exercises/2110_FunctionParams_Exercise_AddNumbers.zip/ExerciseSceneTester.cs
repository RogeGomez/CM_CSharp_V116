using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2110_FunctionParams {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for AddNumbers()...", ref timer, add: false);

            MethodInfo addNumbersMethodInfo = typeof(Exercise).GetMethod("AddNumbers", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (addNumbersMethodInfo == null) {
                // No function
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find a function named AddNumbers()!\n", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found function AddNumbers()!", ref timer);

            foreach (ParameterInfo parameterInfo in addNumbersMethodInfo.GetParameters()) {
                if (parameterInfo.GetCustomAttribute<ParamArrayAttribute>() == null) {
                    // Does not have params attribute
                    ExerciseUtils.TimedMessage(textMeshUI, "Function does not include a params parameter!\n", ref timer);
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                    return;
                } else {
                    // Does have params attribute
                    if (parameterInfo.ParameterType != typeof(int[])) {
                        // Parameter type is not int
                        ExerciseUtils.TimedMessage(textMeshUI, "Params parameter is not of type int[]!\n", ref timer);
                        ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                        return;
                    }
                }
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found params parameter", ref timer);

            if (addNumbersMethodInfo.ReturnType != typeof(int)) {
                // Does not return int
                ExerciseUtils.TimedMessage(textMeshUI, "Function does not return int!\n", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            // Has AddNumbers function, it has a params int[] and returns int
            ExerciseUtils.TimedMessage(textMeshUI, "Function is all correct!", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Trying to call it with values { 1, 2, 3 }", ref timer);

            int result = (int)addNumbersMethodInfo.Invoke(exercise, new object[] { new int[] { 1, 2, 3 } });

            ExerciseUtils.TimedMessage(textMeshUI, $"Result: {result}, expected {AddNumbers(1, 2, 3)}", ref timer);

            if (result != AddNumbers(1, 2, 3)) {
                // Does not match
                ExerciseUtils.TimedMessage(textMeshUI, "Result does not match!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "The function needs to return the total sum of all members.\n", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            // All correct!
            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        private int AddNumbers(params int[] intArray) {
            int result = 0;
            foreach (int i in intArray) {
                result += i;
            }
            return result;
        }

    }

}
