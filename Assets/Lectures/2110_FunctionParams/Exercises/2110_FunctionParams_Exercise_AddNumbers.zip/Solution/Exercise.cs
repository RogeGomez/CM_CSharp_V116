using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2110_FunctionParams {


    public class Exercise : MonoBehaviour {


        // Write function AddNumbers(); with an int params parameter

        private int AddNumbers(params int[] intArray) {
            int result = 0;
            foreach (int i in intArray) {
                result += i;
            }
            return result;
        }


    }

}
