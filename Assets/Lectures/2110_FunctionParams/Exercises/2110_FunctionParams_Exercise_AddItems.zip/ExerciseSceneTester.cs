using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2110_FunctionParams {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for AddItems()...", ref timer, add: false);

            MethodInfo addItemsMethodInfo = typeof(Exercise).GetMethod("AddItems", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (addItemsMethodInfo == null) {
                // No function
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find a function named AddItems()!\n", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found function AddItems()!", ref timer);

            foreach (ParameterInfo parameterInfo in addItemsMethodInfo.GetParameters()) {
                if (parameterInfo.GetCustomAttribute<ParamArrayAttribute>() == null) {
                    // Does not have params attribute
                    ExerciseUtils.TimedMessage(textMeshUI, "Function does not include a params parameter!\n", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                    return;
                } else {
                    // Does have params attribute
                    if (parameterInfo.ParameterType != typeof(Exercise.Item[])) {
                        // Parameter type is not Item
                        ExerciseUtils.TimedMessage(textMeshUI, "Params parameter is not of type Item[]!\n", ref timer, color: ExerciseUtils.COLOR_WARNING);
                        ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                        return;
                    }
                }
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found params parameter", ref timer);


            // Has AddItems function, it has a params int[] and returns int
            ExerciseUtils.TimedMessage(textMeshUI, "Function is all correct!", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Trying to call it with values { Item.Weapon }", ref timer);

            Exercise exercise = new Exercise();
            addItemsMethodInfo.Invoke(exercise, new object[] { new Exercise.Item[] { Exercise.Item.Weapon } });

            ExerciseUtils.TimedMessage(textMeshUI, "GetItemList()...", ref timer);

            foreach (Exercise.Item item in exercise.GetItemList()) {
                ExerciseUtils.TimedMessage(textMeshUI, item.ToString(), ref timer);
            }

            if (exercise.GetItemList().Count != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "ItemList does not have one item!\n", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "ItemList correctly has one Item...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Trying to call AddItems(Item.Weapon, Item.Gold, Item.Shield )", ref timer);

            addItemsMethodInfo.Invoke(exercise, new object[] { new Exercise.Item[] { Exercise.Item.Weapon, Exercise.Item.Gold, Exercise.Item.Shield } });

            ExerciseUtils.TimedMessage(textMeshUI, "GetItemList()...", ref timer);

            foreach (Exercise.Item item in exercise.GetItemList()) {
                ExerciseUtils.TimedMessage(textMeshUI, item.ToString(), ref timer);
            }

            if (exercise.GetItemList().Count != 4) {
                ExerciseUtils.TimedMessage(textMeshUI, "ItemList does not have 4 items!\n", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "ItemList correctly has 4 Items...", ref timer);


            // All correct!
            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
