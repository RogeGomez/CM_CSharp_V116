using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2110_FunctionParams {


    public class Exercise {

        public enum Item {
            Weapon,
            Shield,
            Gold
        }

        // Don't modify this field
        private List<Item> itemList = new List<Item>();


        // Write function AddItems(); with a params parameter of type Item to add multiple items to the itemList inventory
        


        // Don't modify this function
        public List<Item> GetItemList() {
            return itemList;
        }

    }

}
