using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2110_FunctionParams {


    public class Exercise {

        public enum Item {
            Weapon,
            Shield,
            Gold
        }


        // Write function AddItems(); with an int params parameter of type Item to add multiple items to the itemList inventory
        public void AddItems(List<Item> itemList, params Item[] itemArray) {
            itemList.AddRange(itemArray);
        }


    }

}
