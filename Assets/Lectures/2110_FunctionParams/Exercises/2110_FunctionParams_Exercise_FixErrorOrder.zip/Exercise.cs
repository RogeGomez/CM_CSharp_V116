using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/* COMPILATION BLOCKER
namespace CodeMonkey.CSharpCourse.L2110_FunctionParams {


    public class Exercise {

        public enum Item {
            Weapon,
            Shield,
            Gold
        }


        // Fix this error
        public void AddItems(params Item[] itemArray, List<Item> itemList) {
            itemList.AddRange(itemArray);
        }


    }

}
COMPILATION BLOCKER */