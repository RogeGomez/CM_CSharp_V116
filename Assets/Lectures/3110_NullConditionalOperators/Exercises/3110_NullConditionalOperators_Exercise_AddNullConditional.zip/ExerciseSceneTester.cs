using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3110_NullConditionalOperators {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private bool gotEvent;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("3110", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not read Exercise.cs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for ? in the code...", ref timer);

            if (!lectureText.Contains("?")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not ? in the code!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found ?...", ref timer);

            Exercise exercise = new Exercise();

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TakeDamage() with no listeners...", ref timer);

            try {
                exercise.TakeDamage();
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Fired an Exception!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "Correctly did not throw an exception...", ref timer);
            
            ExerciseUtils.TimedMessage(textMeshUI, "Attaching a listener...", ref timer);

            exercise.OnDamaged += Exercise_OnDamaged;

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TakeDamage()...", ref timer);

            exercise.TakeDamage();

            if (!gotEvent) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Event was not fired!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;

            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Event was correctly fired...", ref timer);
            

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        private void Exercise_OnDamaged(object sender, EventArgs e) {
            gotEvent = true;
        }

    }

}
