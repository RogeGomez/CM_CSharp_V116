using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3110_NullConditionalOperators {


    public class Exercise {


        public event EventHandler OnDamaged;


        public void TakeDamage() {
            // Use a Null conditional operator to ensure this line does not throw a NullReferenceException
            OnDamaged?.Invoke(this, EventArgs.Empty);
        }



    }



}