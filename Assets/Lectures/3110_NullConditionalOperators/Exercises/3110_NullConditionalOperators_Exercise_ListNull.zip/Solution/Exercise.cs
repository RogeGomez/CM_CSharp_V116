using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3110_NullConditionalOperators {


    public class Exercise {


        private List<Target> targetList;


        public void AttackFirstTarget() {
            // Use a Null conditional operator to ensure this line does not throw a NullReferenceException
            targetList?[0].Damage();
        }


        // Don't modify this code
        public void SetTargetList(List<Target> targetList) {
            this.targetList = targetList;
        }


        public class Target {

            public void Damage() {
                ExerciseSceneTester.Instance.TargetDamaged();
            }

        }

    }



}