using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3110_NullConditionalOperators {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private bool wasTargetDamaged;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("3110", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not read Exercise.cs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for ? in the code...", ref timer);

            if (!lectureText.Contains("?")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not ? in the code!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found ?...", ref timer);

            Exercise exercise = new Exercise();

            ExerciseUtils.TimedMessage(textMeshUI, "Calling AttackFirstTarget() with targetList null...", ref timer);

            try {
                exercise.AttackFirstTarget();
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Fired an Exception!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "Correctly did not throw an exception...", ref timer);
            
            ExerciseUtils.TimedMessage(textMeshUI, "Setting a valid targetList...", ref timer);

            Exercise.Target target = new Exercise.Target();
            exercise.SetTargetList(new List<Exercise.Target> { target });


            ExerciseUtils.TimedMessage(textMeshUI, "Calling AttackFirstTarget()...", ref timer);

            exercise.AttackFirstTarget();

            if (!wasTargetDamaged) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Target was not damaged!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;

            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Target was correctly damaged...", ref timer);
            

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void TargetDamaged() {
            wasTargetDamaged = true;
        }

    }

}
