using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3170_BitwiseOperations {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            Exercise exercise = new Exercise();

            ExerciseUtils.TimedMessage(textMeshUI, "Calling BitwiseAnd(3, 5)...", ref timer);
            int result = exercise.BitwiseAnd(3, 5);
            ExerciseUtils.TimedMessage(textMeshUI, $"Got {result}, expected: 1", ref timer);

            if (result != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "\n", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling BitwiseOr(3, 5)...", ref timer);
            result = exercise.BitwiseOr(3, 5);
            ExerciseUtils.TimedMessage(textMeshUI, $"Got {result}, expected: 7", ref timer);

            if (result != 7) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "\n", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "Calling BitwiseXor(3, 5)...", ref timer);
            result = exercise.BitwiseXor(3, 5);
            ExerciseUtils.TimedMessage(textMeshUI, $"Got {result}, expected: 6", ref timer);

            if (result != 6) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "\n", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "Calling BitwiseNot(3)...", ref timer);
            result = exercise.BitwiseNot(3);
            ExerciseUtils.TimedMessage(textMeshUI, $"Got {result}, expected: -4", ref timer);

            if (result != -4) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
