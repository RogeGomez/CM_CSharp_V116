using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3170_BitwiseOperations {


    public class Exercise {

        // Implement the functions to do bitwise operations and return the result.
        public int BitwiseAnd(int a, int b) {
            return a & b;
        }

        public int BitwiseOr(int a, int b) {
            return a | b;
        }

        public int BitwiseXor(int a, int b) {
            return a ^ b;
        }

        public int BitwiseNot(int a) {
            return ~a;
        }

    }

}
