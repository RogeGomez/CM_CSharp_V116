using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3050_typeof {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private Type exerciseValidateType;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestExercise()...", ref timer);

            new Exercise().TestExercise();

            if (exerciseValidateType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "ExerciseValidate() was not called!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (exerciseValidateType != typeof(Exercise.Player)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Received type does not match {typeof(Exercise.Player)}!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }



            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void ExerciseValidate(System.Type type) {
            exerciseValidateType = type;
            ExerciseUtils.TimedMessage(textMeshUI, "Got ExerciseValidate with " + exerciseValidateType, ref timer);
        }

    }

}
