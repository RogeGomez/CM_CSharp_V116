using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3050_typeof {


    public class Exercise {



        public void TestExercise(Player player) {
            // Call ExerciseValidate with the Player type using GetType()
            ExerciseValidate(player.GetType());
        }



        public void ExerciseValidate(System.Type type) {
            ExerciseSceneTester.Instance.ExerciseValidate(type);
        }

        public class Player {
            // ...
        }

    }



}