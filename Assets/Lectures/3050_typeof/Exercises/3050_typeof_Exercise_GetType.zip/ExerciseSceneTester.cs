using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3050_typeof {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private Type exerciseValidateType;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("3050", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not read Exercise.cs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Making sure code does not have typeof()...", ref timer);

            if (lectureText.Contains("typeof(")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Found typeof!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for GetType()...", ref timer);

            if (!lectureText.Contains("GetType()")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find GetType()!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found GetType()...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestExercise()...", ref timer);

            new Exercise().TestExercise(new Exercise.Player());

            if (exerciseValidateType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "ExerciseValidate() was not called!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (exerciseValidateType != typeof(Exercise.Player)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Received type does not match {typeof(Exercise.Player)}!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }



            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void ExerciseValidate(System.Type type) {
            exerciseValidateType = type;
            ExerciseUtils.TimedMessage(textMeshUI, "Got ExerciseValidate with " + exerciseValidateType, ref timer);
        }

    }

}
