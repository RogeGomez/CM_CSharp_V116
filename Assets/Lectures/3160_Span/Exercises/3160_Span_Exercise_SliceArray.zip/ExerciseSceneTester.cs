using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3160_Span {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            Exercise exercise = new Exercise();

            MethodInfo getSpanMethodInfo =
                typeof(Exercise).GetMethod("GetSpan", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (getSpanMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find GetSpan function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Found GetSpan function...", ref timer);

            if (getSpanMethodInfo.ReturnType != typeof(Span<int>)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"GetSpan function does not return Span<int>!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (getSpanMethodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, $"GetSpan function does not have 1 parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (getSpanMethodInfo.GetParameters()[0].ParameterType != typeof(int[])) {
                ExerciseUtils.TimedMessage(textMeshUI, $"GetSpan function does not have a int[] parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "GetSpan function correctly returns Span<int> and has int[] parameter...", ref timer);

            int[] intArray = new int[]{ 5, 45, 78, 56, 89, 10 };

            ExerciseUtils.TimedMessage(textMeshUI, "Calling GetSpan(new int[] { 5, 45, 78, 56, 89, 10 })...", ref timer);
            Span<int> intSpan = exercise.GetSpan(intArray);

            ExerciseUtils.TimedMessage(textMeshUI, $"Got Span with {intSpan.Length} elements, expected 4", ref timer);

            if (intSpan.Length != 4) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            MethodInfo fillSpanValuesMethodInfo =
                typeof(Exercise).GetMethod("FillSpanValues", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (fillSpanValuesMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find FillSpanValues function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Found FillSpanValues function...", ref timer);

            if (fillSpanValuesMethodInfo.GetParameters().Length != 2) {
                ExerciseUtils.TimedMessage(textMeshUI, $"FillSpanValues function does not have 2 parameters!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (fillSpanValuesMethodInfo.GetParameters()[0].ParameterType != typeof(Span<int>)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"GetSpan function does not have a Span<int> parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (fillSpanValuesMethodInfo.GetParameters()[1].ParameterType != typeof(int)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"GetSpan function does not have a second int parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "FillSpanValues function correctly has (Span<int>, int) parameters...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling FillSpanValues(intSpan, 56)", ref timer);
            exercise.FillSpanValues(intSpan, 56);

            ExerciseUtils.TimedMessage(textMeshUI, "Checking array...", ref timer);
            string arrayText = "";
            foreach (int number in intArray) {
                arrayText += number + ", ";
            }
            arrayText = arrayText.Substring(0, arrayText.Length - 2);
            ExerciseUtils.TimedMessage(textMeshUI, "Got { " + arrayText + " }", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Expected { 5, 56, 56, 56, 56, 10 }", ref timer);

            if (intArray[0] != 5 ||
                intArray[1] != 56 ||
                intArray[2] != 56 ||
                intArray[3] != 56 ||
                intArray[4] != 56 ||
                intArray[5] != 10) {

                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }
        delegate void MyDelegate(Span<int> span);

    }

}
