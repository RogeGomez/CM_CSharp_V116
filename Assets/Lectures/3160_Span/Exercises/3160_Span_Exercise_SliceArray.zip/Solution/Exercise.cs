using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3160_Span {


    public class Exercise {

        // Implement the GetSpan() function to return a span of the given array,
        // but only grab a slice that contains the elements in the middle, without the first and last element
        // Then implement the FillSpanValues to fill in the values of the span
        public Span<int> GetSpan(int[] intArray) {
            return new Span<int>(intArray, 1, intArray.Length - 2);
        }

        public void FillSpanValues(Span<int> intSpan, int value) {
            intSpan.Fill(value);
        }

    }

}
