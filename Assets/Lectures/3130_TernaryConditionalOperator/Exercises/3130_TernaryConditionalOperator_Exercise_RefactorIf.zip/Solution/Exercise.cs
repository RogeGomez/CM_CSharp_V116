using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3130_TernaryConditionalOperator {


    public class Exercise {



        public string GetNumberType(int number) {
            // Refactor this if-else to use a simple ternary conditional operator
            return number % 2 == 0 ? "Even" : "Odd";
        }


    }



}