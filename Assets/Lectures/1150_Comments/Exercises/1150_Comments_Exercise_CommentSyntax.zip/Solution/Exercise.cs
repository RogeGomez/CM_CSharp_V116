using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1150_Comments {


    public class Exercise : MonoBehaviour {


        // Single-line comment

        /*
         * Multi
         * line
         * Comment
         * */

    }

}
