using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1150_Comments {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private bool gotError;


        private void Awake() {
            Instance = this;
            gotError = false;

            textMeshUI.text = "Waiting...";

            FunctionTimer.Create(() => {
                if (gotError) {
                    textMeshUI.text = "The function was called!\n\n" + INCORRECT;
                } else {
                    textMeshUI.text = SUCCESS;
                    ExerciseCompletionTester.ExerciseCompleted();
                }
            }, .6f);
        }

        public void Error() {
            gotError = true;
        }

    }

}
