using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1150_Comments {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Press Play in Unity to test your code

            // Comment out this following line to make the code not run.
            // ExerciseSceneTester.Instance.Error();
        }

    }

}
