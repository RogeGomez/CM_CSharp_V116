using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1150_Comments {


    public class Exercise : MonoBehaviour {



        // This function checks if the player can jump, should be named "CanJump"
        private bool cjmp() {
            int n = 50; // This is how much energy the player has, should be named "energy"
            int nc = 20; // Energy cost required to jump, should be named "jumpEnergyCost"
            // Test if has enough energy to jump
            if (n > nc) {
                return true;
            }
            return false;
        }


    }

}
