using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1150_Comments {


    public class Exercise : MonoBehaviour {



        private bool CanJump() {
            int energy = 50;
            int jumpEnergyCost = 20;

            if (energy > jumpEnergyCost) {
                return true;
            }
            return false;
        }


    }

}
