using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1150_Comments {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Testing...", ref timer, add: false);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("1150", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not read Exercise.cs!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (lectureText.Contains("//")) {
                ExerciseUtils.TimedMessage(textMeshUI, "There's still comments in the code!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Correctly found no comments in the code...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for CanJump()", ref timer);

            MethodInfo methodInfo = typeof(Exercise).GetMethod("CanJump", BindingFlags.Public | BindingFlags.Instance | BindingFlags.NonPublic);

            if (methodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find a CanJump() function!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found CanJump() function...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }


    }

}
