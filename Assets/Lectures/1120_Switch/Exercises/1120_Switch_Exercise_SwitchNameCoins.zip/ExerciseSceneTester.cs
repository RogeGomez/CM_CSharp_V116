using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1120_Switch {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private int coinAmount;
        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {

            bool codeMonkeySuccess = false;
            bool ironManSuccess = false;

            coinAmount = 0;
            ExerciseUtils.TimedMessage(textMeshUI, "Testing case \"Code Monkey\"", ref timer, add: false);
            exercise.TestExercise("Code Monkey");
            ExerciseUtils.TimedMessage(textMeshUI, $"Coin Amount {coinAmount}, expected 5", ref timer);
            if (coinAmount == 5) {
                // Successful
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
                codeMonkeySuccess = true;
            } else {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }

            ExerciseUtils.TimedMessage(textMeshUI, "", ref timer);

            coinAmount = 0;
            ExerciseUtils.TimedMessage(textMeshUI, "Testing case \"Iron Man\"", ref timer);
            exercise.TestExercise("Iron Man");
            ExerciseUtils.TimedMessage(textMeshUI, $"Coin Amount {coinAmount}, expected 1", ref timer);
            if (coinAmount == 1) {
                // Successful
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
                ironManSuccess = true;
            } else {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }
            
            ExerciseUtils.TimedMessage(textMeshUI, "", ref timer);

            if (codeMonkeySuccess && ironManSuccess) {
                ExerciseCompletionTester.ExerciseCompleted();
            } else {
                ExerciseUtils.TimedMessage(textMeshUI, "Remember that switch is case sensitive!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "case \"code money\" is different from case \"Code Monkey\"!", ref timer, color: ExerciseUtils.COLOR_WARNING);
            }
        }

        public void Add1Coin() {
            coinAmount += 1;
        }

        public void Add5Coins() {
            coinAmount += 5;
        }


    }

}
