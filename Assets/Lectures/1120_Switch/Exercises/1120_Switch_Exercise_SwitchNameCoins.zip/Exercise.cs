using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1120_Switch {


    public class Exercise : MonoBehaviour {


        public void TestExercise(string playerName) {
            // Use the variable 'playerName' for your switch
            // Call the function Add5Coins(); if the playerName is "Code Monkey"
            // Call the function Add1Coin(); if the playerName is "Iron Man"


            // Press Play in Unity to test your code
        }

        // Don't modify this function
        private void Add5Coins() {
            ExerciseSceneTester.Instance.Add5Coins();
        }

        // Don't modify this function
        private void Add1Coin() {
            ExerciseSceneTester.Instance.Add1Coin();
        }

    }

}
