using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* COMPILATION BLOCKER
namespace CodeMonkey.CSharpCourse.L1120_Switch {


    public class Exercise : MonoBehaviour {


        public void TestExercise() {
            int age = 35;
            switch (age) {
                case 35:
                    break;
                case "56":
	                break;
                case 37.8:
                    break;
            }

            // Press Play in Unity to test your code
        }


    }

}
COMPILATION BLOCKER */