using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1120_Switch {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private bool gotDefault;
        private bool gotCodeMonkey;
        private bool gotIronMan;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Testing case \"Code Monkey\"", ref timer, add: false);
            ExerciseUtils.TimedMessage(textMeshUI, "Expecting ExerciseCodeMonkey()...", ref timer);

            exercise.TestExercise("Code Monkey");

            if (!gotCodeMonkey) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\nTesting case \"Iron Man\"", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Expecting ExerciseIronMan()...", ref timer);

            exercise.TestExercise("Iron Man");

            if (!gotIronMan) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\nTesting case with random string of characters", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Expecting ExerciseDefault()...", ref timer);

            exercise.TestExercise("asdf");

            if (!gotDefault) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void ExerciseDefault() {
            gotDefault = true;
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseDefault()", ref timer);
        }

        public void ExerciseCodeMonkey() {
            gotCodeMonkey = true;
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseCodeMonkey()", ref timer);
        }

        public void ExerciseIronMan() {
            gotIronMan = true;
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseIronMan()", ref timer);
        }

    }

}
