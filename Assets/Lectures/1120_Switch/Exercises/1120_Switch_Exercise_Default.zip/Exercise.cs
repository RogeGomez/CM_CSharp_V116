using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1120_Switch {


    public class Exercise : MonoBehaviour {


        public void TestExercise(string playerName) {
            // Modify the switch to call ExerciseDefault(); if none of the cases match
            switch (playerName) {
                case "Code Monkey":
                    ExerciseCodeMonkey();
                    break;
                case "Iron Man":
                    ExerciseIronMan();
                    break;
            }

            // Press Play in Unity to test your code
        }

        // Don't modify this function
        private void ExerciseDefault() {
            ExerciseSceneTester.Instance.ExerciseDefault();
        }

        private void ExerciseCodeMonkey() {
            ExerciseSceneTester.Instance.ExerciseCodeMonkey();
        }

        private void ExerciseIronMan() {
            ExerciseSceneTester.Instance.ExerciseIronMan();
        }


    }

}
