using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1120_Switch {


    public class Exercise : MonoBehaviour {


        public void TestExercise(string playerName) {
            switch (playerName) {
                case "Code Monkey":
                    // Player is named "Code Monkey";
                    ExerciseCodeMonkey();
                    break;
                case "Iron Man":
                    // Player is named "Iron Man";
                    ExerciseIronMan();
                    break;
            }

            // Press Play in Unity to test your code
        }


        // Don't modify these functions
        private void ExerciseCodeMonkey() {
        }

        private void ExerciseIronMan() {
        }
    }

}
