using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1120_Switch {


    public class Exercise : MonoBehaviour {


        // objectType will be tested with "Player" and "Enemy"
        public void TestExercise(string objectType) {
            switch (objectType) {
                default:
                    ExerciseDefault();
                    break;
                case "player":
                    ExercisePlayer();
                    break;
                case "3nemy":
                    ExerciseEnemy();
                    break;
            }

            // Press Play in Unity to test your code

        }


        // Don't modify this function
        private void ExerciseDefault() {
            ExerciseSceneTester.Instance.ExerciseDefault();
        }

        private void ExercisePlayer() {
            ExerciseSceneTester.Instance.ExercisePlayer();
        }

        private void ExerciseEnemy() {
            ExerciseSceneTester.Instance.ExerciseEnemy();
        }


    }

}
