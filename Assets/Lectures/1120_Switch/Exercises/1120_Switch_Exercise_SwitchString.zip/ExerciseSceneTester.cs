using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1120_Switch {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private bool gotDefault;
        private bool gotPlayer;
        private bool gotEnemy;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Testing case \"Player\"", ref timer, add: false);
            ExerciseUtils.TimedMessage(textMeshUI, "Expecting ExercisePlayer()...", ref timer);

            exercise.TestExercise("Player");

            if (!gotPlayer) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\nTesting case \"Enemy\"", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Expecting ExerciseEnemy()...", ref timer);

            exercise.TestExercise("Enemy");

            if (!gotEnemy) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void ExerciseDefault() {
            gotDefault = true;
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseDefault()", ref timer);
        }

        public void ExercisePlayer() {
            gotPlayer = true;
            ExerciseUtils.TimedMessage(textMeshUI, "ExercisePlayer()", ref timer);
        }

        public void ExerciseEnemy() {
            gotEnemy = true;
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseEnemy()", ref timer);
        }

    }

}
