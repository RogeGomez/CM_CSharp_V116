using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3080_default {


    public class Exercise {



        public void TestExercise() {
            // Use the default operator to assign the zero-equivalent to these variables
            int number = 56;
            bool isSuper = true;
            string name = "Code Monkey";

            ExerciseValidate(number, isSuper, name);
        }



        private void ExerciseValidate(int i, bool b, string s) {
            ExerciseSceneTester.Instance.ExerciseValidate(i, b, s);
        }


    }



}