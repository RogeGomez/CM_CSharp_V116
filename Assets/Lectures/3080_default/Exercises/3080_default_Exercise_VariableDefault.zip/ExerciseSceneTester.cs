using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;
using static UnityEngine.Rendering.DebugUI;

namespace CodeMonkey.CSharpCourse.L3080_default {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private int gotInt;
        private bool gotBool;
        private string gotString;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("3080", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not read Exercise.cs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for default in the code...", ref timer);

            if (!lectureText.Contains("default")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find default()!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found default()...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestExercise()...", ref timer);

            new Exercise().TestExercise();


            if (gotInt != 0 || 
                gotBool != false ||
                gotString != null) {
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void ExerciseValidate(int i, bool b, string s) {
            ExerciseUtils.TimedMessage(textMeshUI, "int: " + i + ", expected: " + 0, ref timer);
            if (i != 0) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }
            ExerciseUtils.TimedMessage(textMeshUI, "bool: " + b + ", expected: " + false, ref timer);
            if (b != false) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }
            ExerciseUtils.TimedMessage(textMeshUI, "string: " + (s ?? "null") + ", expected: " + "null", ref timer);
            if (s != null) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }

            gotInt = i;
            gotBool = b;
            gotString = s;
        }

    }

}
