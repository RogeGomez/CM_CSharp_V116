using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3080_default {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private string lastMessage;
        private bool gotIntCorrect;
        private bool gotBoolCorrect;
        private bool gotStringCorrect;
        private bool gotPlayerCorrect;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("3080", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not read Exercise.cs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for default in the code...", ref timer);

            if (!lectureText.Contains("default")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find default()!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found default()...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestExercise()...", ref timer);

            new Exercise().TestExercise();


            if (!gotIntCorrect ||
                !gotBoolCorrect ||
                !gotStringCorrect ||
                !gotPlayerCorrect) {
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void ValidateValue(int value, int test) {
            ExerciseUtils.TimedMessage(textMeshUI, "ValidateValue int: " + value + " == " + test, ref timer);
            if (value == test) {
                gotIntCorrect = true;
            } else {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }
        }

        public void ValidateValue(bool value, bool test) {
            ExerciseUtils.TimedMessage(textMeshUI, "ValidateValue bool: " + value + " == " + test, ref timer);
            if (value == test) {
                gotBoolCorrect = true;
            } else {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }
        }

        public void ValidateValue(string value, string test) {
            ExerciseUtils.TimedMessage(textMeshUI, "ValidateValue string: " + value + " == " + test, ref timer);
            if (value == test) {
                gotStringCorrect = true;
            } else {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }
        }

        public void ValidateValue(Exercise.Player value, Exercise.Player test) {
            ExerciseUtils.TimedMessage(textMeshUI, "ValidateValue Player: " + value + " == " + test, ref timer);
            if (value == test) {
                gotPlayerCorrect = true;
            } else {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }
        }

    }

}
