using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3080_default {


    public class Exercise {



        public void TestExercise() {
            // Write the second parameter of the functions to match what you think the left side will return
            ValidateValue(default(int), 0);
            ValidateValue(default(bool), false);
            ValidateValue(default(string), null);
            ValidateValue(default(Player), null);
        }



        private void ValidateValue(int value, int test) {
            ExerciseSceneTester.Instance.ValidateValue(value, test);
        }

        private void ValidateValue(bool value, bool test) {
            ExerciseSceneTester.Instance.ValidateValue(value, test);
        }

        private void ValidateValue(string value, string test) {
            ExerciseSceneTester.Instance.ValidateValue(value, test);
        }

        private void ValidateValue(Player value, Player test) {
            ExerciseSceneTester.Instance.ValidateValue(value, test);
        }


        public class Player {
        }

    }



}