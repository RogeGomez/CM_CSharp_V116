using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2040_Enums {


    public class Exercise {

        public enum TutorialStage {
            TutorialStage_1,
            TutorialStage_2,
            TutorialStage_3,
            TutorialStage_COMPLETED,
        }


        private TutorialStage tutorialStage;


        public void StartTutorial() {
            // Start the tutorial on stage _1
            tutorialStage = TutorialStage.TutorialStage_1;
        }

        public void GoToNextTutorialStage() {
            // Do the logic to go to the next tutorial, stay on the last stage
            if (tutorialStage == TutorialStage.TutorialStage_COMPLETED) {
                return;
            }

            tutorialStage++;
        }

        public TutorialStage GetTutorialStage() {
            return tutorialStage;
        }

    }

}