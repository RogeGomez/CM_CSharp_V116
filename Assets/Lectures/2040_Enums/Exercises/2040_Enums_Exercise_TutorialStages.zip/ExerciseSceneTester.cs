using System;
using CodeMonkey.CSharpCourse.Companion;
using CodeMonkey.CSharpCourse.Interactive;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using System.Reflection;
using CodeMonkey.Utils;

namespace CodeMonkey.CSharpCourse.L2040_Enums {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string LECTURE_CODE = "2040";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Starting Tutorial...", ref timer, add: false);

            Exercise exercise = new Exercise();
            exercise.StartTutorial();

            ExerciseUtils.TimedMessage(textMeshUI, "Current Tutorial: " + exercise.GetTutorialStage(), ref timer);

            if (exercise.GetTutorialStage() != Exercise.TutorialStage.TutorialStage_1) {
                ExerciseUtils.TimedMessage(textMeshUI, "It is not at TutorialStage_1!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            exercise.GoToNextTutorialStage();

            ExerciseUtils.TimedMessage(textMeshUI, "Going to next Tutorial...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, exercise.GetTutorialStage() + ", expected: TutorialStage_2...", ref timer);

            if (exercise.GetTutorialStage() != Exercise.TutorialStage.TutorialStage_2) {
                ExerciseUtils.TimedMessage(textMeshUI, "It is not at TutorialStage_2!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            exercise.GoToNextTutorialStage();

            ExerciseUtils.TimedMessage(textMeshUI, "Going to next Tutorial...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, exercise.GetTutorialStage() + ", expected: TutorialStage_3...", ref timer);

            if (exercise.GetTutorialStage() != Exercise.TutorialStage.TutorialStage_3) {
                ExerciseUtils.TimedMessage(textMeshUI, "It is not at TutorialStage_3!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            exercise.GoToNextTutorialStage();

            ExerciseUtils.TimedMessage(textMeshUI, "Going to next Tutorial...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, exercise.GetTutorialStage() + ", expected: TutorialStage_COMPLETED...", ref timer);

            if (exercise.GetTutorialStage() != Exercise.TutorialStage.TutorialStage_COMPLETED) {
                ExerciseUtils.TimedMessage(textMeshUI, "It is not at TutorialStage_COMPLETED!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            exercise.GoToNextTutorialStage();

            ExerciseUtils.TimedMessage(textMeshUI, "Going to next Tutorial, it should stay on COMPLETED...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, exercise.GetTutorialStage() + ", expected: TutorialStage_COMPLETED...", ref timer);

            if (exercise.GetTutorialStage() != Exercise.TutorialStage.TutorialStage_COMPLETED) {
                ExerciseUtils.TimedMessage(textMeshUI, "It is not at TutorialStage_COMPLETED!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
