using System;
using CodeMonkey.CSharpCourse.Companion;
using CodeMonkey.CSharpCourse.Interactive;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using System.Reflection;
using CodeMonkey.Utils;

namespace CodeMonkey.CSharpCourse.L2040_Enums {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string LECTURE_CODE = "2040";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private List<Exercise.Weapon> weaponList;


        private void Awake() {
            Instance = this;

            weaponList = new List<Exercise.Weapon>();
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);

            new Exercise();
            FunctionTimer.Create(() => {
                ExerciseUtils.TimedMessage(textMeshUI, "Checking Weapons...", ref timer);

                if (!weaponList.Contains(Exercise.Weapon.Sword)) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Did not get Weapon.Sword!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "Got Weapon.Sword...", ref timer);


                if (!weaponList.Contains(Exercise.Weapon.Pistol)) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Did not get Weapon.Pistol!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "Got Weapon.Pistol...", ref timer);



                if (!weaponList.Contains(Exercise.Weapon.RocketLauncher)) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Did not get Weapon.RocketLauncher!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "Got Weapon.RocketLauncher...", ref timer);

                ExerciseUtils.TimedMessage(textMeshUI, "Got all Weapons...", ref timer);

                if (!ExerciseUtils.TryGetLectureExerciseCSText(LECTURE_CODE, out string lectureText)) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Could not read code file!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                if (!lectureText.Contains("Enum.GetValues") && !lectureText.Contains("Enum.GetNames")) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Did not find Enum.GetValues(); or Enum.GetNames()!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "Did you manually call each Weapon instead of cycling through all values?", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                if (lectureText.Contains("Enum.GetValues")) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Correctly found Enum.GetValues();", ref timer);
                }

                if (lectureText.Contains("Enum.GetNames")) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Correctly found Enum.GetNames();", ref timer);
                }

                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
                FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
            }, .1f);
        }

        public void ExerciseEnumValue(Exercise.Weapon weapon) {
            weaponList.Add(weapon);
        }

    }

}
