using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2040_Enums {


    public class Exercise {

        public enum Weapon {
            Sword,
            Pistol,
            RocketLauncher,
        }

        public Exercise() {
            // Iterate through all the Enum values, call ExerciseEnumValue() for each value
            foreach (Weapon weapon in Enum.GetValues(typeof(Weapon))) {
                ExerciseEnumValue(weapon);
            }
        }

        private void ExerciseEnumValue(Weapon weapon) {
            ExerciseSceneTester.Instance.ExerciseEnumValue(weapon);
        }

    }

}