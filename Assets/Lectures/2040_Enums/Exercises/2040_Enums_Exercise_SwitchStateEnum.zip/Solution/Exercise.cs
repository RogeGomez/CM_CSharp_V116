using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2040_Enums {


    public class Exercise {

        public enum State {
            Idle,
            LookingForEnemy,
            MovingToEnemy,
            AttackingEnemy
        }

        public void HandleState(State state) {
            // Do a switch on the 'state' variable and run the correct function for each state
            switch (state) {
                case State.Idle:
                    HandleIdle();
                    break;
                case State.LookingForEnemy:
                    HandleLookingForEnemy();
                    break;
                case State.MovingToEnemy:
                    HandleMovingToEnemy();
                    break;
                case State.AttackingEnemy:
                    HandleAttackingEnemy();
                    break;
            }
        }


        // Don't modify these functions
        private void HandleIdle() {
            Debug.Log("HandleIdle");
        }

        private void HandleLookingForEnemy() {
            Debug.Log("HandleLookingForEnemy");
        }

        private void HandleMovingToEnemy() {
            Debug.Log("HandleMovingToEnemy");
        }

        private void HandleAttackingEnemy() {
            Debug.Log("HandleAttackingEnemy");
        }

    }

}