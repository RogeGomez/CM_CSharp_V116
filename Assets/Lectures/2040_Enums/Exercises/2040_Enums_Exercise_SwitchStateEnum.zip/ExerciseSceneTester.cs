using System;
using CodeMonkey.CSharpCourse.Companion;
using CodeMonkey.CSharpCourse.Interactive;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using System.Reflection;
using CodeMonkey.Utils;

namespace CodeMonkey.CSharpCourse.L2040_Enums {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string LECTURE_CODE = "2040";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private string lastLogMessage;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Testing HandleState(State.Idle)...", ref timer, add: false);

            Application.logMessageReceived += Application_logMessageReceived;

            Exercise exercise = new Exercise();
            exercise.HandleState(Exercise.State.Idle);

            if (lastLogMessage != "HandleIdle") {
                Application.logMessageReceived -= Application_logMessageReceived;
                ExerciseUtils.TimedMessage(textMeshUI, "HandleState() did NOT handle State.Idle", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "HandleState() correctly handled State.Idle", ref timer);




            exercise.HandleState(Exercise.State.LookingForEnemy);

            if (lastLogMessage != "HandleLookingForEnemy") {
                Application.logMessageReceived -= Application_logMessageReceived;
                ExerciseUtils.TimedMessage(textMeshUI, "HandleState() did NOT handle State.LookingForEnemy", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "HandleState() correctly handled State.LookingForEnemy", ref timer);




            exercise.HandleState(Exercise.State.MovingToEnemy);

            if (lastLogMessage != "HandleMovingToEnemy") {
                Application.logMessageReceived -= Application_logMessageReceived;
                ExerciseUtils.TimedMessage(textMeshUI, "HandleState() did NOT handle State.MovingToEnemy", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "HandleState() correctly handled State.MovingToEnemy", ref timer);




            exercise.HandleState(Exercise.State.AttackingEnemy);

            if (lastLogMessage != "HandleAttackingEnemy") {
                Application.logMessageReceived -= Application_logMessageReceived;
                ExerciseUtils.TimedMessage(textMeshUI, "HandleState() did NOT handle State.AttackingEnemy", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "HandleState() correctly handled State.AttackingEnemy", ref timer);





            ExerciseUtils.TimedMessage(textMeshUI, "HandleState() correctly handled all states!", ref timer);

            Application.logMessageReceived += Application_logMessageReceived;

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        private void Application_logMessageReceived(string condition, string stackTrace, LogType type) {
            lastLogMessage = condition;
        }
    }

}
