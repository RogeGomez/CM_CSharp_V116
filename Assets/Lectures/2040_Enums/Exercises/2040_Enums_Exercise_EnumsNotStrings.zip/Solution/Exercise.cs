using CodeMonkey.CSharpCourse.L2290_IntermediateProject;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2040_Enums {


    public class Exercise {

        public enum ObjectType {
            Player,
            Enemy,
            Barrel
        }

        // Refactor this code to work with an Enum type so we can avoid using strings as identifiers.
        public void HandleObject(ObjectType objectType) {
            switch (objectType) {
                case ObjectType.Player:
                    // Do something with Player
                    break;
                case ObjectType.Enemy:
                    // Do something with Enemy
                    break;
                case ObjectType.Barrel:
                    // Do something with Barrel
                    break;
            }
        }




    }

}
