using System;
using CodeMonkey.CSharpCourse.Companion;
using CodeMonkey.CSharpCourse.Interactive;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using System.Reflection;
using CodeMonkey.Utils;

namespace CodeMonkey.CSharpCourse.L2040_Enums {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string LECTURE_CODE = "2040";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for Enum...", ref timer);
            Type enumType = null;
            foreach (Type type in typeof(Exercise).GetNestedTypes(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)) {
                if (type.IsEnum) {
                    enumType = type;
                    break;
                }
            }

            if (enumType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find an Enum!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found Enum " + enumType.Name, ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Checking HandleObject function...", ref timer);

            MethodInfo methodInfo = typeof(Exercise).GetMethod("HandleObject", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (methodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Cannot find HandleObject() function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (methodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "HandleObject() function does not have 1 parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "Did you modify it!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (methodInfo.GetParameters()[0].ParameterType != enumType) {
                ExerciseUtils.TimedMessage(textMeshUI, "HandleObject() function does not have 1 parameter of the Enum type!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "HandleObject() function correctly has a parameter of the Enum type...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
