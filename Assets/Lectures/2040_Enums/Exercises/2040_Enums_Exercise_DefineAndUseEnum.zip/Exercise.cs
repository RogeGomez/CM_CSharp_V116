using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2040_Enums {


    public class Exercise : MonoBehaviour {


        // Refactor this code to return a properly named enum instead of magic ints

        public int GetNextPlayerAction() {
            if (enemy != null) {
                // Has enemy
                float attackDistance = 5f;
                if (distanceToEnemy < attackDistance) {
                    // Attack enemy
                    return 1;
                } else {
                    // Move towards enemy
                    return 2;
                }
            } else {
                // Has no enemy
                return 0;
            }
        }




        // Don't touch the code down here, it's used for testing

        private float distanceToEnemy;
        private Enemy enemy;

        public void SetEnemy(Enemy enemy) {
            this.enemy = enemy;
        }

        public void SetDistanceToEnemy(float distanceToEnemy) {
            this.distanceToEnemy = distanceToEnemy;
        }


        public class Enemy {
        }

    }

}
