using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2040_Enums {


    public class Exercise : MonoBehaviour {


        public enum PlayerAction {
            NoEnemy,
            AttackEnemy,
            MoveTowardsEnemy
        }

        public PlayerAction GetNextPlayerAction() {
            if (enemy != null) {
                // Has enemy
                float attackDistance = 5f;
                if (distanceToEnemy < attackDistance) {
                    // Attack enemy
                    return PlayerAction.AttackEnemy;
                } else {
                    // Move towards enemy
                    return PlayerAction.MoveTowardsEnemy;
                }
            } else {
                // Has no enemy
                return PlayerAction.NoEnemy;
            }
        }




        // Don't touch the code down here, it's used for testing

        private float distanceToEnemy;
        private Enemy enemy;

        public void SetEnemy(Enemy enemy) {
            this.enemy = enemy;
        }

        public void SetDistanceToEnemy(float distanceToEnemy) {
            this.distanceToEnemy = distanceToEnemy;
        }


        public class Enemy {
        }

    }

}
