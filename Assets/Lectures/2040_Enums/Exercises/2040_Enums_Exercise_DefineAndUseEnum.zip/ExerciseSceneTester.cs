using CodeMonkey.CSharpCourse.Interactive;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2040_Enums {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            float timer = .5f;

            ExerciseUtils.TimedMessage(textMeshUI, "Testing GetNextPlayerAction() function...", ref timer, add: false);

            ExerciseUtils.TimedMessage(textMeshUI, "Setting Enemy to null", ref timer);
            exercise.SetEnemy(null);

            ExerciseUtils.TimedMessage(textMeshUI, "GetNextPlayerAction() -> " + exercise.GetNextPlayerAction(), ref timer);

            exercise.SetEnemy(new Exercise.Enemy());
            exercise.SetDistanceToEnemy(10f);
            ExerciseUtils.TimedMessage(textMeshUI, "Setting Enemy", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Setting Distance to Enemy = 10f", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "GetNextPlayerAction() -> " + exercise.GetNextPlayerAction(), ref timer);

            exercise.SetDistanceToEnemy(1f);
            ExerciseUtils.TimedMessage(textMeshUI, "Setting Distance to Enemy = 1f", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "GetNextPlayerAction() -> " + exercise.GetNextPlayerAction(), ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "\n", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for Enum...", ref timer);

            bool foundEnum = false;
            foreach (Type type in typeof(Exercise).GetNestedTypes()) {
                if (type.IsEnum) {
                    // It's an enum!
                    ExerciseUtils.TimedMessage(textMeshUI, "Found enum " + type.Name + "!\n", ref timer);
                    foundEnum = true;
                    break;
                }
            }

            if (!foundEnum) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not find any Enum!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Testing GetNextPlayerAction() function return type...", ref timer);

            MethodInfo getNextPlayerActionMethodInfo = typeof(Exercise).GetMethod("GetNextPlayerAction");
            if (getNextPlayerActionMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find function GetNextPlayerAction()!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "Did you delete or rename it?", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (getNextPlayerActionMethodInfo.ReturnType.IsEnum) {
                ExerciseUtils.TimedMessage(textMeshUI, "Function is correctly returning an Enum!", ref timer);
            } else {
                ExerciseUtils.TimedMessage(textMeshUI, "Function is NOT returning an enum!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            ExerciseCompletionTester.ExerciseCompleted();
        }

    }

}
