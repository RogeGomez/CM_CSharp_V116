using System;
using CodeMonkey.CSharpCourse.Companion;
using CodeMonkey.CSharpCourse.Interactive;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using System.Reflection;
using CodeMonkey.Utils;

namespace CodeMonkey.CSharpCourse.L2040_Enums {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string LECTURE_CODE = "2040";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "...", ref timer, add: false);

            Exercise exercise = new Exercise();

            ExerciseUtils.TimedMessage(textMeshUI, "Calling GetPlayerActionEnum(\"Idle\")...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, exercise.GetPlayerActionEnum("Idle") + ", expected: Idle", ref timer);

            if (exercise.GetPlayerActionEnum("Idle") != Exercise.PlayerAction.Idle) {
                ExerciseUtils.TimedMessage(textMeshUI, "Does not match!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }



            ExerciseUtils.TimedMessage(textMeshUI, "Calling GetPlayerActionEnum(\"Patrolling\")...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, exercise.GetPlayerActionEnum("Patrolling") + ", expected: Patrolling", ref timer);

            if (exercise.GetPlayerActionEnum("Patrolling") != Exercise.PlayerAction.Patrolling) {
                ExerciseUtils.TimedMessage(textMeshUI, "Does not match!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }



            ExerciseUtils.TimedMessage(textMeshUI, "Calling GetPlayerActionEnum(\"AttackingEnemy\")...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, exercise.GetPlayerActionEnum("AttackingEnemy") + ", expected: AttackingEnemy", ref timer);

            if (exercise.GetPlayerActionEnum("AttackingEnemy") != Exercise.PlayerAction.AttackingEnemy) {
                ExerciseUtils.TimedMessage(textMeshUI, "Does not match!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }



            ExerciseUtils.TimedMessage(textMeshUI, "Calling GetPlayerActionEnum(\"Nothing\")...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, exercise.GetPlayerActionEnum("Nothing") + ", expected: Idle", ref timer);

            if (exercise.GetPlayerActionEnum("Nothing") != Exercise.PlayerAction.Idle) {
                ExerciseUtils.TimedMessage(textMeshUI, "Does not match!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
