using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2040_Enums {


    public class Exercise {

        public enum PlayerAction {
            Idle,
            Patrolling,
            AttackingEnemy,
        }


        public PlayerAction GetPlayerActionEnum(string playerActionString) {
            // Parse the playerActionString into an actual PlayerAction
            // Return PlayerAction.Idle if it does not match any value

            return PlayerAction.Idle;
        }

    }

}