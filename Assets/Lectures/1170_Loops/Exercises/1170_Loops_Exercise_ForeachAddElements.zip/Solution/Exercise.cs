using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1170_Loops {


    public class Exercise : MonoBehaviour {


        public int AddNumbers(int[] numberArray) {
            int result = 0;

            // Write a foreach loop that cycles through all elements of the array, adds them together and returns the result
            foreach (int number in numberArray) {
                result += number;
            }

            return result;
        }


    }

}
