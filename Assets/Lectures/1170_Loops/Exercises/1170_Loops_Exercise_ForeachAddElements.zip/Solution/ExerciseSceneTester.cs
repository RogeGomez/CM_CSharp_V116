using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1170_Loops {


    public class ExerciseSceneTester : MonoBehaviour {

        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
        }

        private void Start() {
            if (!ExerciseUtils.TryGetLectureExerciseCSText("1170", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not read Exercise.cs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for 'foreach' in the code...", ref timer, add: false);

            if (!lectureText.Contains("foreach")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find a 'foreach' in the code!", ref timer, color: ExerciseUtils.COLOR_WARNING);
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found a 'foreach' in the code...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for AddNumbers function...", ref timer);

            MethodInfo addNumbersMethodInfo = typeof(Exercise).GetMethod("AddNumbers", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (addNumbersMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Calling AddNumbers(new int[] { 1, 2, 3 })...", ref timer);
            int result = (int)addNumbersMethodInfo.Invoke(exercise, new object[] { new int[] { 1, 2, 3 } });
            ExerciseUtils.TimedMessage(textMeshUI, "Result: " + result + ", expected 6", ref timer);

            if (result != 6) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
