using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1170_Loops {


    public class ExerciseSceneTester : MonoBehaviour {

        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private List<string> logList;


        private void Awake() {
            Instance = this;

            logList = new List<string>();

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
        }

        private void Start() {
            if (!ExerciseUtils.TryGetLectureExerciseCSText("1170", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not read Exercise.cs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for 'for' in the code...", ref timer, add: false);

            if (!lectureText.Contains("for ") && !lectureText.Contains("for(")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find a 'for' in the code!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found a 'for' in the code...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for LogNames function...", ref timer);

            MethodInfo logNamesMethodInfo = typeof(Exercise).GetMethod("LogNames", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (logNamesMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Calling LogNames(new string[] { \"Code Monkey\", \"Iron Man\", \"Black Widow\" })...", ref timer);
            Application.logMessageReceived += Application_logMessageReceived;
            logNamesMethodInfo.Invoke(exercise, new object[] { new string[] { "Code Monkey", "Iron Man", "Black Widow" } });
            Application.logMessageReceived -= Application_logMessageReceived;

            if (!logList.Contains("Code Monkey")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not get log Code Monkey!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "Did you forget Debug.Log(name); inside the function?", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Log: Code Monkey", ref timer);

            if (!logList.Contains("Iron Man")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not get log Iron Man!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "Did you forget Debug.Log(name); inside the function?", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Log: Iron Man", ref timer);

            if (!logList.Contains("Black Widow")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not get log Black Widow!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "Did you forget Debug.Log(name); inside the function?", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Log: Black Widow", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        private void Application_logMessageReceived(string condition, string stackTrace, LogType type) {
            logList.Add(condition);
        }
    }

}
