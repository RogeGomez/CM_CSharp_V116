using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1170_Loops {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Write a while loop that runs 3 times, inside it call the Loop(); function
            // IMPORTANT: Be careful not to write an infinite loop! If you do, Unity will run forever and crash!

        }

        private void Loop() {
            ExerciseCompletionTester.Loop();
        }

    }

}