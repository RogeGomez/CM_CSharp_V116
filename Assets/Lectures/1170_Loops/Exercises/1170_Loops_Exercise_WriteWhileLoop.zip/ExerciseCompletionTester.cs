using CodeMonkey.CSharpCourse.Companion;
using CodeMonkey.CSharpCourse.Interactive;
using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1170_Loops {

    [InitializeOnLoad]
    public class ExerciseCompletionTester {


        static ExerciseCompletionTester() {
            CodeMonkeyCompanion.OnCompilationFinished += CodeMonkeyCompanion_OnCompilationFinished;
            CodeMonkeyCompanion.OnCompilerMessage += CodeMonkeyCompanion_OnCompilerMessage;
        }

        private static void CodeMonkeyCompanion_OnCompilerMessage(object sender, System.EventArgs e) {
            CodeMonkeyCompanion.HandleCompilerMessage((CompilerMessage)sender);
        }

        private static void CodeMonkeyCompanion_OnCompilationFinished(object sender, System.EventArgs e) {
            LectureSO lectureSO = LectureSO.GetLectureSO("1170");
            string exerciseFilename = lectureSO.GetLectureFolderPath() + "Exercises/Exercise.cs";

            if (File.Exists(exerciseFilename)) {
                string exerciseFileText = File.ReadAllText(exerciseFilename);
                if (exerciseFileText.Contains("while (true)")) {
                    CodeMonkeyCompanion.SendCompanionMessage(
                        CodeMonkeyCompanion.MessageType.Error,
                        "It seems you are making an infinite loop! If you run the code Unity will crash!"
                    );
                    return;
                }
            } else {
                // File does not exist, did you accidentally delete it?
            }
        }

        private static void ExerciseCompleted() {
            CodeMonkeyCompanion.SendCompanionMessage(
                CodeMonkeyCompanion.MessageType.Info,
                "Exercise Completed! Good job!"
            );
            CodeMonkeyInteractiveSO.SetState(CodeMonkeyInteractiveSO.GetActiveExerciseSO(), CodeMonkeyInteractiveSO.State.Completed);
        }


        private static int loopCounter = 0;

        public static void Loop() {
            loopCounter++;
            if (loopCounter == 1) {
                // First loop iteration, wait 100ms and check
                FunctionTimer.Create(() => {
                    if (loopCounter == 3) {
                        // Ran exactly 3 times, success!
                        ExerciseCompleted();
                        return;
                    }
                    if (loopCounter == 0) {
                        CodeMonkeyCompanion.SendCompanionMessage(
                            CodeMonkeyCompanion.MessageType.Warning,
                            "The Loop did not run, make sure you call the Loop() function inside the while!"
                        );
                        return;
                    }
                    if (loopCounter < 3) {
                        CodeMonkeyCompanion.SendCompanionMessage(
                            CodeMonkeyCompanion.MessageType.Warning,
                            "The Loop ran less than 3 times, is your iterator logic correct?"
                        );
                        return;
                    }
                    if (loopCounter > 3) {
                        CodeMonkeyCompanion.SendCompanionMessage(
                            CodeMonkeyCompanion.MessageType.Warning,
                            "The Loop ran more than 3 times, is your iterator logic correct?"
                        );
                        return;
                    }
                }, .1f, "ExerciseCompletionTester", true);
            }
        }

    }

}