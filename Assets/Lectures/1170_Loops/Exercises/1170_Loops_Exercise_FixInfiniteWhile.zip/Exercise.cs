using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1170_Loops {


    public class Exercise : MonoBehaviour {


        public void Start() {
            int safety = 0;

            // Fix this infinite while loop.
            // Keep it in the code, but make it never run.
            while (true) {
                Loop();


                // Don't modify the safety code! If you do Unity will crash with an infinite loop!
                safety++;
                if (safety >= 5) {
                    break;
                }
            }
        }

        private void Loop() {
            ExerciseSceneTester.Instance.Loop();
        }

    }

}
