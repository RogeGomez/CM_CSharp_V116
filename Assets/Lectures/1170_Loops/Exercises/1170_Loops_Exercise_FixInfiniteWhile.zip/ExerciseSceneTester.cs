using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1170_Loops {


    public class ExerciseSceneTester : MonoBehaviour {

        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private int loopCount;


        private void Awake() {
            Instance = this;

            loopCount = 0;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
        }

        private void Start() {
            if (!ExerciseUtils.TryGetLectureExerciseCSText("1170", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not read Exercise.cs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                return;
            }

            FunctionTimer.Create(() => {
                ExerciseUtils.TimedMessage(textMeshUI, "Looking for 'while' in the code...", ref timer);

                if (!lectureText.Contains("while ") && !lectureText.Contains("while(")) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Could not find a 'while' in the code!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "Found a 'while' in the code...", ref timer);

                ExerciseUtils.TimedMessage(textMeshUI, "Loop Count: " + loopCount + ", expected 0", ref timer);

                if (loopCount != 0) {
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
                FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
            }, .01f);
        }

        public void Loop() {
            ExerciseUtils.TimedMessage(textMeshUI, "Loop();", ref timer);
            loopCount++;
        }

    }

}
