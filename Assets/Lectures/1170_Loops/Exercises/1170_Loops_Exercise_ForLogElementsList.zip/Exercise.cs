using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1170_Loops {


    public class Exercise : MonoBehaviour {


        public void LogNames(List<string> nameList) {
            // Write a for loop that logs all the elements in a List with Debug.Log();

        }


    }

}
