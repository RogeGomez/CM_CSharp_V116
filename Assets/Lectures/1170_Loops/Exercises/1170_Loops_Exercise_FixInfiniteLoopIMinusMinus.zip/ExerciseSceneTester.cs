using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1170_Loops {


    public class ExerciseSceneTester : MonoBehaviour {

        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private int loopCount;


        private void Awake() {
            Instance = this;

            loopCount = 0;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
        }

        private void Start() {
            FunctionTimer.Create(() => {
                ExerciseUtils.TimedMessage(textMeshUI, "Loop count == " + loopCount + ", expected 3", ref timer);
                if (loopCount != 3) {
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
                FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
            }, 0.01f);
        }

        public void Loop() {
            ExerciseUtils.TimedMessage(textMeshUI, "Loop();", ref timer);
            loopCount++;
        }

    }

}
