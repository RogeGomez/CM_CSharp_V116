using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1170_Loops {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Fix this infinite loop.
            // Don't remove the safety code or Unity will crash!

            int safety = 0;

            for (int i = 0; i < 3; i++) {
                // This code should only run 3 times
                Loop();


                // Don't touch this safety code
                safety++;
                if (safety > 5) {
                    break;
                }
            }
        }


        private void Loop() {
            ExerciseSceneTester.Instance.Loop();
        }

    }

}
