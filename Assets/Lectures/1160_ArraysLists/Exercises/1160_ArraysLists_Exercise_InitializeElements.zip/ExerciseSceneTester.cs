using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1160_ArraysLists {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;

            textMeshUI.text = "Waiting...";
        }

        public void ExerciseValidate(int[] intArray) {
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseValidate(); called...", ref timer, add: false);
            ExerciseUtils.TimedMessage(textMeshUI, "Checking intArray...", ref timer);

            if (intArray == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "intArray is null!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "intArray exists...", ref timer);

            if (intArray.Length != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, "intArray Length incorrect! Should be 3 instead of " + intArray.Length, ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "intArray correctly has Length == 3...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, $"Testing intArray[0] == {intArray[0]}, expected 56", ref timer);

            if (intArray[0] != 56) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Testing intArray[1] == {intArray[1]}, expected 2", ref timer);

            if (intArray[1] != 2) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Testing intArray[2] == {intArray[2]}, expected 3", ref timer);

            if (intArray[2] != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
