using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1160_ArraysLists {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Modify the creation of the array to initialize it with the elements 1, 2, 3
            int[] intArray = null;

            // Then afterwards access the element on index 0 and set it to 56

            // Then call the function
            ExerciseValidate(intArray);
        }


        private void ExerciseValidate(int[] intArray) {
            ExerciseSceneTester.Instance.ExerciseValidate(intArray);
        }

    }

}
