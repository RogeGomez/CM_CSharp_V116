using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1160_ArraysLists {


    public class Exercise : MonoBehaviour {


        private void Start() {
            int[] ageArray = new int[3];
            ageArray[0] = 12;
            ageArray[1] = 35;
            ageArray[2] = 56;
            // Convert ageArray into this ageList
            List<int> ageList = null;

            List<string> nameList = new List<string>() {
                "Code Monkey",
                "Iron Man",
                "Black Widow",
                "Spider-Man",
                "Hulk"
            };
            // Convert nameList onto this nameArray
            string[] nameArray = null;


            // Call ExerciseValidate
            ExerciseValidate(ageList, nameArray);
        }


        private void ExerciseValidate(List<int> ageList, string[] nameArray) {
            ExerciseSceneTester.Instance.ExerciseValidate(ageList, nameArray);
        }

    }

}
