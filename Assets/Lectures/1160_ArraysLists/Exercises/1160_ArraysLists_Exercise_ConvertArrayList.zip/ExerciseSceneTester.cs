using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1160_ArraysLists {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;

            textMeshUI.text = "Waiting...";
        }

        public void ExerciseValidate(List<int> ageList, string[] nameArray) {
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseValidate(); called...", ref timer, add: false);

            ExerciseUtils.TimedMessage(textMeshUI, $"Checking ageList...", ref timer);

            if (ageList == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "ageList is null!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "ageList is correctly set...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, $"Checking nameArray...", ref timer);

            if (nameArray == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "nameArray is null!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "nameArray is correctly set...", ref timer);




            ExerciseUtils.TimedMessage(textMeshUI, $"ageList.Count == {ageList.Count}, expected 3...", ref timer);

            if (ageList.Count != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, $"nameArray.Length == {nameArray.Length}, expected 5...", ref timer);

            if (nameArray.Length != 5) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            if (!ExerciseUtils.TryGetLectureExerciseCSText("1160", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Cannot read Exercise.cs!", ref timer);
                return;
            }

            if (!lectureText.Contains("new List<int>(ageArray);") && !lectureText.Contains("ageArray.ToList();")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find new List<int>(ageArray); or ageArray.ToList()!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (lectureText.Contains("new List<int>(ageArray);")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Found new List<int>(ageArray);...", ref timer);
            }

            if (lectureText.Contains("ageArray.ToList();")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Found ageArray.ToList();...", ref timer);
            }


            if (!lectureText.Contains("nameList.ToArray();")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find nameList.ToArray();!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found nameList.ToArray();...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
