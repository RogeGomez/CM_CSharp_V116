using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1160_ArraysLists {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Create a List of strings

            // Then use the list add function to add the elements "Code Monkey" and "Iron Man" to the list

            // Then remove the element "Iron Man"

            // And call ExerciseValidate(list);

        }


        private void ExerciseValidate(List<string> stringList) {
            ExerciseSceneTester.Instance.ExerciseValidate(stringList);
        }

    }

}
