using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1160_ArraysLists {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;

            textMeshUI.text = "Waiting...";
        }

        public void ExerciseValidate(List<string> stringList) {
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseValidate(); called...", ref timer, add: false);
            ExerciseUtils.TimedMessage(textMeshUI, "Checking stringList...", ref timer);

            if (stringList == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "stringList is null!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "stringList exists...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, $"Testing stringList[0] == {stringList[0]}, expected \"Code Monkey\"", ref timer);

            if (stringList[0] != "Code Monkey") {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Analyzing code to see if \"Iron Man\" was added...", ref timer);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("1160", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Cannot read Exercise.cs!", ref timer);
                return;
            }

            if (!lectureText.Contains(".Add(\"Iron Man\"")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find .Add(\"Iron Man\"); in the code!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Iron Man was indeed added...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, $"Analyzing code to see if \"Iron Man\" was removed...", ref timer);

            if (!lectureText.Contains(".Remove(\"Iron Man\"")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find .Remove(\"Iron Man\"); in the code!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Iron Man was indeed removed...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, $"Testing stringList.Count == {1}, expected 1", ref timer);

            if (stringList.Count != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "stringList Length incorrect! Should be 1 instead of " + stringList.Count, ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "stringList correctly has Length == 1...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
