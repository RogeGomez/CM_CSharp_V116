using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1160_ArraysLists {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Create a List of strings
            List<string> nameList = new List<string>();

            // Then use the list add function to add the elements "Code Monkey" and "Iron Man" to the list
            nameList.Add("Code Monkey");
            nameList.Add("Iron Man");

            // Then remove the element "Iron Man"
            nameList.Remove("Iron Man");

            // And call ExerciseValidate(list);
            ExerciseValidate(nameList);
        }


        private void ExerciseValidate(List<string> stringList) {
            ExerciseSceneTester.Instance.ExerciseValidate(stringList);
        }

    }

}
