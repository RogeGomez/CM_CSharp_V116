using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1160_ArraysLists {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Define and create an Array of ints and a List of strings


            // Press Play in Unity to test your code


            // Uncomment the following line and call the Result() function with the correct arguments
            //ExerciseSceneTester.Instance.Result(intArray, stringList);
        }

    }

}
