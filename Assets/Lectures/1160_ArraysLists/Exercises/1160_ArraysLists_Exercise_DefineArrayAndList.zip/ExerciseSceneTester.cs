using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1160_ArraysLists {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;

            textMeshUI.text = "Waiting...";
        }

        public void Result(int[] intArray, List<string> stringList) {
            ExerciseUtils.TimedMessage(textMeshUI, "Result(); called...", ref timer, add: false);
            ExerciseUtils.TimedMessage(textMeshUI, "Checking intArray...", ref timer);

            if (intArray == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "intArray is null!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "intArray is correctly created...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Checking stringList...", ref timer);

            if (stringList == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "stringList is null!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "stringList is correctly created...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "Checking if both have at least one element...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, $"intArray.Length = {intArray.Length}, expected >= 1", ref timer);

            if (intArray.Length <= 0) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"stringList.Count = {stringList.Count}, expected >= 1", ref timer);

            if (stringList.Count <= 0) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
