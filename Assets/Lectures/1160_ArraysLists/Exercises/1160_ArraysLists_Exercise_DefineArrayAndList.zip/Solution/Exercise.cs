using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1160_ArraysLists {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Define and create an Array of ints and a List of strings
            int[] intArray = new int[] { 1, 2, 3 };
            List<string> stringList = new List<string>() { "1", "2", "3" };

            // Press Play in Unity to test your code


            // Uncomment the following line and call the Result() function with the correct arguments
            ExerciseSceneTester.Instance.Result(intArray, stringList);
        }

    }

}
