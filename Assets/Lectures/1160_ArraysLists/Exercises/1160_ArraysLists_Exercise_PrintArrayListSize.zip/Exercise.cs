using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1160_ArraysLists {


    public class Exercise : MonoBehaviour {


        private void Start() {
            int[] ageArray = new int[3];
            ageArray[0] = 12;
            ageArray[1] = 35;
            ageArray[2] = 56;


            List<string> nameList = new List<string>() {
                "Code Monkey",
                "Iron Man",
                "Black Widow",
                "Spider-Man",
                "Hulk"
            };


            // Call ExerciseValidate and pass in the size of each collection

        }


        private void ExerciseValidate(int arraySize, int listSize) {
            ExerciseSceneTester.Instance.ExerciseValidate(arraySize, listSize);
        }

    }

}
