using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1160_ArraysLists {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;

            textMeshUI.text = "Waiting...";
        }

        public void ExerciseValidate(int arraySize, int listSize) {
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseValidate(); called...", ref timer, add: false);
            ExerciseUtils.TimedMessage(textMeshUI, $"arraySize == {arraySize}, expected 3...", ref timer);

            if (arraySize != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"listSize == {listSize}, expected 5...", ref timer);

            if (listSize != 5) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            if (!ExerciseUtils.TryGetLectureExerciseCSText("1160", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Cannot read Exercise.cs!", ref timer);
                return;
            }

            if (!lectureText.Contains(".Length")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find array.Length!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found array.Length...", ref timer);


            if (!lectureText.Contains(".Count")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find list.Count!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found list.Count...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
