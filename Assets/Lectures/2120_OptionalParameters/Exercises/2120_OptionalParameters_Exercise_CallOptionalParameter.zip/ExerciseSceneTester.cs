using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2120_OptionalParameters {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting for function call...", ref timer, add: false);
        }

        public void SetupPlayer(Vector3 playerPosition = default, int playerHealth = 0, string playerName = null) {
            ExerciseUtils.TimedMessage(textMeshUI, "SetupPlayer() has been called...", ref timer);

            if (playerPosition != default) {
                ExerciseUtils.TimedMessage(textMeshUI, "playerPosition was set but should be default!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "playerPosition was correctly left as default", ref timer);

            if (playerHealth == 0) {
                ExerciseUtils.TimedMessage(textMeshUI, "playerHealth was NOT set!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "playerHealth was correctly set!", ref timer);

            if (playerName == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "playerName was NOT set!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "playerName was correctly set!", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "All correct!", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);

            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
