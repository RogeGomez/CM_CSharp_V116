using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2120_OptionalParameters {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Call the SetupPlayer(); function here
            SetupPlayer(playerHealth: 12, playerName: "asdf");
        }




        public void SetupPlayer(Vector3 playerPosition = default, int playerHealth = 0, string playerName = null) {
            ExerciseSceneTester.Instance.SetupPlayer(playerPosition, playerHealth, playerName);
        }


    }

}
