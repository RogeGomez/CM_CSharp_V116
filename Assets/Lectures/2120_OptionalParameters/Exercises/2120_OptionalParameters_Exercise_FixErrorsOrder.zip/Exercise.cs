using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* COMPILATION BLOCKER
namespace CodeMonkey.CSharpCourse.L2120_OptionalParameters {


    public class Exercise : MonoBehaviour {


        // Fix this error
        public void SetupPlayer(int playerHealth = 0, string playerName) {
            // ...
        }


    }

}
COMPILATION BLOCKER */