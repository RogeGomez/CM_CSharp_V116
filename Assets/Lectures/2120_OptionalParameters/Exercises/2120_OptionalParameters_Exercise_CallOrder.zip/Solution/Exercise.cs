using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2120_OptionalParameters {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Call the SetupPlayer(); function here, but pass in first the playerName and secondly the playerHealth
            SetupPlayer(playerName: "Code Monkey", playerHealth: 12);
        }




        public void SetupPlayer(int playerHealth, string playerName) {
            ExerciseSceneTester.Instance.SetupPlayer(playerHealth, playerName);
        }


    }

}
