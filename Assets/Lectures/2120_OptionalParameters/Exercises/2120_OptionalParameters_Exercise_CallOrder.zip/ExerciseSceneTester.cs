using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2120_OptionalParameters {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting for function call...", ref timer, add: false);
        }

        public void SetupPlayer(int playerHealth, string playerName) {
            ExerciseUtils.TimedMessage(textMeshUI, "SetupPlayer() has been called...", ref timer);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("2120", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not read code file!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!lectureText.Replace(" ", "").Contains("playerName:")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find playerName: parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found playerName:", ref timer);

            if (!lectureText.Replace(" ", "").Contains("playerHealth:")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find playerHealth: parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found playerHealth:", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
