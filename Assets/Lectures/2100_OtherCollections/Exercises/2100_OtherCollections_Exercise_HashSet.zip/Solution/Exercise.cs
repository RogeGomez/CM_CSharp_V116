using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2100_OtherCollections {


    public class Exercise {


        public HashSet<string> GetHashSet() {
            // Create a HashSet and add the strings "Code Monkey", "Iron Man" and "Black Widow"
            HashSet<string> nameHashSet = new HashSet<string>();

            nameHashSet.Add("Code Monkey");
            nameHashSet.Add("Iron Man");
            nameHashSet.Add("Black Widow");

            return nameHashSet;
        }


    }

}
