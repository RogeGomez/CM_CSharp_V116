using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2100_OtherCollections {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Calling GetHashSet()...", ref timer, add: false);

            Exercise exercise = new Exercise();
            HashSet<string> nameHashSet = exercise.GetHashSet();

            if (nameHashSet == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "HashSet is null!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!nameHashSet.Contains("Code Monkey")) {
                ExerciseUtils.TimedMessage(textMeshUI, "HashSet does not have Code Monkey!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "HashSet has Code Monkey\n", ref timer);


            if (!nameHashSet.Contains("Iron Man")) {
                ExerciseUtils.TimedMessage(textMeshUI, "HashSet does not have Iron Man!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "HashSet has Iron Man\n", ref timer);


            if (!nameHashSet.Contains("Black Widow")) {
                ExerciseUtils.TimedMessage(textMeshUI, "HashSet does not have Black Widow!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "HashSet has Black Widow\n", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
