using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2100_OtherCollections {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Create a Stack and populate it with strings


        }


        private void ExerciseValidate(Stack<string> nameStack) {
            ExerciseSceneTester.Instance.ExerciseValidate(nameStack);
        }

    }

}
