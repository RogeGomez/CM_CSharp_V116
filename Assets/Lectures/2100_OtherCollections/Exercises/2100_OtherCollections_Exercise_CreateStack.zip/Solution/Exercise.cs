using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2100_OtherCollections {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Create a Stack and populate it with strings
            Stack<string> nameStack = new Stack<string>();
            nameStack.Push("Code Monkey");
            nameStack.Push("Iron Man");
            nameStack.Push("Black Widow");
            ExerciseValidate(nameStack);

        }


        private void ExerciseValidate(Stack<string> nameStack) {
            ExerciseSceneTester.Instance.ExerciseValidate(nameStack);
        }

    }

}
