using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2100_OtherCollections {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
        }

        public void ExerciseValidate(Stack<string> nameStack) {
            ExerciseUtils.TimedMessage(textMeshUI, $"Checking stack count = {nameStack.Count}, expected 3\n", ref timer);

            if (nameStack.Count != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            string name = nameStack.Pop();
            ExerciseUtils.TimedMessage(textMeshUI, $"Stack.Pop() = {name}, expected \"Black Widow\"\n", ref timer);
            if (name != "Black Widow") {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            name = nameStack.Pop();
            ExerciseUtils.TimedMessage(textMeshUI, $"Stack.Pop() = {name}, expected \"Iron Man\"\n", ref timer);
            if (name != "Iron Man") {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            name = nameStack.Pop();
            ExerciseUtils.TimedMessage(textMeshUI, $"Stack.Pop() = {name}, expected \"Code Monkey\"\n", ref timer);
            if (name != "Code Monkey") {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
