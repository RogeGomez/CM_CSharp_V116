using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2100_OtherCollections {


    public class Exercise {


        public Queue<string> GetNameQueue() {
            // Create a Queue and add the strings "Code Monkey", "Iron Man" and "Black Widow" in order
            Queue<string> nameQueue = new Queue<string>();

            nameQueue.Enqueue("Code Monkey");
            nameQueue.Enqueue("Iron Man");
            nameQueue.Enqueue("Black Widow");

            return nameQueue;
        }


    }

}
