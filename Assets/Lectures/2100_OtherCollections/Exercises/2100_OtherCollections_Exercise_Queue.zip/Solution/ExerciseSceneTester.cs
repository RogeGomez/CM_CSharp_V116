using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2100_OtherCollections {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Calling GetNameQueue()...", ref timer, add: false);

            Exercise exercise = new Exercise();
            Queue<string> nameQueue = exercise.GetNameQueue();

            ExerciseUtils.TimedMessage(textMeshUI, "Dequeuing element...", ref timer);
            string name = nameQueue.Dequeue();
            ExerciseUtils.TimedMessage(textMeshUI, "Got: " + name + ", expected: Code Monkey\n", ref timer);

            if (name != "Code Monkey") {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "Dequeuing element...", ref timer);
            name = nameQueue.Dequeue();
            ExerciseUtils.TimedMessage(textMeshUI, "Got: " + name + ", expected: Iron Man\n", ref timer);

            if (name != "Iron Man") {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "Dequeuing element...", ref timer);
            name = nameQueue.Dequeue();
            ExerciseUtils.TimedMessage(textMeshUI, "Got: " + name + ", expected: Black Widow\n", ref timer);

            if (name != "Black Widow") {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
