using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2250_IEnumerable {


    public class Exercise : MonoBehaviour {


        private PlayerStats playerStats;


        private void Start() {
            playerStats = new PlayerStats();
            playerStats.wis = new Stat("Wisdom", 12);
            playerStats.dex = new Stat("Dexterity", 33);
            playerStats.str = new Stat("Strength", 56);

            // Fix the error
            foreach (Stat stat in playerStats) {
                ExerciseValidate(stat.ToString());
            }
        }

        private void ExerciseValidate(string msg) {
            ExerciseSceneTester.Instance.ExerciseValidate(msg);
        }



        // Implement IEnumerable in this custom type so it can work with 'foreach'
        public class PlayerStats {

            public Stat wis;
            public Stat str;
            public Stat dex;

        }


        public class Stat {

            public string name;
            public int value;

            public Stat(string name, int value) {
                this.name = name;
                this.value = value;
            }

            public override string ToString() {
                return name + ": " + value;
            }
        }





    }

}
