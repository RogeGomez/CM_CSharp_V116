using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3200_RefOutIn {


    public class Exercise {

        // Define a function named DoSomething with a ref, out and in parameters,
        // inside that function call ExerciseValidate();
        public void DoSomething(ref int r, out int o, in int i) {
            o = 12;
            ExerciseValidate();
        }

        public Exercise() {
            // Call your function from here
            int r = 0;
            int i = 0;
            DoSomething(ref r, out int o, i);
        }

        private void ExerciseValidate() {
            ExerciseSceneTester.Instance.ExerciseValidate();
        }

    }

}
