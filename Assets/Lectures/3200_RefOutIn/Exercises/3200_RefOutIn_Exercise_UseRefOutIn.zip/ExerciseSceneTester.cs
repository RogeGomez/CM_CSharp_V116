using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3200_RefOutIn {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            MethodInfo doSomethingMethodInfo =
                typeof(Exercise).GetMethod("DoSomething", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for DoSomething function...", ref timer);

            if (doSomethingMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find DoSomething function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Found DoSomething function...", ref timer);

            if (doSomethingMethodInfo.GetParameters().Length != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Function does not have 3 parameters!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Correctly has 3 parameters...", ref timer);

            ParameterInfo refParameterInfo = null;
            ParameterInfo outParameterInfo = null;
            ParameterInfo inParameterInfo = null;

            foreach (ParameterInfo parameterInfo in doSomethingMethodInfo.GetParameters()) {
                if (parameterInfo.ParameterType.IsByRef && !parameterInfo.IsOut) {
                    // Ref parameter
                    refParameterInfo = parameterInfo;
                }
                if (parameterInfo.ParameterType.IsByRef && parameterInfo.IsOut) {
                    // Out parameter
                    outParameterInfo = parameterInfo;
                }
                if (parameterInfo.IsIn) {
                    // In parameter
                    inParameterInfo = parameterInfo;
                }
            }

            if (refParameterInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find 'ref' parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (outParameterInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find 'out' parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (inParameterInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find 'in' parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Correctly has 'ref', 'out' and 'in' parameters...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "Creating Exercise...", ref timer);

            FunctionTimer.Create(() => new Exercise(), timer);
        }

        public void ExerciseValidate() {
            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, 0f);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, .5f);
        }

    }

}