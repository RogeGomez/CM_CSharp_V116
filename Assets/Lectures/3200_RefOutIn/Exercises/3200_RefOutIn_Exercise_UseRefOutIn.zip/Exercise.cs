using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3200_RefOutIn {


    public class Exercise {

        // Define a function named DoSomething with a ref, out and in parameters,
        // inside that function call ExerciseValidate();
        

        public Exercise() {
            // Call your function from here

        }

        private void ExerciseValidate() {
            ExerciseSceneTester.Instance.ExerciseValidate();
        }

    }

}
