using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2090_Dictionary {


    public class Exercise : MonoBehaviour {


        public enum ResourceType {
            Gold,
            Wood,
        }


        private void Start() {
            // Create a dictionary here, then call ExerciseValidate();

            Dictionary<ResourceType, int> dictionary = new Dictionary<ResourceType, int>();
            dictionary[ResourceType.Gold] = 5;
            dictionary[ResourceType.Wood] = 12;
            ExerciseValidate(dictionary);
        }


        // Don't modify this function, it's used for validating the exercise
        private void ExerciseValidate(Dictionary<ResourceType, int> resourceDictionary) {
            ExerciseSceneTester.Instance.ExerciseValidate(resourceDictionary);
        }

    }

}
