using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2090_Dictionary {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private bool success;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting for dictionary...", ref timer, add: false);
        }

        private void Start() {
            FunctionTimer.Create(() => {
                if (!success) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Function was never called!\n", ref timer);
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                }
            }, .01f);
        }

        public void ExerciseValidate(Dictionary<Exercise.ResourceType, int> resourceDictionary) {
            ExerciseUtils.TimedMessage(textMeshUI, "Function called...", ref timer);

            if (resourceDictionary == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Dictionary is null!\n", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Gold: {resourceDictionary[Exercise.ResourceType.Gold]}, expected 5\n", ref timer);
            if (resourceDictionary[Exercise.ResourceType.Gold] != 5) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Wood: {resourceDictionary[Exercise.ResourceType.Wood]}, expected 12\n", ref timer);
            if (resourceDictionary[Exercise.ResourceType.Wood] != 12) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
            success = true;
        }

    }

}
