using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2090_Dictionary {


    public class Exercise {

        public enum ResourceType {
            Gold,
            Wood,
            Stone,
            Food
        }

        // Define a class that can hold a ResourceType field and an int field



        // Define a List of that class type


        public Dictionary<ResourceType, int> CreateDictionary() {
            // Implement this function, create a Dictionary based on the contents of the List field


            return null;
        }


    }

}
