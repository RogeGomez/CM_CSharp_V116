using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2090_Dictionary {


    public class Exercise {

        public enum ResourceType {
            Gold,
            Wood,
            Stone,
            Food
        }

        // Define a class that can hold a ResourceType field and an int field
        public class ResourceTypeAmount {
            public ResourceType resourceType;
            public int amount;
        }

        // Define a List of that class type
        private List<ResourceTypeAmount> resourceTypeAmountList;


        public Dictionary<ResourceType, int> CreateDictionary() {
            // Implement this function, create a Dictionary based on the contents of the List field
            Dictionary<ResourceType, int> dictionary = new Dictionary<ResourceType, int>();

            foreach (ResourceTypeAmount resourceTypeAmount in resourceTypeAmountList) {
                dictionary[resourceTypeAmount.resourceType] = resourceTypeAmount.amount;
            }

            return dictionary;
        }


    }

}
