using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2090_Dictionary {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for nested class/struct...", ref timer, add: false);

            Type nestedType = null;
            foreach (Type testType in typeof(Exercise).GetNestedTypes(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)) {
                if (!testType.IsEnum && (testType.IsValueType || testType.IsClass)) {
                    nestedType = testType;
                    ExerciseUtils.TimedMessage(textMeshUI, "Found Nested type: " + nestedType.Name, ref timer);
                }
            }

            if (nestedType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find any nested class/struct!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            FieldInfo resourceTypeFieldInfo = null;
            FieldInfo intFieldInfo = null;
            foreach (FieldInfo fieldInfo in nestedType.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)) {
                if (fieldInfo.FieldType == typeof(Exercise.ResourceType)) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Found field of type ResourceType", ref timer);
                    resourceTypeFieldInfo = fieldInfo;
                }
                if (fieldInfo.FieldType == typeof(int)) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Found field of type int", ref timer);
                    intFieldInfo = fieldInfo;
                }
            }

            if (resourceTypeFieldInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find any ResourceType field inside the type!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found nested ResourceType field...", ref timer);

            if (intFieldInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find any 'int' field inside the type!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found nested int field...", ref timer);

            FieldInfo listFieldInfo = null;
            foreach (FieldInfo fieldInfo in typeof(Exercise).GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)) {
                if (fieldInfo.FieldType.IsGenericType && fieldInfo.FieldType.GetGenericTypeDefinition() == typeof(List<>)) {
                    listFieldInfo = fieldInfo;
                    ExerciseUtils.TimedMessage(textMeshUI, "Found Exercise List field...", ref timer);
                }
            }

            if (listFieldInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find any List field!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "Setting up List with elements: [Wood, 5]; [Gold, 3]; [Food, 2]", ref timer);

            Exercise exercise = new Exercise();

            object listObject = Activator.CreateInstance(listFieldInfo.FieldType);
            MethodInfo addMethodInfo = listObject.GetType().GetMethod("Add", BindingFlags.Instance | BindingFlags.Public);

            object resourceAmountObject = Activator.CreateInstance(nestedType);
            resourceTypeFieldInfo.SetValue(resourceAmountObject, Exercise.ResourceType.Wood);
            intFieldInfo.SetValue(resourceAmountObject, 5);
            addMethodInfo.Invoke(listObject, new object[] { resourceAmountObject });

            resourceAmountObject = Activator.CreateInstance(nestedType);
            resourceTypeFieldInfo.SetValue(resourceAmountObject, Exercise.ResourceType.Gold);
            intFieldInfo.SetValue(resourceAmountObject, 3);
            addMethodInfo.Invoke(listObject, new object[] { resourceAmountObject });

            resourceAmountObject = Activator.CreateInstance(nestedType);
            resourceTypeFieldInfo.SetValue(resourceAmountObject, Exercise.ResourceType.Food);
            intFieldInfo.SetValue(resourceAmountObject, 2);
            addMethodInfo.Invoke(listObject, new object[] { resourceAmountObject });

            listFieldInfo.SetValue(exercise, listObject);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling CreateDictionary()...", ref timer);
            Dictionary<Exercise.ResourceType, int> dictionary = exercise.CreateDictionary();

            ExerciseUtils.TimedMessage(textMeshUI, "Got Dictionary " + dictionary, ref timer);

            if (!dictionary.ContainsKey(Exercise.ResourceType.Wood)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Does not have Wood!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Wood: " + dictionary[Exercise.ResourceType.Wood] + ", expected: 5", ref timer);

            if (dictionary[Exercise.ResourceType.Wood] != 5) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!dictionary.ContainsKey(Exercise.ResourceType.Gold)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Does not have Gold!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Gold: " + dictionary[Exercise.ResourceType.Gold] + ", expected: 3", ref timer);

            if (dictionary[Exercise.ResourceType.Gold] != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!dictionary.ContainsKey(Exercise.ResourceType.Food)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Does not have Food!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Food: " + dictionary[Exercise.ResourceType.Food] + ", expected: 2", ref timer);

            if (dictionary[Exercise.ResourceType.Food] != 2) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
