using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2090_Dictionary {


    public class Exercise {


        public enum ResourceType {
            Gold,
            Wood,
            Stone,
            Food
        }

        public void CycleKeys(Dictionary<ResourceType, int> resourceAmountDictionary) {
            // Cycle through all keys in the Dictionary
            // Call ExerciseValidate(); for each key
            foreach (ResourceType resourceType in resourceAmountDictionary.Keys) {
                ExerciseValidate(resourceType);
            }
        }

        private void ExerciseValidate(ResourceType resourceType) {
            ExerciseSceneTester.Instance.ExerciseValidate(resourceType);
        }


    }

}
