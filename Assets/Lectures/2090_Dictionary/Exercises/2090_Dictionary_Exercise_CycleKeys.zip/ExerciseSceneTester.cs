using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2090_Dictionary {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private List<Exercise.ResourceType> receivedResourceTypeList;

        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Creating Dictionary with only Key: Wood...", ref timer, add: false);

            Dictionary<Exercise.ResourceType, int> resourceAmountDictionary = new Dictionary<Exercise.ResourceType, int>();
            resourceAmountDictionary[Exercise.ResourceType.Wood] = 56;

            receivedResourceTypeList = new List<Exercise.ResourceType>();

            Exercise exercise = new Exercise();
            exercise.CycleKeys(resourceAmountDictionary);

            if (receivedResourceTypeList.Count != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "Received more than one key!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (receivedResourceTypeList[0] != Exercise.ResourceType.Wood) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not receive Wood as expected!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Correctly got Key: Wood...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "Creating Dictionary keys: Wood, Gold, Food, Stone...", ref timer);

            resourceAmountDictionary = new Dictionary<Exercise.ResourceType, int>();
            resourceAmountDictionary[Exercise.ResourceType.Wood] = 56;
            resourceAmountDictionary[Exercise.ResourceType.Gold] = 56;
            resourceAmountDictionary[Exercise.ResourceType.Food] = 56;
            resourceAmountDictionary[Exercise.ResourceType.Stone] = 56;

            receivedResourceTypeList = new List<Exercise.ResourceType>();

            exercise.CycleKeys(resourceAmountDictionary);

            if (receivedResourceTypeList.Count != 4) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not receive exactly 4 keys!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!receivedResourceTypeList.Contains(Exercise.ResourceType.Wood)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not get Wood key!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Correctly got Key: Wood...", ref timer);

            if (!receivedResourceTypeList.Contains(Exercise.ResourceType.Gold)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not get Gold key!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Correctly got Key: Gold...", ref timer);

            if (!receivedResourceTypeList.Contains(Exercise.ResourceType.Food)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not get Food key!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Correctly got Key: Food...", ref timer);

            if (!receivedResourceTypeList.Contains(Exercise.ResourceType.Stone)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not get Stone key!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Correctly got Key: Stone...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "All correct!", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void ExerciseValidate(Exercise.ResourceType resourceType) {
            ExerciseUtils.TimedMessage(textMeshUI, "Key: " + resourceType, ref timer);
            receivedResourceTypeList.Add(resourceType);
        }

    }

}
