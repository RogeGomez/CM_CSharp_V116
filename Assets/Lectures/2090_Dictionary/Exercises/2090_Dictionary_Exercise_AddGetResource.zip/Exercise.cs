using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2090_Dictionary {


    public class Exercise {


        public enum ResourceType {
            Gold,
            Wood,
        }


        private Dictionary<ResourceType, int> resourceAmountDictionary;


        public void AddResource(ResourceType resourceType, int amount) {
            // Implement this function to Add resources, don't throw any errors

        }

        public int GetResourceAmount(ResourceType resourceType) {
            // Implement this function to Get the resource amount, don't throw errors
            return 0;
        }


    }

}
