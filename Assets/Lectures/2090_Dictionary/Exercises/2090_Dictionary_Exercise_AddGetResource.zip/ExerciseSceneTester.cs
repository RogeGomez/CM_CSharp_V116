using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2090_Dictionary {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Trying to add Wood x3...", ref timer, add: false);

            Exercise exercise = new Exercise();
            try {
                exercise.AddResource(Exercise.ResourceType.Wood, 3);
                ExerciseUtils.TimedMessage(textMeshUI, "Added Wood x3...", ref timer);
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, "Exception!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Trying to get Wood...", ref timer);

            try {
                int wood = exercise.GetResourceAmount(Exercise.ResourceType.Wood);
                ExerciseUtils.TimedMessage(textMeshUI, "Got Wood x" + wood + ", expected 3", ref timer);

                if (wood != 3) {
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                    return;
                }
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, "Exception!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "Trying to get Gold...", ref timer);

            try {
                int gold = exercise.GetResourceAmount(Exercise.ResourceType.Gold);
                ExerciseUtils.TimedMessage(textMeshUI, "Got Gold x" + gold + ", expected 0", ref timer);

                if (gold != 0) {
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                    return;
                }
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, "Exception!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }



            ExerciseUtils.TimedMessage(textMeshUI, "Trying to add Wood x5...", ref timer);

            try {
                exercise.AddResource(Exercise.ResourceType.Wood, 5);
                ExerciseUtils.TimedMessage(textMeshUI, "Added Wood x5...", ref timer);
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, "Exception!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Trying to get Wood...", ref timer);

            try {
                int wood = exercise.GetResourceAmount(Exercise.ResourceType.Wood);
                ExerciseUtils.TimedMessage(textMeshUI, "Got Wood x" + wood + ", expected 8", ref timer);

                if (wood != 8) {
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                    return;
                }
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, "Exception!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
