using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2090_Dictionary {


    public class Exercise {


        public enum ResourceType {
            Gold,
            Wood,
        }


        private Dictionary<ResourceType, int> resourceAmountDictionary;


        public void AddResource(ResourceType resourceType, int amount) {
            // Implement this function to Add resources, don't throw any errors
            if (resourceAmountDictionary == null) {
                resourceAmountDictionary = new Dictionary<ResourceType, int>();
            }
            if (resourceAmountDictionary.ContainsKey(resourceType)) {
                resourceAmountDictionary[resourceType] += amount;
            } else {
                resourceAmountDictionary[resourceType] = amount;
            }
        }

        public int GetResourceAmount(ResourceType resourceType) {
            // Implement this function to Get the resource amount, don't throw errors
            if (resourceAmountDictionary.ContainsKey(resourceType)) {
                return resourceAmountDictionary[resourceType];
            } else {
                return 0;
            }
        }


    }

}
