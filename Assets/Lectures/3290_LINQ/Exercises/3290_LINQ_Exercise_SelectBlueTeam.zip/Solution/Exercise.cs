using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3290_LINQ {


    public class Exercise {

        
        public Exercise() {
            PlayerData[] playerDataArray = new PlayerData[] {
                new PlayerData { playerName = "Code Monkey",        team = Team.Blue },
                new PlayerData { playerName = "Iron Man",           team = Team.Red },
                new PlayerData { playerName = "Captain America",    team = Team.Blue },
                new PlayerData { playerName = "Black Widow",        team = Team.Red },
                new PlayerData { playerName = "Spider-Man",         team = Team.Blue },
            };

            // Use LINQ to filter out only the players on the Blue team, then pass in the resulting list to ExerciseValidate();
            List<PlayerData> bluePlayerDataList =
                playerDataArray.Where(playerData => playerData.team == Team.Blue).ToList();

            ExerciseValidate(bluePlayerDataList);
        }

        private void ExerciseValidate(List<PlayerData> bluePlayerDataList) {
            ExerciseSceneTester.Instance.ExerciseValidate(bluePlayerDataList);
        }

        public enum Team {
            Red,
            Blue
        }

        public class PlayerData {

            public string playerName;
            public Team team;

            public override string ToString() {
                return playerName + ", " + team;
            }
        }

    }

}
