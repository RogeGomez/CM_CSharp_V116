using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3290_LINQ {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Creating Exercise...", ref timer, add: false);

            new Exercise();
        }

        public void ExerciseValidate(List<Exercise.PlayerData> bluePlayerDataList) {
            ExerciseUtils.TimedMessage(textMeshUI, "Checking if list has 3 elements...", ref timer);

            if (bluePlayerDataList.Count != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, $"bluePlayerDataList does NOT have 3 elements!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            
            ExerciseUtils.TimedMessage(textMeshUI, "Correct!", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Checking if they are all on the Blue team...", ref timer);

            bool allBlue = true;
            foreach (Exercise.PlayerData playerData in bluePlayerDataList) {
                ExerciseUtils.TimedMessage(textMeshUI, playerData.ToString(), ref timer);
                if (playerData.team != Exercise.Team.Blue) {
                    allBlue = false;
                }
            }

            if (!allBlue) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Not all are on the Blue team!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Correct!", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
