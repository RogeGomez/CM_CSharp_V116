using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2060_MultiDimensionalArrays {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Trying to GetSeatingDataStructure()...", ref timer, add: false);

            Exercise exercise = new Exercise();

            Exercise.Seat[][] seatingDataStructure = exercise.GetSeatingDataStructure();

            if (seatingDataStructure == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "It's null!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Got it...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Number of Rows: " + seatingDataStructure.Length + ", expected: 3...", ref timer);

            if (seatingDataStructure.Length != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (seatingDataStructure[0] == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "First row is null!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Number of Seats on first row: " + seatingDataStructure[0].Length + ", expected: 9...", ref timer);

            if (seatingDataStructure[0].Length != 9) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (seatingDataStructure[1] == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Second row is null!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Number of Seats on second row: " + seatingDataStructure[1].Length + ", expected: 12...", ref timer);

            if (seatingDataStructure[1].Length != 12) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (seatingDataStructure[2] == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Third row is null!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Number of Seats on third row: " + seatingDataStructure[2].Length + ", expected: 15...", ref timer);

            if (seatingDataStructure[2].Length != 15) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\nEverything correct!", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
