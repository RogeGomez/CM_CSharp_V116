using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2060_MultiDimensionalArrays {


    public class Exercise {


        public enum Seat {
            Empty,
            Occupied,
        }


        public Seat[][] GetSeatingDataStructure() {
            // Define a jagged array of type Seat, make the first row with 9 seats, the second with 12 and the third with 15
            
            return null;
        }



    }

}
