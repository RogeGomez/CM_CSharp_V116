using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2060_MultiDimensionalArrays {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Testing GetArrayArrays()...", ref timer, add: false);

            Exercise exercise = new Exercise();

            int[][] intArrayArrays = exercise.GetArrayArrays();

            if (intArrayArrays == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Function returned null!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Checking first dimension size...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, intArrayArrays.Length + ", expected: 3", ref timer);

            if (intArrayArrays.Length != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Checking intArrayArrays[0] is not null...", ref timer);

            if (intArrayArrays[0] == null) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Checking second dimension size...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, intArrayArrays[0].Length + ", expected: 4", ref timer);

            if (intArrayArrays[0].Length != 4) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Checking intArrayArrays[0][2]...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, intArrayArrays[0][2] + ", expected: 56", ref timer);

            if (intArrayArrays[0][2] != 56) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\nEverything correct!\n", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
