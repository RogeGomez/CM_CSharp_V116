using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2060_MultiDimensionalArrays {


    public class Exercise {


        // Create an array of arrays with a size of 3 on the first dimension and 4 on the second dimension
        public int[][] GetArrayArrays() {
            int[][] intArrayArrays = new int[3][];

            for (int i = 0; i < intArrayArrays.Length; i++) {
                intArrayArrays[i] = new int[4];
            }

            intArrayArrays[0][2] = 56;
            return intArrayArrays;
        }


    }

}
