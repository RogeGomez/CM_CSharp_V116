using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2060_MultiDimensionalArrays {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Trying to get value on index [0, 0] which should be valid...", ref timer, add: false);

            Exercise exercise = new Exercise();

            try {
                exercise.GetValue(0, 0);
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, "Got an Exception!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Got: " + exercise.GetValue(0, 0) + ", correct...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Trying to get value on index [1, 2] which should be valid...", ref timer);

            try {
                exercise.GetValue(1, 2);
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, "Got an Exception!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Got: " + exercise.GetValue(1, 2) + ", correct...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "Trying to get value on index [-1, 0] which should be invalid...", ref timer);

            try {
                exercise.GetValue(-1, 0);
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, "Got an Exception!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Got: " + exercise.GetValue(-1, 0) + ", expected: -1", ref timer);

            if (exercise.GetValue(-1, 0) != -1) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "Trying to get value on index [0, 5] which should be invalid...", ref timer);

            try {
                exercise.GetValue(0, 5);
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, "Got an Exception!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Got: " + exercise.GetValue(0, 5) + ", expected: -1", ref timer);

            if (exercise.GetValue(0, 5) != -1) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\nEverything correct!\n", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
