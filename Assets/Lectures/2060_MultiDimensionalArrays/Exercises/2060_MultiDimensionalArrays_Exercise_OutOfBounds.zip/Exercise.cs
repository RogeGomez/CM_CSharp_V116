using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2060_MultiDimensionalArrays {


    public class Exercise {


        // Don't modify this line
        private int[,] int2DArray = new int[3, 5];



        // Modify this function to validate the 'x' and 'y' in order to check if the values are valid, if not it should return -1
        public int GetValue(int x, int y) {
            return int2DArray[x, y];
        }


    }

}
