using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2060_MultiDimensionalArrays {


    public class Exercise {


        public int[,] GetArray() {
            // Define and create the array with size 3,4
            // Set the value on index 0,2 to 56


            return null;
        }

    }

}
