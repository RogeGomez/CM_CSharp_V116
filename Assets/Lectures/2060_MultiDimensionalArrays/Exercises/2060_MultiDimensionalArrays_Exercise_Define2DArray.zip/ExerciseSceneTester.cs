using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2060_MultiDimensionalArrays {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            Exercise exercise = new Exercise();

            float timer = 0f;
            ExerciseUtils.TimedMessage(textMeshUI, "Testing GetArray()...", ref timer, add: false);

            int[,] int2DArray = exercise.GetArray();
            if (int2DArray == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Function is returning null instead of array!\n", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Checking first dimension size = " + int2DArray.GetLength(0), ref timer);
            if (int2DArray.GetLength(0) != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, "Wrong size! First dimension length is not set to 3!\n", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Checking second dimension size = " + int2DArray.GetLength(1), ref timer);
            if (int2DArray.GetLength(1) != 4) {
                ExerciseUtils.TimedMessage(textMeshUI, "Wrong size! Second dimension length is not set to 4!\n", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Checking value on index [0,2] = " + int2DArray[0, 2], ref timer);
            if (int2DArray[0, 2] != 56) {
                // Wrong value!
                ExerciseUtils.TimedMessage(textMeshUI, "Wrong value! Expected 56!\n", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Everything correct!\n", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
