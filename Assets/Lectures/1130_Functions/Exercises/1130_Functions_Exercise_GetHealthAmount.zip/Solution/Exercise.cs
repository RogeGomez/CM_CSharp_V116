using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1130_Functions {


    public class Exercise : MonoBehaviour {


        public void TestExercise() {
            // Write some code where if the GetHealthAmount(); function returns < 50 it runs LowHealth(); or else it runs HighHealth();
            if (GetHealthAmount() < 50) {
                LowHealth();
            } else {
                HighHealth();
            }
        }



        // Don't modify these functions
        private void LowHealth() {
            ExerciseSceneTester.Instance.LowHealth();
        }

        private void HighHealth() {
            ExerciseSceneTester.Instance.HighHealth();
        }

        private int GetHealthAmount() {
            return healthAmount;
        }

        public void SetHealthAmount(int healthAmount) {
            this.healthAmount = healthAmount;
        }

        private int healthAmount;


    }

}
