using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1130_Functions {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private bool gotLowHealth;
        private bool gotHighHealth;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Setting Health Amount to 70...", ref timer, add: false);
            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestExercise(), expecting HighHealth()", ref timer);

            exercise.SetHealthAmount(70);
            exercise.TestExercise();

            if (!gotHighHealth) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Setting Health Amount to 25...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestExercise(), expecting LowHealth()", ref timer);

            exercise.SetHealthAmount(25);
            exercise.TestExercise();

            if (!gotLowHealth) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void LowHealth() {
            gotLowHealth = true;
            ExerciseUtils.TimedMessage(textMeshUI, "LowHealth();", ref timer);
        }

        public void HighHealth() {
            gotHighHealth = true;
            ExerciseUtils.TimedMessage(textMeshUI, "HighHealth();", ref timer);
        }

    }

}
