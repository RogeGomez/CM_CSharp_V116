using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1130_Functions {


    public class Exercise : MonoBehaviour {


        // Write a function named MultiplyInts that takes in 2 ints and returns the multiplication of both of them
        public int MultiplyInts(int a, int b) {
            return a * b;
        }



    }

}
