using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1130_Functions {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for MultiplyInts function...", ref timer, add: false);

            MethodInfo methodInfo = typeof(Exercise).GetMethod("MultiplyInts", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (methodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find MultiplyInts function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found MultiplyInts function...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Checking parameters and return type...", ref timer);

            if (methodInfo.ReturnType != typeof(int)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Does not return 'int'!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Function correctly returns 'int'...", ref timer);

            if (methodInfo.GetParameters().Length != 2) {
                ExerciseUtils.TimedMessage(textMeshUI, "Does not have 2 parameters!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Function correctly has 2 parameters...", ref timer);

            if (methodInfo.GetParameters()[0].ParameterType != typeof(int) || methodInfo.GetParameters()[1].ParameterType != typeof(int)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Both parameters are not of type 'int'!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Both parameters are correctly of type 'int'...", ref timer);

            int result = (int)methodInfo.Invoke(exercise, new object[] { 2, 3 });
            ExerciseUtils.TimedMessage(textMeshUI, "Calling function MultiplyInts(2, 3); == " + result + ", expected 6", ref timer);

            if (result != 6) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            ExerciseCompletionTester.ExerciseCompleted();
        }

    }

}
