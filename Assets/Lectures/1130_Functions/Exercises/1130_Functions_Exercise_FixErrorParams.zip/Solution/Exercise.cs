using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1130_Functions {


    public class Exercise : MonoBehaviour {


        public void TestExercise() {
            // Fix the errors and call the function properly
            MyFunction("Code Monkey", 35);
        }

        private void MyFunction(string name, int age) {
            // Do something
        }


    }

}
