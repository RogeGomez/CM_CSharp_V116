using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/* COMPILATION BLOCKER
namespace CodeMonkey.CSharpCourse.L1130_Functions {


    public class Exercise : MonoBehaviour {


        public void TestExercise() {
            // Fix the errors and call the function properly
            MyFunction(false, "Code Monkey");
        }

        private void MyFunction(string name, int age) {
            // Do something
        }


    }

}
COMPILATION BLOCKER */