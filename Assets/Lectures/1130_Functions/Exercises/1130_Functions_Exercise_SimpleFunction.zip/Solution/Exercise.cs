using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1130_Functions {


    public class Exercise {


        // Write the most basic function possible, name it "MyFunction", make it return void and take no parameters.
        // Remember to write inside this class code block
        private void MyFunction() {
        }



    }

}
