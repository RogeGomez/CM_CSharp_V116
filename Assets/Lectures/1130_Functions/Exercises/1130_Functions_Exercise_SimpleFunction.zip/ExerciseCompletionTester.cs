using CodeMonkey.CSharpCourse.Companion;
using CodeMonkey.CSharpCourse.Interactive;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1130_Functions {

    [InitializeOnLoad]
    public class ExerciseCompletionTester {


        private const string LECTURE_CODE = "1130";



        static ExerciseCompletionTester() {
            CodeMonkeyCompanion.OnCompilationFinished -= CodeMonkeyCompanion_OnCompilationFinished;
            CodeMonkeyCompanion.OnCompilationFinished += CodeMonkeyCompanion_OnCompilationFinished;
            CodeMonkeyCompanion.OnCompilerMessage -= CodeMonkeyCompanion_OnCompilerMessage;
            CodeMonkeyCompanion.OnCompilerMessage += CodeMonkeyCompanion_OnCompilerMessage;

            ExerciseSO.TryRemoveCompilationBlockers();
        }

        private static void CodeMonkeyCompanion_OnCompilerMessage(object sender, System.EventArgs e) {
            CompilerMessage compilerMessage = (CompilerMessage)sender;

            // Default
            CodeMonkeyCompanion.HandleCompilerMessage(compilerMessage);
        }

        private static void CodeMonkeyCompanion_OnCompilationFinished(object sender, System.EventArgs e) {
            if (CodeMonkeyCompanion.HasErrors()) {
                // There are still errors in the console
                return;
            }

            LectureSO lectureSO = LectureSO.GetLectureSO(LECTURE_CODE);
            string exerciseFilename = lectureSO.GetLectureFolderPath() + "Exercises/Exercise.cs";

            if (File.Exists(exerciseFilename)) {
                string exerciseFileText = File.ReadAllText(exerciseFilename);
                if (exerciseFileText.Contains("void MyFunction()")) {
                    // Success! Exercise completed!
                    ExerciseCompleted();
                } else {
                    // Exercise not complete, any common reason?
                    if (exerciseFileText.ToLower().Contains("void myfunction()")) {
                        CodeMonkeyCompanion.SendCompanionMessage(
                            CodeMonkeyCompanion.MessageType.Warning,
                            "Did you accidentally write '<b>myFunction</b>' or something other than exactly '<b>MyFunction()</b>'?\nRemember how code is <b>case sensitive!</b>"
                        );
                    }
                }
            } else {
                // File does not exist, did you accidentally delete it?
            }
        }

        public static void ExerciseCompleted() {
            // Success! Exercise completed!
            CodeMonkeyInteractiveSO.SetState(CodeMonkeyInteractiveSO.GetActiveExerciseSO(), CodeMonkeyInteractiveSO.State.Completed);
        }

    }

}
