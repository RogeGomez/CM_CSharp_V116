using CodeMonkey.CSharpCourse.Companion;
using CodeMonkey.CSharpCourse.Interactive;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1130_Functions {

    [InitializeOnLoad]
    public class ExerciseCompletionTester {


        private const string LECTURE_CODE = "1130";



        static ExerciseCompletionTester() {
            CodeMonkeyCompanion.OnCompilationFinished -= CodeMonkeyCompanion_OnCompilationFinished;
            CodeMonkeyCompanion.OnCompilationFinished += CodeMonkeyCompanion_OnCompilationFinished;
            CodeMonkeyCompanion.OnCompilerMessage -= CodeMonkeyCompanion_OnCompilerMessage;
            CodeMonkeyCompanion.OnCompilerMessage += CodeMonkeyCompanion_OnCompilerMessage;

            ExerciseSO.TryRemoveCompilationBlockers();
        }

        private static void CodeMonkeyCompanion_OnCompilerMessage(object sender, System.EventArgs e) {
            CompilerMessage compilerMessage = (CompilerMessage)sender;

            // Default
            CodeMonkeyCompanion.HandleCompilerMessage(compilerMessage);
        }

        private static void CodeMonkeyCompanion_OnCompilationFinished(object sender, System.EventArgs e) {
            if (CodeMonkeyCompanion.HasErrors()) {
                // There are still errors in the console
                Debug.Log("There are still errors in the console");
                return;
            }

            if (!ExerciseUtils.TryGetLectureExerciseCSText(LECTURE_CODE, out string lectureText)) {
                // Cannot read Exercise.cs
                return;
            }

            if (!lectureText.Contains("MyFunction(")) {
                CodeMonkeyCompanion.SendCompanionMessage(
                    CodeMonkeyCompanion.MessageType.Error,
                    "Could not find 'MyFunction' in file!"
                );
                return;
            }

            if (lectureText.Contains("MyFunction()")) {
                CodeMonkeyCompanion.SendCompanionMessage(
                    CodeMonkeyCompanion.MessageType.Error,
                    "MyFunction does not have parameters!"
                );
                return;
            }

            if (!lectureText.Replace(" ", "").Contains("MyFunction(int")) {
                CodeMonkeyCompanion.SendCompanionMessage(
                    CodeMonkeyCompanion.MessageType.Error,
                    "MyFunction does not have an 'int' parameter!"
                );
                return;
            }


            /*
            Type exerciseType = typeof(ExerciseCompletionTester).Assembly.GetType("CodeMonkey.CSharpCourse.L1130_Functions.Exercise"); 
            if (exerciseType == null) {
                return;
            }

            MethodInfo methodInfo = exerciseType.GetMethod("MyFunction", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (methodInfo == null) {
                CodeMonkeyCompanion.SendCompanionMessage(
                    CodeMonkeyCompanion.MessageType.Error,
                    "Could not find 'MyFunction' in file!"
                );
                return;
            }

            if (methodInfo.GetParameters().Length < 1) {
                CodeMonkeyCompanion.SendCompanionMessage(
                    CodeMonkeyCompanion.MessageType.Error,
                    "MyFunction does not have parameters!"
                );
                return;
            }

            if (methodInfo.GetParameters()[0].ParameterType == typeof(int)) {
                CodeMonkeyCompanion.SendCompanionMessage(
                    CodeMonkeyCompanion.MessageType.Error,
                    "MyFunction does not have an 'int' parameter!"
                );
                return;
            }
            */
            ExerciseCompleted();
        }

        public static void ExerciseCompleted() {
            // Success! Exercise completed!
            CodeMonkeyInteractiveSO.SetState(CodeMonkeyInteractiveSO.GetActiveExerciseSO(), CodeMonkeyInteractiveSO.State.Completed);
        }

    }

}
