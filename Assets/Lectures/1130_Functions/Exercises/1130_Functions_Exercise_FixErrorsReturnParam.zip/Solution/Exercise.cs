using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1130_Functions {


    public class Exercise {


        // Fix these errors
        private void MyFunction(int a) {
            // Do something
        }


    }

}
