using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* COMPILATION BLOCKER
namespace CodeMonkey.CSharpCourse.L1130_Functions {


    public class Exercise {


        // Fix these errors
        private MyFunction(int) {
            // Do something
        }


    }

}
COMPILATION BLOCKER */