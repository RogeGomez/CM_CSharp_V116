using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1130_Functions {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private string lastLog;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for 2 functions named 'PrintMessage'...", ref timer, add: false);

            MethodInfo printMessage1MethodInfo = null;
            MethodInfo printMessage2MethodInfo = null;

            foreach (MethodInfo methodInfo in typeof(Exercise).GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)) {
                if (methodInfo.Name == "PrintMessage") {
                    if (printMessage1MethodInfo == null) {
                        printMessage1MethodInfo = methodInfo;
                        continue;
                    }
                    if (printMessage2MethodInfo == null) {
                        printMessage2MethodInfo = methodInfo;
                        continue;
                    }
                }
            }

            if (printMessage1MethodInfo == null || printMessage2MethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not find 2 functions named exactly 'PrintMessage'!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found 2 functions named exactly 'PrintMessage'...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Checking parameters...", ref timer);

            if (printMessage1MethodInfo.GetParameters().Length != 1 || printMessage2MethodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "Both functions don't have one parameter!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Functions correctly have just one parameter...", ref timer);


            MethodInfo stringMethodInfo = null;
            MethodInfo intMethodInfo = null;

            if (printMessage1MethodInfo.GetParameters()[0].ParameterType == typeof(string)) {
                stringMethodInfo = printMessage1MethodInfo;
            }
            if (printMessage2MethodInfo.GetParameters()[0].ParameterType == typeof(string)) {
                stringMethodInfo = printMessage2MethodInfo;
            }

            if (printMessage1MethodInfo.GetParameters()[0].ParameterType == typeof(int)) {
                intMethodInfo = printMessage1MethodInfo;
            }
            if (printMessage2MethodInfo.GetParameters()[0].ParameterType == typeof(int)) {
                intMethodInfo = printMessage2MethodInfo;
            }

            if (intMethodInfo == null || stringMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "One function should have a string parameter!\nThe other one should have an int parameter!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found one function with a string parameter, and one with an int parameter...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Testing PrintMessage(\"Code Monkey\")...", ref timer);

            Application.logMessageReceived += Application_logMessageReceived;
            stringMethodInfo.Invoke(exercise, new object[] { "Code Monkey" });

            ExerciseUtils.TimedMessage(textMeshUI, "Expected Log: \"Code Monkey\", got: " + lastLog, ref timer);
            if (lastLog != "Code Monkey") {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Testing PrintMessage(56)...", ref timer);

            intMethodInfo.Invoke(exercise, new object[] { 56 });

            ExerciseUtils.TimedMessage(textMeshUI, "Expected Log: \"56\", got: " + lastLog, ref timer);
            if (lastLog != "56") {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            Application.logMessageReceived -= Application_logMessageReceived;

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        private void Application_logMessageReceived(string condition, string stackTrace, LogType type) {
            lastLog = condition;
        }
    }

}
