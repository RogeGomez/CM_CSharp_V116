using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1130_Functions {


    public class Exercise : MonoBehaviour {


        // Write a function named PrintMessage, that takes in a string a logs it to the console with Debug.Log();
        private void PrintMessage(string message) {
            Debug.Log(message);
        }

        // Then write another function with the exact same name that does the same thing but takes an int parameter.
        private void PrintMessage(int number) {
            Debug.Log(number.ToString());
        }



    }

}
