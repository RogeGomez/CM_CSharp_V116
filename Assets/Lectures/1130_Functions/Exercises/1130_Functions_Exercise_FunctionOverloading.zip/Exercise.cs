using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1130_Functions {


    public class Exercise : MonoBehaviour {


        // Write a function named PrintMessage, that takes in a string and logs it to the console with Debug.Log();



        // Then write another function with the exact same name that does the same thing but takes an int parameter.



    }

}
