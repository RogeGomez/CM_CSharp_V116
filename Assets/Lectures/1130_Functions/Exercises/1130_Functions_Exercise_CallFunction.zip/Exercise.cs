using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1130_Functions {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Call the ExerciseSuccess function from here
            // Then Run the Unity scene

        }


        private void ExerciseSuccess() {
            ExerciseSceneTester.Instance.Success();
        }



    }

}
