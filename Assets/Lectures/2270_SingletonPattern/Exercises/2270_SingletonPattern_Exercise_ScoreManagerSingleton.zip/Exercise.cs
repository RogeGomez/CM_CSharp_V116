using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.Rendering.DebugUI;

namespace CodeMonkey.CSharpCourse.L2270_SingletonPattern {


    public class Exercise {


        public Exercise() {
            // Access the ScoreManager singleton and call AddScore();

        }




    }

    public class ScoreManager {

        private static ScoreManager instance;
        public static ScoreManager Instance {
            get {
                if (instance == null) {
                    instance = new ScoreManager();
                }
                return instance;
            }
        }

        public void AddScore() {
            ExerciseSceneTester.Instance.AddScore();
        }

    }

}
