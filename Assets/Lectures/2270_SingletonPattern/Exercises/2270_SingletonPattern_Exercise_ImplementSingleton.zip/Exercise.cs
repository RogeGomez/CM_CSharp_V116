using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2270_SingletonPattern {


    public class Exercise {

        // Implement the singleton pattern in an Instance property
        // with a public get and private set
        // and lazy initialization



    }

}
