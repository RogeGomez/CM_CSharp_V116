using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2270_SingletonPattern {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "", ref timer, add: false);

            PropertyInfo propertyInfo = typeof(Exercise).GetProperty("Instance", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);

            if (propertyInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'Instance' property!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found 'Instance' property...", ref timer);

            Exercise exercise = (Exercise)propertyInfo.GetValue(null);

            if (exercise == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Getting the property did not return an object!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "Did you implement lazy initialization?", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Property did return an object...", ref timer);

            MethodInfo getMethodInfo = null;
            MethodInfo setMethodInfo = null;

            foreach (MethodInfo methodInfo in propertyInfo.GetAccessors(true)) {
                if (methodInfo.Name.Contains("set_")) {
                    setMethodInfo = methodInfo;
                }
                if (methodInfo.Name.Contains("get_")) {
                    getMethodInfo = methodInfo;
                }
            }

            if (getMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find a 'get' in the property...", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Property has a 'get'...", ref timer);

            if (setMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find a 'set' in the property...", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Property has a 'set'...", ref timer);

            if (!getMethodInfo.IsPublic) {
                ExerciseUtils.TimedMessage(textMeshUI, "Property get is not public!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "'get' is correctly marked public...", ref timer);

            if (!setMethodInfo.IsPrivate) {
                ExerciseUtils.TimedMessage(textMeshUI, "Property set is not private!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "'set' is correctly marked private...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "All correct!", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
