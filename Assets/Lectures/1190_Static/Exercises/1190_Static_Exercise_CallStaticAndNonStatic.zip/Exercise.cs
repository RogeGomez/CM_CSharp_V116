using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1190_Static {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Write code here, call both Player functions
            // Remember the difference between static and non static, how one requires an instance and one doesn't
        }



        public class Player {

            public void NormalFunction() {
                Debug.Log("Player.NormalFunction();");
                ExerciseSceneTester.Instance.PlayerNormalFunction();
            }

            public static void StaticFunction() {
                Debug.Log("Player.StaticFunction();");
                ExerciseSceneTester.Instance.PlayerStaticFunction();
            }

        }

    }

}
