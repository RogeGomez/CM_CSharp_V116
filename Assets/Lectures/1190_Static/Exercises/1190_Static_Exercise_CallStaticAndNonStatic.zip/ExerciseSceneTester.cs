using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1190_Static {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private bool didPlayerNormalFunctionRun;
        private bool didPlayerStaticFunctionRun;


        private void Awake() {
            Instance = this;

            didPlayerNormalFunctionRun = false;
            didPlayerStaticFunctionRun = false;

            textMeshUI.text = "Waiting for functions to be called...\n";

            FunctionTimer.Create(() => {
                if (didPlayerNormalFunctionRun) {
                    textMeshUI.text += "Normal function ran!\n";

                    FunctionTimer.Create(() => {
                        if (didPlayerStaticFunctionRun) {
                            // Both functions ran
                            textMeshUI.text += "Static function ran!\n";
                            textMeshUI.text += SUCCESS;
                            ExerciseCompletionTester.ExerciseCompleted();
                        } else {
                            textMeshUI.text += "Static function did not run!\n";
                            textMeshUI.text += INCORRECT;
                        }
                    }, 1f);
                } else {
                    textMeshUI.text += "Normal function did not run!\n";
                    textMeshUI.text += INCORRECT;
                }
            }, 1f);
        }

        public void PlayerNormalFunction() {
            didPlayerNormalFunctionRun = true;
        }

        public void PlayerStaticFunction() {
            didPlayerStaticFunctionRun = true;
        }

    }

}
