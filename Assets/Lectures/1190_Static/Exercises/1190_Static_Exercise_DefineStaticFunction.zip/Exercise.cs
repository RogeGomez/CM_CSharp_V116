using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1190_Static {


    public class Exercise {


        // Define a static function



    }

}
