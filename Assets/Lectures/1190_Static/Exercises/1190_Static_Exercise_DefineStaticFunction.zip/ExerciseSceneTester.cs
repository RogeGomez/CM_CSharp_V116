using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1190_Static {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for a static function...", ref timer, add: false);

            MethodInfo staticMethodInfo = null;
            foreach (MethodInfo methodInfo in typeof(Exercise).GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)) {
                if (methodInfo.IsStatic) {
                    staticMethodInfo = methodInfo;
                }
            }

            if (staticMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find a static function!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found static function: " + staticMethodInfo.Name, ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
