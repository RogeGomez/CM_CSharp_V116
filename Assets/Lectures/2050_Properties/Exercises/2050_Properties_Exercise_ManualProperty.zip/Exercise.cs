using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2050_Properties {


    public class Exercise {

        // Implement a property, string PlayerName, with a manual backing field, not auto-implemented, with a get; and set;



    }

}
