using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2050_Properties {


    public class Exercise {

        // Implement a property, string PlayerName, with a manual backing field, not auto-implemented, with a get; and set;

        private string playerName;

        public string PlayerName {
            get {
                return playerName;
            }
            set {
                playerName = value;
            }
        }

    }

}
