using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2050_Properties {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            float timer = 0;
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for properties...", ref timer, add: false);


            PropertyInfo propertyInfo = null;
            foreach (PropertyInfo testPropertyInfo in typeof(Exercise).GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Found property: " + testPropertyInfo.Name + "!", ref timer);
                propertyInfo = testPropertyInfo;
                break;
            }

            if (propertyInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "No property found!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (propertyInfo.GetMethod == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Property has no 'get'!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Property has a 'get'...", ref timer);

            if (propertyInfo.SetMethod == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Property has no 'set'!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Property has a 'set'...", ref timer);


            if (!propertyInfo.GetMethod.IsPublic) {
                ExerciseUtils.TimedMessage(textMeshUI, "Property 'get' is not public!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Property 'get' is correctly public...", ref timer);

            if (!propertyInfo.SetMethod.IsPrivate) {
                ExerciseUtils.TimedMessage(textMeshUI, "Property 'set' is not private!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Property 'set' is correctly private...", ref timer);



            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
