using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2050_Properties {


    public class Exercise {


        // Define a property with a public 'get' and a private 'set'
        public string PlayerName { get; private set; }



    }

}
