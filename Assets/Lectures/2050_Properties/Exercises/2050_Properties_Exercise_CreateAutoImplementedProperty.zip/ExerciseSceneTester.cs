using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2050_Properties {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            float timer = 0;
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for properties...", ref timer, add: false);

            bool foundProperty = false;
            foreach (PropertyInfo propertyInfo in typeof(Exercise).GetProperties()) {
                ExerciseUtils.TimedMessage(textMeshUI, "Found property: " + propertyInfo.Name + "!", ref timer);
                foundProperty = true;
            }

            if (!foundProperty) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not find any property!\n", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            const string LECTURE_CODE = "2050";
            if (ExerciseUtils.TryGetLectureExerciseCSText(LECTURE_CODE, out string lectureText)) {
                // Got lecture text
                if (lectureText.Contains("get;") && lectureText.Contains("set;")) {
                    // Contains auto implemented get and set
                    ExerciseUtils.TimedMessage(textMeshUI, "Property is auto-implemented!\n", ref timer);
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
                    FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
                } else {
                    ExerciseUtils.TimedMessage(textMeshUI, "Property is NOT auto-implemented!\n", ref timer);
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                }
            }
        }

    }

}
