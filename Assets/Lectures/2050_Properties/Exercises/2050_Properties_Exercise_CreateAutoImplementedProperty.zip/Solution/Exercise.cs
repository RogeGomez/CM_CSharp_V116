using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2050_Properties {


    public class Exercise {


        public string PlayerName { get; set; }


    }

}
