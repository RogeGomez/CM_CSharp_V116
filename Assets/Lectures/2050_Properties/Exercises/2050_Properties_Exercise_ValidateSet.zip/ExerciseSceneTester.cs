using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2050_Properties {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            float timer = 0;
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for properties...", ref timer, add: false);


            PropertyInfo propertyInfo = typeof(Exercise).GetProperty("PlayerName", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (propertyInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not find any property!\n", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (propertyInfo.SetMethod == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Property has no 'set'!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Trying to set PlayerName to \"Iron Man\"...", ref timer);

            Exercise exercise = new Exercise();
            propertyInfo.SetMethod.Invoke(exercise, new object[] { "Iron Man" });

            ExerciseUtils.TimedMessage(textMeshUI, "Trying to get PlayerName...", ref timer);

            string storedPlayerName = (string)propertyInfo.GetMethod.Invoke(exercise, new object[] { });

            ExerciseUtils.TimedMessage(textMeshUI, storedPlayerName + ", expected: Iron Man", ref timer);


            if (storedPlayerName != "Iron Man") {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Trying to set PlayerName to \"Black Widow\"...", ref timer);

            propertyInfo.SetMethod.Invoke(exercise, new object[] { "Black Widow" });

            ExerciseUtils.TimedMessage(textMeshUI, "Trying to get PlayerName...", ref timer);

            storedPlayerName = (string)propertyInfo.GetMethod.Invoke(exercise, new object[] { });

            ExerciseUtils.TimedMessage(textMeshUI, storedPlayerName + ", expected: Black Widow", ref timer);


            if (storedPlayerName != "Black Widow") {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Trying to set PlayerName to \"RudeWord\"...", ref timer);

            propertyInfo.SetMethod.Invoke(exercise, new object[] { "RudeWord" });

            ExerciseUtils.TimedMessage(textMeshUI, "Trying to get PlayerName...", ref timer);

            storedPlayerName = (string)propertyInfo.GetMethod.Invoke(exercise, new object[] { });

            ExerciseUtils.TimedMessage(textMeshUI, storedPlayerName + ", expected: Code Monkey", ref timer);


            if (storedPlayerName != "Code Monkey") {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
