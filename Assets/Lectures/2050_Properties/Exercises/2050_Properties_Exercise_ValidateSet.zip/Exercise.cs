using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2050_Properties {


    public class Exercise {


        private string playerName;


        // Add validation on the property 'set', if it is set to 'RudeWord' it should default to 'Code Monkey'
        public string PlayerName {
            get {
                return playerName;
            }
            set {
                playerName = value;
            }
        }

    }

}
