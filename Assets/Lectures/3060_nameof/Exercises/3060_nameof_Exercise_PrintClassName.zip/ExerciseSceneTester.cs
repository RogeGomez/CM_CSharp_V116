using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3060_nameof {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private string lastMessage;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("3060", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not read Exercise.cs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for nameof in the code...", ref timer);

            if (!lectureText.Contains("nameof(")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find nameof()!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found nameof()...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestExercise()...", ref timer);

            Application.logMessageReceived += Application_logMessageReceived;

            new Exercise().TestExercise();

            Application.logMessageReceived -= Application_logMessageReceived;


            ExerciseUtils.TimedMessage(textMeshUI, "Expected Log 'Exercise'...", ref timer);

            if (lastMessage != "Exercise") {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        private void Application_logMessageReceived(string condition, string stackTrace, LogType type) {
            lastMessage = condition;

            ExerciseUtils.TimedMessage(textMeshUI, "Log: " + lastMessage, ref timer);
        }

    }

}
