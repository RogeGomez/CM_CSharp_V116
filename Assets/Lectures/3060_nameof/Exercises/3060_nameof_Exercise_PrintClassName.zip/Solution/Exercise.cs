using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3060_nameof {


    public class Exercise {



        public void TestExercise() {
            // Do a Debug.Log on the Exercise class name using nameof
            Debug.Log(nameof(Exercise));
        }



    }



}