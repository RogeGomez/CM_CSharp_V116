using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3060_nameof {


    public class Exercise {



        public void SetSpeed(float speed) {
            // Do a Debug.Log on the 'speed' parameter name

        }



    }



}