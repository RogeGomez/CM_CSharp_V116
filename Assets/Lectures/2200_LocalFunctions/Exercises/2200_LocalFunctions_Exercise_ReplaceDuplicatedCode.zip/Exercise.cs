using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2200_LocalFunctions {


    public class Exercise : MonoBehaviour {


        private void Start() {
            Vector3 position = new Vector3(0, 0, 0);
            float rotation = 0f;
            int count = 0;

            // Replace this code that is copy pasted 4 times with just 4 calls of a local function
            position += new Vector3(10, 0, 0);
            rotation += 90;
            count++;
            ExerciseValidate(position, rotation, count);

            position += new Vector3(10, 0, 0);
            rotation += 90;
            count++;
            ExerciseValidate(position, rotation, count);

            position += new Vector3(10, 0, 0);
            rotation += 90;
            count++;
            ExerciseValidate(position, rotation, count);

            position += new Vector3(10, 0, 0);
            rotation += 90;
            count++;
            ExerciseValidate(position, rotation, count);
        }

        private void ExerciseValidate(Vector3 position, float rotation, int count) {
            ExerciseSceneTester.Instance.ExerciseValidate(position, rotation, count);
        }

    }

}
