using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2200_LocalFunctions {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private List<Vector3> positionList;
        private List<float> rotationList;
        private List<int> countList;


        private void Awake() {
            Instance = this;

            positionList = new List<Vector3>();
            rotationList = new List<float>();
            countList = new List<int>();

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
        }

        private void Start() {
            FunctionTimer.Create(() => {
                if (positionList.Count != 4) {
                    // Did not run function 4 times
                    ExerciseUtils.TimedMessage(textMeshUI, "Did not run ExerciseValidate() 4 times!", ref timer);
                    ExerciseUtils.TimedMessage(textMeshUI, $"It ran {positionList.Count} times!", ref timer);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "ExerciseValidate() was correctly called 4 times...", ref timer);

                if (!countList.Contains(1) || !countList.Contains(2) || !countList.Contains(3) || !countList.Contains(4)) {
                    // Some count is wrong
                    ExerciseUtils.TimedMessage(textMeshUI, $"Some 'count' is wrong!", ref timer);
                    ExerciseUtils.TimedMessage(textMeshUI, $"Did you place the exact same code on the local function?", ref timer);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "All data is correct...", ref timer);

                // Validate functions
                int normalFunctionCount = 0;
                foreach (MethodInfo methodInfo in typeof(Exercise).GetMethods(BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)) {
                    Debug.Log(methodInfo.Name);
                    if (methodInfo.Name[0] != '<') {
                        // It's a normal function
                        normalFunctionCount++;
                    }
                }

                if (normalFunctionCount != 2) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Found more than 2 normal functions!", ref timer);
                    ExerciseUtils.TimedMessage(textMeshUI, "Did you define a normal function instead of a Local function?", ref timer);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "Found only 2 normal functions as expected...", ref timer);

                if (!ExerciseUtils.TryGetLectureExerciseCSText("2200", out string lectureText)) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Cannot read Exercise.cs!", ref timer);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                if (CountSubstring(lectureText, "count++") > 1) {
                    // Found more than one instance!
                    ExerciseUtils.TimedMessage(textMeshUI, "Found some copy pasted code!", ref timer);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "Did not find any copy pasted code...", ref timer);

                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
                FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
            }, .01f);
        }

        public void ExerciseValidate(Vector3 position, float rotation, int count) {
            positionList.Add(position);
            rotationList.Add(rotation);
            countList.Add(count);
        }

        private int CountSubstring(string text, string value) {
            int count = 0, minIndex = text.IndexOf(value, 0);
            while (minIndex != -1) {
                minIndex = text.IndexOf(value, minIndex + value.Length);
                count++;
            }
            return count;
        }

    }

}
