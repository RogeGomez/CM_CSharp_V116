using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3100_Records {


    public class Exercise {


        public record Person(string FirstName, string LastName);


        public void TestExercise() {
            // Fix the error, create a Person named "Code", "Monkey"
            Person person = new Person("Code", "Monkey");

            ExerciseValidate(person);
        }


        private void ExerciseValidate(Person person) {
            ExerciseSceneTester.Instance.ExerciseValidate(person);
        }




    }



}

// Workaround to use Records in Unity
namespace System.Runtime.CompilerServices {
    public class IsExternalInit {
    }
}