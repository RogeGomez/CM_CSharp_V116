using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;
using static CodeMonkey.CSharpCourse.L3100_Records.Exercise;

namespace CodeMonkey.CSharpCourse.L3100_Records {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private Person person;
        private Person person2;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);

            ExerciseUtils.TimedMessage(textMeshUI, "No Errors in the code...", ref timer);

            new Exercise().TestExercise();

            if (person == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Did not recieve Person!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (person.FirstName != "Code" || person.LastName != "Monkey") {
                ExerciseUtils.TimedMessage(textMeshUI, $"Person is not named exactly \"Code\", \"Monkey\"!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Person is correctly named " + person, ref timer);



            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void ExerciseValidate(Person person) {
            this.person = person;
        }

    }

}
