using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3100_Records {


    public class Exercise {


        // Define a record named Person with a string FirstName and string LastName
        public record Person(string FirstName, string LastName);



    }



}

// Workaround to use Records in Unity
namespace System.Runtime.CompilerServices {
    public class IsExternalInit {
    }
}