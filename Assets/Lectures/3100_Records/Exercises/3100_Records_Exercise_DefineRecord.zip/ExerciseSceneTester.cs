using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3100_Records {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("3100", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not read Exercise.cs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for record in the code...", ref timer);

            if (!lectureText.Contains(" record")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find record!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found record...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for Person type...", ref timer);
            Type personType = typeof(Exercise).GetNestedType("Person", BindingFlags.Public | BindingFlags.NonPublic);

            if (personType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find Person!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found Person type...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Checking properties...", ref timer);

            PropertyInfo firstNamePropertyInfo = personType.GetProperty("FirstName");
            if (firstNamePropertyInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find FirstName property!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Found FirstName...", ref timer);

            PropertyInfo lastNamePropertyInfo = personType.GetProperty("LastName");
            if (lastNamePropertyInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find LastName property!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Found LastName...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
