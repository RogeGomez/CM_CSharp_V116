using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;
using static CodeMonkey.CSharpCourse.L3100_Records.Exercise;

namespace CodeMonkey.CSharpCourse.L3100_Records {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private Person person1;
        private Person person2;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);

            new Exercise().TestExercise();

            if (person1 == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Did not recieve Person1!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            if (person2 == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Did not recieve Person1!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (person1.FirstName != "Code" || person1.LastName != "Monkey") {
                ExerciseUtils.TimedMessage(textMeshUI, $"Person1 is not named exactly \"Code\", \"Monkey\"!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Person1 is correctly named " + person1, ref timer);

            if (person2.FirstName != "Code" || person2.LastName != "Gorilla") {
                ExerciseUtils.TimedMessage(textMeshUI, $"Person1 is not named exactly \"Code\", \"Gorilla\"!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Person2 is correctly named " + person2, ref timer);



            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void ExerciseValidate(Person person1, Person person2) {
            this.person1 = person1;
            this.person2 = person2;
        }

    }

}
