using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3100_Records {


    public class Exercise {


        public record Person(string FirstName, string LastName);


        public void TestExercise() {
            // Create a Person named "Code", "Monkey"; and another one named "Code", "Gorilla"
            // Then pass both to the ExerciseValidate function
            Person person1 = new Person("Code", "Monkey");
            Person person2 = person1 with { LastName = "Gorilla" };

            ExerciseValidate(person1, person2);
        }


        private void ExerciseValidate(Person person1, Person person2) {
            ExerciseSceneTester.Instance.ExerciseValidate(person1, person2);
        }




    }



}

// Workaround to use Records in Unity
namespace System.Runtime.CompilerServices {
    public class IsExternalInit {
    }
}