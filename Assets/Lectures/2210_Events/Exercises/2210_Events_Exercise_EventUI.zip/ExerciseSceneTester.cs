using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace CodeMonkey.CSharpCourse.L2210_Events {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;
        [SerializeField] private Image healthBarImage;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);

            HealthSystem healthSystem = new HealthSystem();

            ExerciseUtils.TimedMessage(textMeshUI, "Calling SetHealthSystem...", ref timer);

            exercise.SetHealthSystem(healthSystem);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling healthSystem.TakeDamage()...", ref timer);

            bool testFloatEquals = false;
            FunctionTimer.Create(() => {
                healthSystem.TakeDamage();
                testFloatEquals = TestFloatEquals(healthBarImage.fillAmount, .9f);
            }, timer);
            timer += .1f;

            ExerciseUtils.TimedMessage(textMeshUI, "Checking if HealthBar is at 90%...", ref timer);

            FunctionTimer.Create(() => {
                if (!testFloatEquals) {
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                    return;
                }
            }, timer);
            timer += .1f;

            ExerciseUtils.TimedMessage(textMeshUI, "Correct...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling healthSystem.TakeDamage() * 6...", ref timer);

            bool testFloatEquals2 = false;
            FunctionTimer.Create(() => {
                healthSystem.TakeDamage();
                healthSystem.TakeDamage();
                healthSystem.TakeDamage();
                healthSystem.TakeDamage();
                healthSystem.TakeDamage();
                healthSystem.TakeDamage();
                testFloatEquals2 = TestFloatEquals(healthBarImage.fillAmount, .3f);
            }, timer);
            timer += .1f;

            ExerciseUtils.TimedMessage(textMeshUI, "Checking if HealthBar is at 30%...", ref timer);

            FunctionTimer.Create(() => {
                if (!testFloatEquals2) {
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                    return;
                }
            }, timer);
            timer += .1f;

            ExerciseUtils.TimedMessage(textMeshUI, "Correct...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            ExerciseCompletionTester.ExerciseCompleted();
        }

        private bool TestFloatEquals(float test, float compare, float maxChange = .01f) {
            return Mathf.Abs(test - compare) < maxChange;
        }

    }

}
