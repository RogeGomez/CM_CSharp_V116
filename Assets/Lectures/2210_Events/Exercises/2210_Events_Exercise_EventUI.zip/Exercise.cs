using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace CodeMonkey.CSharpCourse.L2210_Events {


    public class Exercise : MonoBehaviour {


        [SerializeField] private Image healthBarImage;


        private HealthSystem healthSystem;


        public void SetHealthSystem(HealthSystem healthSystem) {
            this.healthSystem = healthSystem;

            // Listen to the OnDamaged event on the HealthSystem
            // then GetHealthAmountNormalized() and call SetHealthBarSize() to update the visual

        }


        private void SetHealthBarSize(float healthAmountNormalized) {
            healthBarImage.fillAmount = healthAmountNormalized;
        }

    }

    // Don't modify this class
    public class HealthSystem {


        public event EventHandler OnDamaged;


        private int healthAmount = 10;
        private int healthAmountMax = 10;


        public void TakeDamage() {
            healthAmount--;
            OnDamaged?.Invoke(this, EventArgs.Empty);
        }

        public float GetHealthAmountNormalized() {
            return (float)healthAmount / healthAmountMax;
        }

    }

}
