using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2210_Events {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private EventArgs gotEventArgs;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for OnDamagedEventArgs...", ref timer, add: false);


            Type onDamagedEventArgsType = typeof(Exercise).GetNestedType("OnDamagedEventArgs");

            if (onDamagedEventArgsType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find OnDamagedEventArgs type!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found type OnDamagedEventArgs...", ref timer);


            if (!onDamagedEventArgsType.IsSubclassOf(typeof(EventArgs))) {
                ExerciseUtils.TimedMessage(textMeshUI, "OnDamagedEventArgs does not inherit from EventArgs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "It correctly inherits from EventArgs...", ref timer);

            FieldInfo damageAmountFieldInfo = onDamagedEventArgsType.GetField("damageAmount", BindingFlags.Instance | BindingFlags.Public);

            if (damageAmountFieldInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'damageAmount' field!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found damageAmount field...\n", ref timer);


            EventInfo onDamagedEventInfo = typeof(Exercise).GetEvent("OnDamaged", BindingFlags.Public | BindingFlags.Instance);
            if (onDamagedEventInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did NOT find any OnDamaged event!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "Did you remove it?", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found event OnDamaged...", ref timer);

            if (onDamagedEventInfo.EventHandlerType.GetGenericArguments().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "Event does not have one generic type!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (onDamagedEventInfo.EventHandlerType.GetGenericArguments()[0] != onDamagedEventArgsType) {
                ExerciseUtils.TimedMessage(textMeshUI, "Event generic is not of type OnDamagedEventArgs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Event is correctly defined as EventHandler<OnDamagedEventArgs>...\n", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Subscribing to event...", ref timer);

            exercise.SetupTest();

            ExerciseUtils.TimedMessage(textMeshUI, "Calling Damage(56)...", ref timer);
            exercise.Damage(56);

            if (gotEventArgs == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Event was not fired!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Listened to event...", ref timer);

            if (gotEventArgs.GetType() != onDamagedEventArgsType) {
                ExerciseUtils.TimedMessage(textMeshUI, "Fired EventArgs is not of type OnDamagedEventArgs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            int damageAmount = (int)damageAmountFieldInfo.GetValue(gotEventArgs);

            ExerciseUtils.TimedMessage(textMeshUI, "Got damageAmount: " + damageAmount + ", expected: 56", ref timer);

            if (damageAmount != 56) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "All correct!", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            ExerciseCompletionTester.ExerciseCompleted();
        }

        public void OnDamagedListener(object sender, EventArgs e) {
            gotEventArgs = e;
        }

    }

}
