using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2210_Events {


    public class Exercise : MonoBehaviour {


        // Define custom EventArgs for the OnDamaged event, remember the proper naming rules
        // inside it store an int for the 'damageAmount'
        public event EventHandler OnDamaged;


        public void Damage(int damageAmount) {
            // Refactor this code to fire the event using custom event args with the damage amount
            OnDamaged?.Invoke(this, EventArgs.Empty);
        }




        // Don't modify this testing code
        public void SetupTest() {
            OnDamaged += Exercise_OnDamaged;
        }

        private void Exercise_OnDamaged(object sender, EventArgs e) {
            ExerciseSceneTester.Instance.OnDamagedListener(sender, e);
        }
    }

}
