using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2210_Events {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private bool listenedToEvent;

        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
            EventInfo onTickEventInfo = typeof(Exercise).GetEvent("OnTick", BindingFlags.Public | BindingFlags.Instance);
            if (onTickEventInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did NOT find any OnTick event!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "Did you define it with the exact name?", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "Is the event public?", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found event OnTick...", ref timer);

            if (onTickEventInfo.EventHandlerType != typeof(EventHandler)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Event is not of type EventHandler!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Event is correctly of type EventHandler...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Subscribing to event...", ref timer);
            onTickEventInfo.AddEventHandler(exercise, new EventHandler(OnTickListener));

            ExerciseUtils.TimedMessage(textMeshUI, "Calling Tick()...", ref timer);
            exercise.Tick();

            if (!listenedToEvent) {
                ExerciseUtils.TimedMessage(textMeshUI, "Event was not fired!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Listened to event!", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            ExerciseCompletionTester.ExerciseCompleted();
        }

        private void OnTickListener(object sender, EventArgs e) {
            listenedToEvent = true;
        }

    }

}
