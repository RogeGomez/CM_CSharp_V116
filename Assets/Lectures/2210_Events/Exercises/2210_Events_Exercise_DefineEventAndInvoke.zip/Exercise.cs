using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2210_Events {


    public class Exercise : MonoBehaviour {

        // Define an event EventHandler OnTick
        


        public void Tick() {
            // Fire off the event here

        }


    }

}
