using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace CodeMonkey.CSharpCourse.L2210_Events {

    public class Exercise {

        // Delete this entire HealthBarUI class so that nothing is listening to the HealthSystem events
        public class HealthBarUI {


            [SerializeField] private Image healthBarImage;


            private HealthSystem healthSystem;


            public void SetHealthSystem(HealthSystem healthSystem) {
                this.healthSystem = healthSystem;

                healthSystem.OnDamaged += HealthSystem_OnDamaged;
            }

            private void HealthSystem_OnDamaged(object sender, EventArgs e) {
                SetHealthBarSize(healthSystem.GetHealthAmountNormalized());
            }

            private void SetHealthBarSize(float healthAmountNormalized) {
                healthBarImage.fillAmount = healthAmountNormalized;
            }

        }


        // Don't modify this class
        public class HealthSystem {


            public event EventHandler OnDamaged;


            private int healthAmount = 10;
            private int healthAmountMax = 10;


            public void TakeDamage() {
                healthAmount--;
                OnDamaged?.Invoke(this, EventArgs.Empty);
            }

            public float GetHealthAmountNormalized() {
                return (float)healthAmount / healthAmountMax;
            }

        }

    }

}
