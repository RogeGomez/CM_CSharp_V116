using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace CodeMonkey.CSharpCourse.L2210_Events {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);

            Exercise.HealthSystem healthSystem = new Exercise.HealthSystem();

            ExerciseUtils.TimedMessage(textMeshUI, "Checking that HealthBarUI no longer exists...", ref timer);

            Type healthBarUIType = typeof(Exercise).GetNestedType("HealthBarUI", BindingFlags.Public);

            if (healthBarUIType != null) {
                ExerciseUtils.TimedMessage(textMeshUI, "HealthBarUI still exists!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "HealthBarUI correctly no longer exists!", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling healthSystem.TakeDamage()...", ref timer);

            healthSystem.TakeDamage();

            ExerciseUtils.TimedMessage(textMeshUI, "Code still works!", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            ExerciseCompletionTester.ExerciseCompleted();
        }

        private bool TestFloatEquals(float test, float compare, float maxChange = .01f) {
            return Mathf.Abs(test - compare) < maxChange;
        }

    }

}
