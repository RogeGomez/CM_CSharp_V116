using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2210_Events {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);

            FunctionTimer.Create(() => {
                ExerciseUtils.TimedMessage(textMeshUI, "Checking listener count OnTick...", ref timer);

                ExerciseUtils.TimedMessage(textMeshUI, exercise.GetOnTickInvocationList().Length + ", expected: 1...", ref timer);

                if (exercise.GetOnTickInvocationList().Length != 1) {
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "Correctly has one listener...", ref timer);

                ExerciseUtils.TimedMessage(textMeshUI, "Firing Event OnTick()...", ref timer);

                exercise.Tick();

                ExerciseUtils.TimedMessage(textMeshUI, "Now listener should have unsubscribed...", ref timer);

                ExerciseUtils.TimedMessage(textMeshUI, "Checking listener count OnTick...", ref timer);

                ExerciseUtils.TimedMessage(textMeshUI, exercise.GetOnTickInvocationList().Length + ", expected: 0...", ref timer);

                if (exercise.GetOnTickInvocationList().Length != 0) {
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "Correctly unsubscribed...", ref timer);


                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
                ExerciseCompletionTester.ExerciseCompleted();
            }, .1f);
        }

    }

}
