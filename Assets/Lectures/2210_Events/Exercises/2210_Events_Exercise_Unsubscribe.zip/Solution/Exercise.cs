using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2210_Events {


    public class Exercise : MonoBehaviour {


        public event EventHandler OnTick;


        private void Start() {
            // Subscribe to the OnTick even, listen to it just once and then unsubscribe.
            OnTick += Exercise_OnTick;
        }

        private void Exercise_OnTick(object sender, EventArgs e) {
            OnTick -= Exercise_OnTick;
        }

        public void Tick() {
            OnTick?.Invoke(this, EventArgs.Empty);
        }


        // Don't modify this code
        public Delegate[] GetOnTickInvocationList() {
            if (OnTick != null) {
                return OnTick.GetInvocationList();
            } else {
                return new Delegate[0];
            }
        }


    }

}
