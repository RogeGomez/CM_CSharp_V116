using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3270_UsingIDisposable {


    public class Exercise {

        public void Test() {
            /* COMPILATION BLOCKER
            using (PlayerData playerData = new PlayerData()) {
                playerData.OpenDataFile();
                playerData.SaveDataFile();
            }
            COMPILATION BLOCKER */
        }

        // Fix the error by implementing IDisposable
        // there's no need to do anything specific inside the function in this example
        public class PlayerData {

            public void OpenDataFile() {
                // ...
            }

            public void SaveDataFile() {
                // ...
            }

        }

    }

}
