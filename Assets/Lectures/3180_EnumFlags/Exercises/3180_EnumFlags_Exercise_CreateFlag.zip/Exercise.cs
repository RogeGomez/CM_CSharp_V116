using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3180_EnumFlags {


    public class Exercise {

        // Define a valid Flags Enum named Powers
        // with the values None, Fire, Ice, Shock, Ground
        // and also define a FireAndIce value that combines both Fire and Ice.
        


    }

}
