using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3180_EnumFlags {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            Type powersType = typeof(Exercise).GetNestedType("Powers", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);

            if (powersType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find Powers type!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Powers exists...", ref timer);

            if (!powersType.IsEnum) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Powers is not an enum!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Powers is correctly an enum...", ref timer);

            string[] namesArray = powersType.GetEnumNames();
            ExerciseUtils.TimedMessage(textMeshUI, "Validating Enum values...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Expecting: None, Fire, Ice, Shock, Ground, FireAndIce...", ref timer);
            if (!namesArray.Contains("None")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Did not find None!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            if (!namesArray.Contains("Fire")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Did not find Fire!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            if (!namesArray.Contains("Ice")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Did not find Ice!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            if (!namesArray.Contains("Shock")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Did not find Shock!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            if (!namesArray.Contains("Ground")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Did not find Ground!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            if (!namesArray.Contains("FireAndIce")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Did not find FireAndIce!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Found all Enum values...", ref timer);

            Attribute flagsAttribute = powersType.GetCustomAttribute(typeof(FlagsAttribute));
            if (flagsAttribute == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Did not find Flags attribute!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Found [Flags] attribute...", ref timer);

            int fireValue, shockValue, fireAndIceValue;
            fireValue = shockValue = fireAndIceValue = 0;

            foreach (var v in powersType.GetEnumValues()) {
                if (v.ToString() == "Fire") {
                    fireValue = (int)v;
                }
                if (v.ToString() == "Shock") {
                    shockValue = (int)v;
                }
                if (v.ToString() == "FireAndIce") {
                    fireAndIceValue = (int)v;
                }
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Checking value of Fire, got {fireValue}, expected 1...", ref timer);
            if (fireValue != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Checking value of Shock, got {shockValue}, expected 4...", ref timer);
            if (shockValue != 4) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Checking value of FireAndIce, got {fireAndIceValue}, expected 3...", ref timer);
            if (fireAndIceValue != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }



            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
