using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3070_sizeof {


    public class Exercise {



        public void TestExercise() {
            // Do a Debug.Log on the size of an int
            
        }


    }



}