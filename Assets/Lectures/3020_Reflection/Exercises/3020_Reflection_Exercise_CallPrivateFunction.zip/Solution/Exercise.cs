using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3020_Reflection {


    public class Exercise {


        public Exercise(Player player) {
            // Call the private function player.SecretFunction using reflection
            MethodInfo secretFunctionMethodInfo = typeof(Player).GetMethod("SecretFunction", BindingFlags.NonPublic | BindingFlags.Instance);

            secretFunctionMethodInfo.Invoke(player, null);
        }



        // Don't modify this class
        public class Player {

            private void SecretFunction() {
                ExerciseSceneTester.Instance.SecretFunction();
            }

        }


    }



}