using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3020_Reflection {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private bool calledSecretFunction;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Constructing Exercise...", ref timer, add: false);

            new Exercise(new Exercise.Player());

            if (!calledSecretFunction) {
                ExerciseUtils.TimedMessage(textMeshUI, "SecretFunction() was not called!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }




            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void SecretFunction() {
            ExerciseUtils.TimedMessage(textMeshUI, "Called SecretFunction()...", ref timer);
            calledSecretFunction = true;
        }

    }

}
