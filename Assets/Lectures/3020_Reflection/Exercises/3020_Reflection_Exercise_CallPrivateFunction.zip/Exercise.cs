using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3020_Reflection {


    public class Exercise {


        public Exercise(Player player) {
            // Call the private function player.SecretFunction using reflection
            
        }



        // Don't modify this class
        public class Player {

            private void SecretFunction() {
                ExerciseSceneTester.Instance.SecretFunction();
            }

        }


    }



}