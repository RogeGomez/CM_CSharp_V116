using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3020_Reflection {


    public class Exercise {


        public void TextExercise(Player player) {
            // Modify the player.playerName to "Code Monkey" using reflection
            // Remember to use the correct BindingFlags
            FieldInfo playerNameFieldInfo = typeof(Player).GetField("playerName", BindingFlags.NonPublic | BindingFlags.Instance);

            playerNameFieldInfo.SetValue(player, "Code Monkey");
        }



        // Don't modify this class
        public class Player {

            private string playerName = "Iron Man";

            public string GetPlayerName() {
                return playerName;
            }

        }


    }



}