using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3020_Reflection {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Constructing Player...", ref timer, add: false);

            Exercise exercise = new Exercise();

            Exercise.Player player = new Exercise.Player();

            ExerciseUtils.TimedMessage(textMeshUI, "player.GetPlayerName() -> " + player.GetPlayerName() + ", expected Iron Man...", ref timer);

            if (player.GetPlayerName() != "Iron Man") {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestExercise(player)...", ref timer);
            exercise.TextExercise(player);

            ExerciseUtils.TimedMessage(textMeshUI, "player.GetPlayerName() -> " + player.GetPlayerName() + ", expected Code Monkey...", ref timer);

            if (player.GetPlayerName() != "Code Monkey") {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
