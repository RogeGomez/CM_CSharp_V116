using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3020_Reflection {


    public class Exercise {


        public Exercise(Player player) {
            // Call the function player.TakeDamage using reflection
            

        }



        // Don't modify this class
        public class Player {

            public void TakeDamage() {
                ExerciseSceneTester.Instance.TakeDamage();
            }

        }


    }



}