using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3020_Reflection {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private List<string> messageList;


        private void Awake() {
            Instance = this;

            messageList = new List<string>();
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);

            Application.logMessageReceived += Application_logMessageReceived;
            new Exercise();
            Application.logMessageReceived -= Application_logMessageReceived;

            ExerciseUtils.TimedMessage(textMeshUI, "\n", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for 'TakeDamage'...", ref timer);

            if (!messageList.Contains("TakeDamage")) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found!", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "Looking for 'SetSpeed'...", ref timer);

            if (!messageList.Contains("SetSpeed")) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found!", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "Looking for 'EnableSuperMode'...", ref timer);

            if (!messageList.Contains("EnableSuperMode")) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found!", ref timer);



            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        private void Application_logMessageReceived(string condition, string stackTrace, LogType type) {
            messageList.Add(condition);

            ExerciseUtils.TimedMessage(textMeshUI, "Log: " + condition, ref timer);
        }

    }

}
