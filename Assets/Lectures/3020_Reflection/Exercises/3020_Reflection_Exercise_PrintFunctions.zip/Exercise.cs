using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3020_Reflection {


    public class Exercise {


        public Exercise() {
            // Cycle through all the functions inside the Player type a do a Debug.Log to print out the name


        }


        // Don't modify this class
        public class Player {

            public void TakeDamage() {
                // ...
            }

            public void SetSpeed() {
                // ...
            }

            public void EnableSuperMode() {
                // ...
            }

        }


    }



}