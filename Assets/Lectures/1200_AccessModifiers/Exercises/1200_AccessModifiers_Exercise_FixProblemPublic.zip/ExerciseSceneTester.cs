using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1200_AccessModifiers {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Testing...", ref timer, add: false);

            MethodInfo getScoreMethodInfo = typeof(Exercise).GetMethod("GetScore", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            MethodInfo addScoreMethodInfo = typeof(Exercise).GetMethod("AddScore", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (getScoreMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find GetScore() function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (addScoreMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find AddScore() function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Trying to get current score...", ref timer);

            if (getScoreMethodInfo.IsPrivate) {
                ExerciseUtils.TimedMessage(textMeshUI, "Cannot do it! GetScore() is incorrectly marked private!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "It should be public so other classes can call the function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, $"Current Score: {getScoreMethodInfo.Invoke(exercise, new object[] { })}", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, $"Trying to add score...", ref timer);

            if (addScoreMethodInfo.IsPrivate) {
                ExerciseUtils.TimedMessage(textMeshUI, "Cannot do it! AddScore() is incorrectly marked private!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "It should be public so other classes can call the function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Calling AddScore(5);...", ref timer);
            addScoreMethodInfo.Invoke(exercise, new object[] { 5 });

            ExerciseUtils.TimedMessage(textMeshUI, $"Score should now be 5...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, $"Current Score: {getScoreMethodInfo.Invoke(exercise, new object[] { })}", ref timer);

            if ((int)getScoreMethodInfo.Invoke(exercise, new object[] { }) != 5) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer, color: ExerciseUtils.COLOR_WARNING);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Trying to directly set score = 12", ref timer);

            FieldInfo scoreFieldInfo = typeof(Exercise).GetField("score", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (scoreFieldInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'score' field!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!scoreFieldInfo.IsPrivate) {
                ExerciseUtils.TimedMessage(textMeshUI, "Was able to directly change score, this should not happen!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "Score should be private and only accessible by that class!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Correctly was unable to directly change score!", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
