using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1200_AccessModifiers {


    public class Exercise : MonoBehaviour {

        // This class is meant to handle the game score
        // Other classes should only be able to Add score, not set it to anything.

        // Don't modify the names and logic, only change the access modifiers

        private int score;


        public void AddScore(int addAmount) {
            score += addAmount;
        }

        public int GetScore() {
            return score;
        }

    }

}
