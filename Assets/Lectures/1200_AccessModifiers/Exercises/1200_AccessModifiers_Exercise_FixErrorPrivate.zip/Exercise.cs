using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* COMPILATION BLOCKER
namespace CodeMonkey.CSharpCourse.L1200_AccessModifiers {


    public class Exercise : MonoBehaviour {


        private void Start() {
            Player player = new Player();
            // Fix this error, cannot access function
            player.DoSomething();
        }


        public class Player {

            void DoSomething() {
                // Do something
            }

        }


    }

}
COMPILATION BLOCKER */