using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1200_AccessModifiers {


    public class ExerciseSceneTester : MonoBehaviour {


        private const int SPEED_TO_SET = 56;

        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            textMeshUI.text = "Looking for 'speed' field...\n";
            FunctionTimer.Create(FindSpeedField, 1f);
        }

        private void FindSpeedField() {
            FieldInfo speedFieldInfo = typeof(Exercise).GetField("speed", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (speedFieldInfo != null) {
                // Found 'speed' field
                ExerciseUtils.TimedMessage(textMeshUI, "Found 'speed' field...", .5f * 1);
                // Is it private?
                if (speedFieldInfo.IsPrivate) {
                    ExerciseUtils.TimedMessage(textMeshUI, "It is correctly private...", .5f * 2);
                    // It's private
                    if (speedFieldInfo.FieldType == typeof(int)) {
                        // It's an int
                        // Field is completely correct
                        ExerciseUtils.TimedMessage(textMeshUI, "It is correctly of type int!\n", .5f * 3);

                        ExerciseUtils.TimedMessage(textMeshUI, "Looking for SetSpeed() function...", .5f * 4);
                        FunctionTimer.Create(FindSetSpeedMethod, .5f * 5);
                    } else {
                        textMeshUI.text += "'speed' field is not an int!\n";
                        textMeshUI.text += ExerciseUtils.INCORRECT;
                    }
                } else {
                    // Not private
                    textMeshUI.text += "'speed' field is not private!\n";
                    textMeshUI.text += ExerciseUtils.INCORRECT;
                }
            } else {
                // Did not find 'speed' field
                textMeshUI.text += "Did not find 'speed' field!\n";
                textMeshUI.text += ExerciseUtils.INCORRECT;
            }
        }

        private void FindSetSpeedMethod() {
            MethodInfo setSpeedMethodInfo = typeof(Exercise).GetMethod("SetSpeed", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (setSpeedMethodInfo != null) {
                // Found function SetSpeed();
                textMeshUI.text += "Found SetSpeed() function...\n";
                if (setSpeedMethodInfo.IsPublic) {
                    // It's public
                    textMeshUI.text += "It's correctly public...\n";
                    if (setSpeedMethodInfo.ReturnType == typeof(void)) {
                        // Correctly returns void
                        textMeshUI.text += "It correctly returns void...\n";
                        if (setSpeedMethodInfo.GetParameters().Length == 1 && setSpeedMethodInfo.GetParameters()[0].ParameterType == typeof(int)) {
                            // Correctly has one parameter of type int
                            // Everything is correct, call it
                            textMeshUI.text += "It has one parameter of type int...\n";
                            textMeshUI.text += "Function completely correct!\n\n";
                            setSpeedMethodInfo.Invoke(exercise, new object[] { SPEED_TO_SET });
                            textMeshUI.text += "Calling function with value " + SPEED_TO_SET + "...\n";
                            textMeshUI.text += "Looking for GetSpeed(); function...\n";
                            FunctionTimer.Create(FindGetSpeedMethod, 1f);
                        } else {
                            // Function has no parameters or more than one or not correct type
                            textMeshUI.text += "Function has no parameters or more than one or not correct type!\n";
                            textMeshUI.text += ExerciseUtils.INCORRECT;
                        }
                    } else {
                        // Function does not return void
                        textMeshUI.text += "Function does not return void\n";
                        textMeshUI.text += ExerciseUtils.INCORRECT;
                    }
                } else {
                    // Function is not public
                    textMeshUI.text += "Function is not public\n";
                    textMeshUI.text += ExerciseUtils.INCORRECT;
                }
            } else {
                // Did not find function SetSpeed();
                textMeshUI.text += "Did not find function SetSpeed();\n";
                textMeshUI.text += ExerciseUtils.INCORRECT;
            }
        }

        private void FindGetSpeedMethod() {
            MethodInfo getSpeedMethodInfo = typeof(Exercise).GetMethod("GetSpeed", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (getSpeedMethodInfo != null) {
                // Found function GetSpeed();
                textMeshUI.text += "Found GetSpeed() function...\n";
                if (getSpeedMethodInfo.IsPublic) {
                    // It's public
                    textMeshUI.text += "It is correctly public...\n";
                    if (getSpeedMethodInfo.ReturnType == typeof(int)) {
                        textMeshUI.text += "It correctly returns int...\n";
                        if (getSpeedMethodInfo.GetParameters().Length == 0) {
                            // Correctly has no parameters
                            // Everything is correct, call it
                            textMeshUI.text += "It correctly has no parameters...\n";
                            textMeshUI.text += "GetSpeed() function is fully correct!\n";
                            int speed = (int)getSpeedMethodInfo.Invoke(exercise, null);

                            textMeshUI.text += "Comparing GetSpeed() return to SetSpeed("+SPEED_TO_SET+");...\n";
                            FunctionTimer.Create(() => {
                                if (speed == SPEED_TO_SET) {
                                    // Correctly got same speed that was set
                                    textMeshUI.text += ExerciseUtils.SUCCESS;
                                    ExerciseCompletionTester.ExerciseCompleted();
                                } else {
                                    textMeshUI.text += "Did not get the same speed to what it was set to!\n";
                                    textMeshUI.text += ExerciseUtils.INCORRECT;
                                }
                            }, 1f);
                        } else {
                            // Function has no parameters or more than one
                            textMeshUI.text += "Function has no parameters or more than one\n";
                            textMeshUI.text += ExerciseUtils.INCORRECT;
                        }
                    } else {
                        // Return type is not int
                        textMeshUI.text += "Return type is not int\n";
                        textMeshUI.text += ExerciseUtils.INCORRECT;
                    }
                } else {
                    // Function is not public
                    textMeshUI.text += "Function is not public\n";
                    textMeshUI.text += ExerciseUtils.INCORRECT;
                }
            } else {
                // Did not find function SetSpeed();
                textMeshUI.text += "Did not find function SetSpeed();\n";
                textMeshUI.text += ExerciseUtils.INCORRECT;
            }
        }


    }

}
