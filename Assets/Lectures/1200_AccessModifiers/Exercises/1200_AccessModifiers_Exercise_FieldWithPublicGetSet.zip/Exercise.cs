using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1200_AccessModifiers {


    public class Exercise : MonoBehaviour {

        // Define a private int field for 'speed' and then 2 public functions to Get and Set that field




    }

}
