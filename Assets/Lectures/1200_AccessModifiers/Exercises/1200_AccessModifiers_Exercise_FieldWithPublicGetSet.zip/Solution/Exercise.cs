using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1200_AccessModifiers {


    public class Exercise : MonoBehaviour {

        // Define a private field for 'speed' and then 2 public functions to Get and Set that field


        private int speed;


        public int GetSpeed() {
            return speed;
        }

        public void SetSpeed(int speed) {
            this.speed = speed;
        }

    }

}
