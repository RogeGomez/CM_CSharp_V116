using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2180_SwitchPatternMatching {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, $"...", ref timer, add: false);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("2180", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find Exercise.cs!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!lectureText.Contains("switch")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find a 'switch' in the code!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found 'switch' in the code...", ref timer);

            if (lectureText.Contains("unit is")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Code still contains an 'is' statement! Use switch instead!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            Exercise.Player player = new Exercise.Player();
            Exercise.Enemy enemy = new Exercise.Enemy();
            Exercise.NPC npc = new Exercise.NPC();
            Exercise.Unit unit = new Exercise.Unit();

            ExerciseUtils.TimedMessage(textMeshUI, $"Calling GetUnitType() with Player", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, $"Output: {exercise.GetUnitType(player)}, expected IsPlayer", ref timer);

            if (exercise.GetUnitType(player) != Exercise.UnitType.IsPlayer) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Calling GetUnitType() with Enemy", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, $"Output: {exercise.GetUnitType(enemy)}, expected IsEnemy", ref timer);

            if (exercise.GetUnitType(enemy) != Exercise.UnitType.IsEnemy) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Calling GetUnitType() with NPC", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, $"Output: {exercise.GetUnitType(npc)}, expected IsNPC", ref timer);

            if (exercise.GetUnitType(npc) != Exercise.UnitType.IsNPC) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Calling GetUnitType() with Unit", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, $"Output: {exercise.GetUnitType(unit)}, expected IsUnit", ref timer);

            if (exercise.GetUnitType(unit) != Exercise.UnitType.IsUnit) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
