using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2180_SwitchPatternMatching {


    public class Exercise : MonoBehaviour {


        // Edit this function to check the type of 'unit' and return the correct UnitType
        public UnitType GetUnitType(Unit unit) {
            switch (unit) {
                default:
                    return UnitType.IsUnit;
                case Player _:
                    return UnitType.IsPlayer;
                case Enemy _:
                    return UnitType.IsEnemy;
                case NPC _:
                    return UnitType.IsNPC;
            }
        }


        public enum UnitType {
            IsUnit,
            IsPlayer,
            IsEnemy,
            IsNPC,
        }

        public class Unit { }

        public class Player : Unit { }

        public class Enemy : Unit { }

        public class NPC : Unit { }


    }

}
