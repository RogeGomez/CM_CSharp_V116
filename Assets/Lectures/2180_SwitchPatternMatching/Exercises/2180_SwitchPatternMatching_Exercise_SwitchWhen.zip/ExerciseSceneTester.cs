using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2180_SwitchPatternMatching {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private bool playerLowHealth;
        private bool enemyDead;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, $"...", ref timer, add: false);

            Exercise exercise = new Exercise();
            Exercise.Player player = new Exercise.Player();
            Exercise.Enemy enemy = new Exercise.Enemy();

            if (!ExerciseUtils.TryGetLectureExerciseCSText("2180", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find Exercise.cs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!lectureText.Contains("switch")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find a 'switch' in the code!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!lectureText.Contains("when")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find a 'when' in the code!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found 'switch' and 'when' in the code...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestUnit() with a Player with health = 100...", ref timer);

            exercise.TestUnit(new Exercise.Player { health = 100 });

            if (playerLowHealth) {
                ExerciseUtils.TimedMessage(textMeshUI, "Incorrectly called PlayerLowHealth()!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Correctly handled that case...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestUnit() with a Player with health = 20...", ref timer);

            exercise.TestUnit(new Exercise.Player { health = 20 });

            if (!playerLowHealth) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not call PlayerLowHealth()!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Correctly called PlayerLowHealth()...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestUnit() with a Enemy with health = 0...", ref timer);

            exercise.TestUnit(new Exercise.Enemy { health = 0 });

            if (!enemyDead) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not call EnemyDead()!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Correctly called EnemyDead()...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void PlayerLowHealth() {
            playerLowHealth = true;
        }

        public void EnemyDead() {
            enemyDead = true;
        }

    }

}
