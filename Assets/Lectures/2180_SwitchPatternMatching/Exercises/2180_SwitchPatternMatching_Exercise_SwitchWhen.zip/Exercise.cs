using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2180_SwitchPatternMatching {


    public class Exercise {


        // Do a switch on Unit, use the 'when' clause to test
        // if it's a player with health < 50, if so call PlayerLowHealth();
        // and if it's an enemy with health == 0 call EnemyDead();
        public void TestUnit(Unit unit) {

        }



        private void PlayerLowHealth() {
            ExerciseSceneTester.Instance.PlayerLowHealth();
        }

        private void EnemyDead() {
            ExerciseSceneTester.Instance.EnemyDead();
        }


        public class Unit { }

        public class Player : Unit {
            public int health;
        }

        public class Enemy : Unit {
            public int health;
        }

        public class NPC : Unit { }


    }

}
