using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3120_NullCoalescingOperators {


    public class Exercise {




        public void PrintValues(List<int> intList) {
            // Use the null-coalescing operator to check if the list is null and if so initialize it
            intList ??= new List<int>();

            foreach (int i in intList) {
                Debug.Log(i);
            }
        }




    }



}