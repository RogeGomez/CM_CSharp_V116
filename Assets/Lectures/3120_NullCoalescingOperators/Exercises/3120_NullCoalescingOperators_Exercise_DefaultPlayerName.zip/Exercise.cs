using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3120_NullCoalescingOperators {


    public class Exercise {


        private string playerName;


        public string GetPlayerName() {
            // Modify this code to use the null-coalescing operator to return either the playerName or "Unknown"
            return playerName;
        }


        public void SetPlayerName(string playerName) {
            this.playerName = playerName;
        }


    }



}