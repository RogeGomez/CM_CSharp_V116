using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3120_NullCoalescingOperators {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("3120", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not read Exercise.cs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for ?? in the code...", ref timer);

            if (!lectureText.Contains("??")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find ?? in the code!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found ??...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling GetColorString(null, null)...", ref timer);

            Exercise exercise = new Exercise();

            ExerciseUtils.TimedMessage(textMeshUI, $"Got: {exercise.GetColorString(null, null)}, expected: Green...", ref timer);

            if (exercise.GetColorString(null, null) != "Green") {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "Calling GetColorString(null, 'Blue')...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, $"Got: {exercise.GetColorString(null, "Blue")}, expected: Blue...", ref timer);

            if (exercise.GetColorString(null, "Blue") != "Blue") {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "Calling GetColorString('Red', 'Blue')...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, $"Got: {exercise.GetColorString("Red", "Blue")}, expected: Red...", ref timer);

            if (exercise.GetColorString("Red", "Blue") != "Red") {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }




            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }


    }

}
