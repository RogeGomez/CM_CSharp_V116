using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3120_NullCoalescingOperators {


    public class Exercise {


        private string defaultColor = "Green";


        public string GetColorString(string primaryColor, string secondaryColor) {
            // Chain multiple null-coalescing operators to return primaryColor or secondaryColor or defaultColor
            return primaryColor ?? secondaryColor ?? defaultColor;
        }




    }



}