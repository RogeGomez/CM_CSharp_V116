using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2220_Generics {


    public class Exercise {


        // Define a generic class, ObjectFactory<T> that inside has a function T CreateObject(); which returns new T();
        



        // Don't modify this code
        public class Player { }


    }

}
