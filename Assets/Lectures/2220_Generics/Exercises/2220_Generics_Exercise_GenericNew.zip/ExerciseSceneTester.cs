using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2220_Generics {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for nested class ObjectFactory...", ref timer, add: false);

            Type objectFactoryType = null;
            foreach (Type type in typeof(Exercise).GetNestedTypes(BindingFlags.Public | BindingFlags.NonPublic)) {
                if (type.IsGenericType) {
                    objectFactoryType = type;
                }
            }

            if (objectFactoryType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find generic type!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Found {objectFactoryType.Name} type...", ref timer);

            if (objectFactoryType.GetGenericArguments().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "Type does not have exactly 1 generic Type!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            GenericParameterAttributes genericParameterAttributes = objectFactoryType.GetGenericArguments()[0].GenericParameterAttributes;
            if (!((genericParameterAttributes & GenericParameterAttributes.DefaultConstructorConstraint) != 0)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Class does not have the new() constraint!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Class correctly has the new() constraint...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for function CreateObject inside type...", ref timer);

            MethodInfo createObjectMethodInfo = objectFactoryType.GetMethod("CreateObject", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (createObjectMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find function CreateObject!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found CreateObject function...\n", ref timer);



            ExerciseUtils.TimedMessage(textMeshUI, "Constructing ObjectFactory<Player>()...", ref timer);

            Type objectFactoryPlayerType = objectFactoryType.MakeGenericType(typeof(Exercise.Player));
            createObjectMethodInfo = objectFactoryPlayerType.GetMethod("CreateObject", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            object objectFactoryPlayer = Activator.CreateInstance(objectFactoryPlayerType);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling CreateObject()...", ref timer);

            object createdObject = createObjectMethodInfo.Invoke(objectFactoryPlayer, new object[] { });

            if (createdObject == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Function returned null!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Function correctly created an object...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "All correct!", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}




