using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2220_Generics {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
        }

        public void ExerciseValidate(object boxAObject, object boxBObject) {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for generic type...", ref timer);
            Type boxType = null;
            foreach (Type type in typeof(Exercise).GetNestedTypes(BindingFlags.Public | BindingFlags.NonPublic)) {
                if (type.IsGenericType) {
                    boxType = type;
                }
            }

            if (boxType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find generic 'Box' type!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "Did you define the 'Box' class? Did you make it generic?", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Found {boxType.Name}...", ref timer);


            if (boxAObject.GetType().GetGenericTypeDefinition() != boxType) {
                ExerciseUtils.TimedMessage(textMeshUI, "First parameter object is not of type 'Box'!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "First parameter object is correctly of type 'Box'...", ref timer);

            if (boxBObject.GetType().GetGenericTypeDefinition() != boxType) {
                ExerciseUtils.TimedMessage(textMeshUI, "Second parameter object is not of type 'Box'!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Second parameter object is correctly of type 'Box'...", ref timer);

            Type boxASubType = boxAObject.GetType().GetGenericArguments()[0];
            if (boxASubType != typeof(Exercise.Weapon)) {
                ExerciseUtils.TimedMessage(textMeshUI, "First parameter object is not of type 'Box<Weapon>'!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "First parameter object is correctly of type 'Box<Weapon>'...", ref timer);

            Type boxBSubType = boxBObject.GetType().GetGenericArguments()[0];
            if (boxBSubType != typeof(Exercise.Potion)) {
                ExerciseUtils.TimedMessage(textMeshUI, "First parameter object is not of type 'Box<Potion>'!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Second parameter object is correctly of type 'Box<Potion>'...", ref timer);


            MethodInfo putWeaponMethodInfo = boxAObject.GetType().GetMethod("Put", BindingFlags.Public | BindingFlags.Instance);
            if (putWeaponMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find Put() function!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found Put() function...", ref timer);

            if (putWeaponMethodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "Put() function does not have one parameter!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            Exercise.Weapon weapon = new Exercise.Weapon();

            ExerciseUtils.TimedMessage(textMeshUI, "Putting weapon in box with Put()...", ref timer);
            putWeaponMethodInfo.Invoke(boxAObject, new object[] { weapon });



            ExerciseUtils.TimedMessage(textMeshUI, "Found Get() function...", ref timer);

            MethodInfo getWeaponMethodInfo = boxAObject.GetType().GetMethod("Get", BindingFlags.Public | BindingFlags.Instance);
            if (getWeaponMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find Get() function!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (getWeaponMethodInfo.GetParameters().Length != 0) {
                ExerciseUtils.TimedMessage(textMeshUI, "Get() function has more than zero parameters!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (getWeaponMethodInfo.ReturnType != typeof(Exercise.Weapon)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Get() function does not return Weapon!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Grabbing weapon with Get() function...", ref timer);

            Exercise.Weapon grabbedWeapon = (Exercise.Weapon)getWeaponMethodInfo.Invoke(boxAObject, new object[] { });

            if (weapon != grabbedWeapon) {
                ExerciseUtils.TimedMessage(textMeshUI, "Grabbed Get() weapon does not match Put() weapon!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "All correct!", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}




