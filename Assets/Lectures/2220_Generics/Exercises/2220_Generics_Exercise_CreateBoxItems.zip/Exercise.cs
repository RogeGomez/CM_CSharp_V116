using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2220_Generics {


    public class Exercise : MonoBehaviour {


        // Define a class Box<T> that can store an item of type T
        // In that class, implement a Put() and Get() that can store and get an item from the box




        private void Start() {
            // Create two instances of Box, one for Weapon, and one for Potion



            // Then pass in those objects to ExerciseValidate();

            //ExerciseValidate(weaponBox, potionBox);
        }

        private void ExerciseValidate(object weaponBoxObject, object potionBoxObject) {
            ExerciseSceneTester.Instance.ExerciseValidate(weaponBoxObject, potionBoxObject);
        }



        // Don't modify these classes, used for testing
        public class Weapon { }
        public class Potion { }

    }

}
