using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2220_Generics {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private string lastMessage;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for function PrintObject...", ref timer, add: false);

            MethodInfo printObjectMethodInfo = typeof(Exercise).GetMethod("PrintObject", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (printObjectMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find function PrintObject!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found PrintObject function...", ref timer);

            if (!printObjectMethodInfo.IsGenericMethod) {
                ExerciseUtils.TimedMessage(textMeshUI, "Function is not Generic!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (printObjectMethodInfo.GetGenericArguments().Length != 2) {
                ExerciseUtils.TimedMessage(textMeshUI, "Function does not have 2 Generic types!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (printObjectMethodInfo.GetParameters().Length != 2) {
                ExerciseUtils.TimedMessage(textMeshUI, "Function does not have 2 parameters!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Function correctly has 2 Generic types...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling function with <int, bool>{ 1, true }...", ref timer);

            Exercise exercise = new Exercise();

            Application.logMessageReceived += Application_logMessageReceived;

            MethodInfo printObjectGenericMethodInfo = printObjectMethodInfo.MakeGenericMethod(typeof(int), typeof(bool));
            printObjectGenericMethodInfo.Invoke(exercise, new object[] { 1, true });

            Application.logMessageReceived -= Application_logMessageReceived;

            ExerciseUtils.TimedMessage(textMeshUI, "Log Message: " + lastMessage + ", expected: 1 True...", ref timer);

            if (lastMessage != "1 True") {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "All correct!", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        private void Application_logMessageReceived(string condition, string stackTrace, LogType type) {
            lastMessage = condition;
        }

    }

}




