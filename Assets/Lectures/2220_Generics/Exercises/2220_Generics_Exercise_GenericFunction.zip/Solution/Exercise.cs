using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2220_Generics {


    public class Exercise {


        // Define a generic function, PrintObject<T1, T2> that takes those types as parameters and does a Debug.Log(t1 + " " + t2);
        public void PrintObject<T1, T2>(T1 t1, T2 t2) {
            Debug.Log(t1 + " " + t2);
        }



    }

}
