using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3140_MainCommandLineArgs {


    public class Exercise {

        // Modify this function to make it a valid Main function that receives arguments and returns an exit code
        public void Main() {

        }

    }

}
