using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using System.Reflection;

namespace CodeMonkey.CSharpCourse.L3140_MainCommandLineArgs {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            Exercise exercise = new Exercise();
            MethodInfo methodInfo = typeof(Exercise).GetMethod("Main", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static);

            if (methodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Did not find a Main function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Found Main function...", ref timer);


            if (!methodInfo.IsStatic) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Main function is not static!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, $"Main function is correctly static...", ref timer);


            if (methodInfo.ReturnType != typeof(int)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Main function does not return int!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Main correctly returns int...", ref timer);

            if (methodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Main function does not have a parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, $"Main correctly has one parameter...", ref timer);

            if (methodInfo.GetParameters()[0].ParameterType != typeof(string[])) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Main function parameter is not string[]!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, $"Parameter is correctly string[]...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, $"Calling Main(\"Code Monkey\")...", ref timer);
            int returnInt = (int)methodInfo.Invoke(exercise, new object[] { new string[] { "Code Monkey" } });

            ExerciseUtils.TimedMessage(textMeshUI, $"Got return {returnInt}, expected {0}...", ref timer);
            if (returnInt != 0) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, $"Calling Main(\"add\", \"12\")...", ref timer);
            returnInt = (int)methodInfo.Invoke(exercise, new object[] { new string[] { "add", "12" } });

            ExerciseUtils.TimedMessage(textMeshUI, $"Got return {returnInt}, expected {22}...", ref timer);
            if (returnInt != 22) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
