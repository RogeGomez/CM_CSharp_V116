using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3140_MainCommandLineArgs {


    public class Exercise {


        public static int Main(string[] args) {
            if (args.Length > 0) {
                if (args[0] == "Code Monkey") {
                    return 0;
                }
            }
            if (args.Length > 1) {
                if (args[0] == "add") {
                    int number = int.Parse(args[1]);
                    return number + 10;
                }
            }
            return 0;
        }

    }

}
