using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3260_Tuples {


    public class Exercise {

        // Create a function GetPlayerData(); that returns a tuple with a string playerName and an int healthAmount.
        public (string playerName, int healthAmount) GetPlayerData() {
            return ("Code Monkey", 56);
        }

    }

}
