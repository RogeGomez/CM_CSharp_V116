using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3260_Tuples {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            MethodInfo getPlayerDataMethodInfo =
                typeof(Exercise).GetMethod("GetPlayerData", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for GetPlayerData function...", ref timer);
            if (getPlayerDataMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find GetPlayerData function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Found GetPlayerData function...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Checking return type...", ref timer);
            if (getPlayerDataMethodInfo.ReturnType != typeof(ValueTuple<string, int>)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"GetPlayerData function does not return (string, int)!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Function correctly returns (string, int)...", ref timer);

            ValueTuple<string, int> returnData = (ValueTuple<string, int>)getPlayerDataMethodInfo.Invoke(new Exercise(), null);

            ExerciseUtils.TimedMessage(textMeshUI, $"Tuple data: ({returnData.Item1}, {returnData.Item2})...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
