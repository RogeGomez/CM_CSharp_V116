using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3230_ClassIndexer {


    public class PlayerStats {


        // Implement the class indexer in the PlayerStats class
        // Make it return str on index 0, wis on index 1 and dex on index 2
        // And also implement the 'set' to write to those values.

        public PlayerStats(int str, int wis, int dex) {
            this.str = str;
            this.wis = wis;
            this.dex = dex;
        }

        public int this[int index] {
            get {
                switch (index) {
                    default:
                    case 0: return str;
                    case 1: return wis;
                    case 2: return dex;
                }
            }
            set {
                switch (index) {
                    case 0: str = value; break;
                    case 1: wis = value; break;
                    case 2: dex = value; break;
                }
            }
        }

        private int str;
        private int wis;
        private int dex;


    }

}
