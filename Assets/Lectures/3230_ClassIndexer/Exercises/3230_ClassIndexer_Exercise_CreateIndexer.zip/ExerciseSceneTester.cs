using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3230_ClassIndexer {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            PropertyInfo[] propertyInfoArray = typeof(PlayerStats).GetProperties();

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for class indexer...", ref timer);

            PropertyInfo indexerPropertyInfo = null;
            foreach (PropertyInfo propertyInfo in propertyInfoArray) {
                if (propertyInfo.GetIndexParameters().Length > 0) {
                    indexerPropertyInfo = propertyInfo;
                }
            }

            if (indexerPropertyInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find a class indexer!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Found class indexer...", ref timer);

            if (indexerPropertyInfo.GetMethod == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Property has no 'get'!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Has 'get'...", ref timer);

            if (indexerPropertyInfo.SetMethod == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Property has no 'set'!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Has 'set'...", ref timer);



            ExerciseUtils.TimedMessage(textMeshUI, "Creating new PlayerStats(12, 56, 32)...", ref timer);
            PlayerStats playerStats = new PlayerStats(12, 56, 32);

            ExerciseUtils.TimedMessage(textMeshUI, "Getting indexer with index 0...", ref timer);
            int value = (int)indexerPropertyInfo.GetMethod.Invoke(playerStats, new object[] { 0 });
            ExerciseUtils.TimedMessage(textMeshUI, $"Got {value}, expected 12", ref timer);

            if (value != 12) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "Setting indexer with index 2 to 99...", ref timer);
            indexerPropertyInfo.SetMethod.Invoke(playerStats, new object[] { 2, 99 });


            ExerciseUtils.TimedMessage(textMeshUI, "Getting indexer with index 2...", ref timer);
            value = (int)indexerPropertyInfo.GetMethod.Invoke(playerStats, new object[] { 2 });
            ExerciseUtils.TimedMessage(textMeshUI, $"Got {value}, expected 99", ref timer);

            if (value != 99) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
