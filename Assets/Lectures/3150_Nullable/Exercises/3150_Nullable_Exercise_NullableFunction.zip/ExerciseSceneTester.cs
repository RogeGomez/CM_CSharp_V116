using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3150_Nullable {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            Exercise exercise = new Exercise();

            MethodInfo hasAttackDamageMethodInfo = 
                typeof(Exercise).GetMethod("HasAttackDamage", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (hasAttackDamageMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find HasAttackDamage function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, $"Found HasAttackDamage function...", ref timer);

            if (hasAttackDamageMethodInfo.ReturnType != typeof(bool)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"HasAttackDamage does not return bool!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, $"HasAttackDamage correctly returns bool...", ref timer);

            if (hasAttackDamageMethodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, $"HasAttackDamage does not have 1 parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (hasAttackDamageMethodInfo.GetParameters()[0].ParameterType != typeof(int?)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"HasAttackDamage does not have a int? parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, $"HasAttackDamage correctly has int? parameter...", ref timer);

            bool returnBool;
            returnBool = (bool)hasAttackDamageMethodInfo.Invoke(exercise, new object[] { null });
            ExerciseUtils.TimedMessage(textMeshUI, $"Calling HasAttackDamage(null)...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, $"Got {returnBool}, expected False...", ref timer);

            if (returnBool != false) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            returnBool = (bool)hasAttackDamageMethodInfo.Invoke(exercise, new object[] { 0 });
            ExerciseUtils.TimedMessage(textMeshUI, $"Calling HasAttackDamage(0)...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, $"Got {returnBool}, expected False...", ref timer);

            if (returnBool != false) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            returnBool = (bool)hasAttackDamageMethodInfo.Invoke(exercise, new object[] { 56 });
            ExerciseUtils.TimedMessage(textMeshUI, $"Calling HasAttackDamage(56)...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, $"Got {returnBool}, expected True...", ref timer);

            if (returnBool != true) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
