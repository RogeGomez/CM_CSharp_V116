using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3150_Nullable {


    public class Exercise {


        // Define a bool HasAttackDamage function
        // It should receive an int? for a attackDamage
        // When the function is called with null it should return false
        // When it has a value > 0 it should return true.
        


    }

}
