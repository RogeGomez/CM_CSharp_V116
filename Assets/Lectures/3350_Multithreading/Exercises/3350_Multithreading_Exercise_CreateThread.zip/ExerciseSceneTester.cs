using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3350_Multithreading {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private BlockingCollection<bool> blockingCollection = new BlockingCollection<bool>();
        private List<float> timerList = new List<float>();


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling Main()...", ref timer);
            Exercise exercise = new Exercise();
            exercise.Main();
            ProcessTimers();

            FunctionTimer.Create(() => {
                timer = 0f;
                if (timerList.Count != 5) {
                    ExerciseUtils.TimedMessage(textMeshUI, $"Did not receive 5 function calls as expected!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }
                ExerciseUtils.TimedMessage(textMeshUI, $"Got all timers...", ref timer);

                float firstTimer = timerList[0];
                float lastTimer = timerList[timerList.Count - 1];

                ExerciseUtils.TimedMessage(textMeshUI, $"\n", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, $"First Timer: {firstTimer}", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, $"Last Timer: {lastTimer}", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, $"Time Elapsed: {lastTimer - firstTimer}", ref timer);

                if (lastTimer - firstTimer > 2f) {
                    ExerciseUtils.TimedMessage(textMeshUI, $"Too long elapsed!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }
                ExerciseUtils.TimedMessage(textMeshUI, $"Fast timer means code was correctly multithreaded...", ref timer);


                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
                FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
            }, timer + 1.5f);
        }

        private void Update() {
            ProcessTimers();
        }

        private void ProcessTimers() {
            while (blockingCollection.Count > 0) {
                blockingCollection.Take();
                ExerciseUtils.TimedMessage(textMeshUI, $"Timer Worker Thread: {Time.realtimeSinceStartup}...", ref timer);
                timerList.Add(Time.realtimeSinceStartup);
            }
        }

        public void ExerciseValidateWorkerThread() {
            blockingCollection.Add(true);
        }

        public void ExerciseValidateMainThread() {
            ExerciseUtils.TimedMessage(textMeshUI, $"Timer Main Thread: {Time.realtimeSinceStartup}...", ref timer);
            timerList.Add(Time.realtimeSinceStartup);
        }

    }

}
