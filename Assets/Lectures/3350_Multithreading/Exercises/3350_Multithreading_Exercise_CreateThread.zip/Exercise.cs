using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3350_Multithreading {


    public class Exercise {


        // Create 3 Threads that run the ExerciseValidateWorkerThread(); function
        // Then call .Start(); and .Join(); on all of them it and finally call ExerciseValidateMainThread();
        public void Main() {
            // Leave this main thread function before
            ExerciseValidateMainThreadBefore();

            // Refactor this for to run the function on 3 Threads, not on the main thread
            int threadCount = 3;
            for (int i = 0; i < threadCount; i++) {
                ExerciseValidateWorkerThread();
            }

            // Leave this main thread function after
            ExerciseValidateMainThreadAfter();
        }


        private void ExerciseValidateWorkerThread() {
            Thread.Sleep(1000);
            ExerciseSceneTester.Instance.ExerciseValidateWorkerThread();
        }

        private void ExerciseValidateMainThreadBefore() {
            ExerciseSceneTester.Instance.ExerciseValidateMainThread();
        }

        private void ExerciseValidateMainThreadAfter() {
            ExerciseSceneTester.Instance.ExerciseValidateMainThread();
        }

    }

}
