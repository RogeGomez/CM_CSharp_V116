using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3350_Multithreading {


    public class Exercise {


        // Create 3 Threads that run the ExerciseValidateWorkerThread(); function
        // Then call .Start(); and .Join(); on all of them it and finally call ExerciseValidateMainThread();
        public void Main() {
            // Leave this main thread function before
            ExerciseValidateMainThreadBefore();

            // Refactor this for to run the function on 3 Threads, not on the main thread
            int threadCount = 3;
            Thread[] threadArray = new Thread[threadCount];

            for (int i = 0; i < threadArray.Length; i++) {
                threadArray[i] = new Thread(ExerciseValidateWorkerThread);
            }
            for (int i = 0; i < threadArray.Length; i++) {
                threadArray[i].Start();
            }
            for (int i = 0; i < threadArray.Length; i++) {
                threadArray[i].Join();
            }

            // Leave this main thread function after
            ExerciseValidateMainThreadAfter();
        }


        private void ExerciseValidateWorkerThread() {
            Thread.Sleep(1000);
            ExerciseSceneTester.Instance.ExerciseValidateWorkerThread();
        }

        private void ExerciseValidateMainThreadBefore() {
            ExerciseSceneTester.Instance.ExerciseValidateMainThread();
        }

        private void ExerciseValidateMainThreadAfter() {
            ExerciseSceneTester.Instance.ExerciseValidateMainThread();
        }

    }

}
