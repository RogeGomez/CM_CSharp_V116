using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3030_FunctionExtensions {

    // Write a Transform function extension named MoveRight();
    public static class TransformExtensions {

        public static void MoveRight(this Transform transform) {
            // ...
        }

    }


    public class Exercise {


        public void TextExercise(Transform transform) {
            // Use the MoveRight function extension on this transform
            transform.MoveRight();
        }


    }



}