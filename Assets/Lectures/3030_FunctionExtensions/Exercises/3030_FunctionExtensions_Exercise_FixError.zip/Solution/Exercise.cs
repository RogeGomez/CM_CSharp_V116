using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3030_FunctionExtensions {


    public class Exercise {


        public void TextExercise(int speed) {
            // Fix the error
            speed = speed.Double();
        }


    }

    public static class IntExtensions {

        public static int Double(this int i) {
            return i * 2;
        }

    }



}