using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

/* COMPILATION BLOCKER
namespace CodeMonkey.CSharpCourse.L3030_FunctionExtensions {


    public class Exercise {


        public void TextExercise(int speed) {
            // Fix the error
            speed = speed.Double();
        }


    }

    public class IntExtensions {

        public static int Double(int i) {
            return i * 2;
        }

    }



}
COMPILATION BLOCKER */