using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2070_NestedLoops {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;

        private struct Iteration {
            public int i;
            public int j;
        }

        private List<Iteration> iterationList;
        private int maxI;
        private int maxJ;
        private float timer;


        private void Awake() {
            Instance = this;

            iterationList = new List<Iteration>();
            timer = 0f;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting for function call...\n", ref timer, add: false);
        }

        private void Start() {

            FunctionTimer.Create(() => {
                ExerciseUtils.TimedMessage(textMeshUI, "Total iterations = " + iterationList.Count + ", expected: " + (3 * 2) + "\n", ref timer);
                if (iterationList.Count != 3 * 2) {
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "max i = " + maxI + ", expected: " + 3 + "\n", ref timer);
                if (maxI != 3) {
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "max j = " + maxJ + ", expected: " + 2 + "\n", ref timer);
                if (maxJ != 2) {
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
                FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
            }, .01f);
        }

        public void ExerciseValidate(int i, int j) {
            ExerciseUtils.TimedMessage(textMeshUI, i + ", " + j, ref timer);
            iterationList.Add(new Iteration {
                i = i,
                j = j,
            });
            maxI = Mathf.Max(maxI, i + 1);
            maxJ = Mathf.Max(maxJ, j + 1);
        }

    }

}
