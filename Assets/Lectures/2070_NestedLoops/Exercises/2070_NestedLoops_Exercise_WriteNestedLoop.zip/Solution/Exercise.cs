using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2070_NestedLoops {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Write your nested loops inside this Start function
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 2; j++) {
                    ExerciseValidate(i, j);
                }
            }

        }


        public void ExerciseValidate(int i, int j) {
            ExerciseSceneTester.Instance.ExerciseValidate(i, j);
        }

    }

}
