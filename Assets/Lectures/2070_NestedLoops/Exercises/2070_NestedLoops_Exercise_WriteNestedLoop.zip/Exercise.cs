using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2070_NestedLoops {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // Write your nested loops inside this Start function


        }


        public void ExerciseValidate(int i, int j) {
            ExerciseSceneTester.Instance.ExerciseValidate(i, j);
        }

    }

}
