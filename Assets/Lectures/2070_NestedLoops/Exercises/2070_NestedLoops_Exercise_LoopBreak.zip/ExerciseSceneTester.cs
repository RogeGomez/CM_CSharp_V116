using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2070_NestedLoops {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private struct GridPositionXY {
            public int i;
            public int j;
            public Exercise.GridPosition gridPosition;
        }


        private bool isCorrect = true;
        private List<GridPositionXY> gridPositionXYList = new List<GridPositionXY>();


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for break;...", ref timer, add: false);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("2070", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Cannot read code file!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!lectureText.Contains("break")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not find break;!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found break;...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling CycleElements()...", ref timer);

            Exercise exercise = new Exercise();

            exercise.CycleElements();

            if (gridPositionXYList.Count != 4) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not run ExerciseValidate() 4 times as expected!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (isCorrect) {
                ExerciseUtils.TimedMessage(textMeshUI, "Correctly skipped [1, 2: Enemy]", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
                FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
            }
        }

        public void ExerciseValidate(int i, int j, Exercise.GridPosition gridPosition) {
            if (gridPosition == Exercise.GridPosition.Empty) {
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, i + ", " + j + ": " + gridPosition, ref timer);
            gridPositionXYList.Add(new GridPositionXY {
                i = i,
                j = j,
                gridPosition = gridPosition,
            });
            if (i == 1 && j == 2 && gridPosition == Exercise.GridPosition.Enemy) {
                ExerciseUtils.TimedMessage(textMeshUI, "Should NOT have cycled through this element!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                isCorrect = false;
            }
        }

    }

}
