using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2070_NestedLoops {


    public class Exercise {


        public enum GridPosition {
            Empty,
            Player,
            Enemy,
            Crate,
        }


        public void CycleElements() {
            // Don't modify this code
            GridPosition[,] gridPosition2DArray = new GridPosition[3, 3];
            gridPosition2DArray[0, 0] = GridPosition.Crate;
            gridPosition2DArray[1, 0] = GridPosition.Enemy;
            gridPosition2DArray[1, 1] = GridPosition.Player;
            gridPosition2DArray[1, 2] = GridPosition.Enemy;
            gridPosition2DArray[2, 1] = GridPosition.Crate;

            // Cycle through the array on both dimensions, call ExerciseValidate(); for each cycle
            // And break; if the GridPosition is Player

        }

        private void ExerciseValidate(int i, int j, GridPosition gridPosition) {
            ExerciseSceneTester.Instance.ExerciseValidate(i, j, gridPosition);

        }

    }

}
