using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2070_NestedLoops {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Calling GetSumOfAllElements(new int[][] { new int[] { 1 }, new int[] { 2 } })...", ref timer, add: false);

            Exercise exercise = new Exercise();

            ExerciseUtils.TimedMessage(textMeshUI, "Result: " + exercise.GetSumOfAllElements(new int[][] { new int[] { 1 }, new int[] { 2 } }) + ", expected: 3...", ref timer);

            if (exercise.GetSumOfAllElements(new int[][] { new int[] { 1 }, new int[] { 2 } }) != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Calling GetSumOfAllElements(new int[][] { new int[] { 2, 3 }, new int[] { 1 } })...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Result: " + exercise.GetSumOfAllElements(new int[][] { new int[] { 2, 3 }, new int[] { 1 } }) + ", expected: 6...", ref timer);

            if (exercise.GetSumOfAllElements(new int[][] { new int[] { 2, 3 }, new int[] { 1 } }) != 6) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
