using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2070_NestedLoops {


    public class Exercise {



        // Return the sum of all the elements in the array of arrays
        public int GetSumOfAllElements(int[][] intArrayArrays) {
            int sum = 0;

            for (int i = 0; i < intArrayArrays.Length; i++) {
                for (int j = 0; j < intArrayArrays[i].Length; j++) {
                    sum += intArrayArrays[i][j];
                }
            }

            return sum;
        }



    }

}
