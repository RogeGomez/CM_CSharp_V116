using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2070_NestedLoops {


    public class Exercise {



        // Return the sum of all the elements in the array of arrays
        public int GetSumOfAllElements(int[][] intArrayArrays) {
            return 0;
        }



    }

}
