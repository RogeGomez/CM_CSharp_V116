using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2070_NestedLoops {


    public class Exercise {



        // Return the sum of all the elements in the 2D array
        public int GetSumOfAllElements(int[,] int2DArray) {
            int sum = 0;

            for (int i = 0; i < int2DArray.GetLength(0); i++) {
                for (int j = 0; j < int2DArray.GetLength(1); j++) {
                    sum += int2DArray[i, j];
                }
            }

            return sum;
        }



    }

}
