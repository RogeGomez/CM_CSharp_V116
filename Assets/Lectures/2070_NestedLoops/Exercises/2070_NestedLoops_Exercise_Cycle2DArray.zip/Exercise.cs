using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2070_NestedLoops {


    public class Exercise {



        // Return the sum of all the elements in the 2D array
        public int GetSumOfAllElements(int[,] int2DArray) {
            return 0;
        }



    }

}
