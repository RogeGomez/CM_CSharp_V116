using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1180_Class {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing Exercise...", ref timer, add: false);

            bool foundConstructor = false;
            foreach (ConstructorInfo constructorInfo in typeof(Exercise).GetConstructors(BindingFlags.Public | BindingFlags.Instance | BindingFlags.NonPublic)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Found Constructor!", ref timer);

                if (constructorInfo.GetParameters().Length != 1) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Constructor does not have 1 parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                }

                if (constructorInfo.GetParameters().Length == 1 && constructorInfo.GetParameters()[0].ParameterType != typeof(float)) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Constructor does not have 1 float parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                }

                if (constructorInfo.GetParameters().Length == 1 && constructorInfo.GetParameters()[0].ParameterType == typeof(float)) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Constructor correctly has one parameter of type float", ref timer);
                    foundConstructor = true;
                }
            }

            if (!foundConstructor) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }


    }

}
