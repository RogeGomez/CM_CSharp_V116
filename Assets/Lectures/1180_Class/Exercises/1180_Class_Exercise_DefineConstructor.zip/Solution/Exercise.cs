using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1180_Class {


    public class Exercise {

        // Define a constructor that takes in a float parameter
        public Exercise(float time) {
        }

    }

}
