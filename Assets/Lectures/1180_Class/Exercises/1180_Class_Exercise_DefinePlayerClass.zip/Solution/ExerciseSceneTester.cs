using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1180_Class {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
            ExerciseUtils.TimedMessage(textMeshUI, "Waiting for Result(); function call...", ref timer, add: false);
        }

        public void Result(string helloString) {
            ExerciseUtils.TimedMessage(textMeshUI, helloString, ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for Player class...", ref timer);

            bool foundPlayerClass = false;
            bool foundSayHelloFunction = false;

            foreach (Type type in typeof(Exercise).GetNestedTypes(BindingFlags.Public | BindingFlags.NonPublic)) {
                if (type.Name == "Player") {
                    // Class name matches Player
                    foundPlayerClass = true;
                    foreach (MethodInfo methodInfo in type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)) {
                        if (methodInfo.Name == "SayHello") {
                            // There is a function named SayHello();
                            foundSayHelloFunction = true;
                        } else {
                            // Function not named exactly SayHello
                        }
                    }
                } else {
                    // Class name does not match exactly Player
                }
            }

            if (foundPlayerClass) {
                ExerciseUtils.TimedMessage(textMeshUI, "Found Player class...", ref timer);

                if (foundSayHelloFunction) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Found SayHello(); function!", ref timer);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
                    FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
                } else {
                    ExerciseUtils.TimedMessage(textMeshUI, "Could not find any function named exactly 'SayHello' inside 'Player'!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                }
            } else {
                // Did not find player class
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find any class named exactly 'Player'!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "Make sure you define it as a nested class inside the Exercise class", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
            }
        }

    }

}
