using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1180_Class {


    public class Exercise : MonoBehaviour {

        // Define a Player class here
        // Inside the player class define a SayHello(); function
        // And inside that function call ExerciseSceneTester.Instance.Result("Hello!");




        private void Start() {
            // Then here on Start, create a Player and call SayHello(); on it

        }


    }

}
