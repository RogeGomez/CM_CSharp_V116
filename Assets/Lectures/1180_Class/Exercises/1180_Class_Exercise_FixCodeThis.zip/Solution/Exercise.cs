using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1180_Class {


    public class Exercise : MonoBehaviour {


        private float speed;


        public void SetSpeed(float speed) {
            // Modify this line to set the class 'speed' to the value this function receives
            this.speed = speed;
        }

        public float GetSpeed() {
            return speed;
        }

    }

}
