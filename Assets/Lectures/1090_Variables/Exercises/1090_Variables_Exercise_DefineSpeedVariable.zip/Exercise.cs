using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1090_Variables {


    public class Exercise {


        private void Main() {
            // This is a Comment, the code ignores these lines of code that start with //
            // Comments are covered in detail in a future lecture

            // Write your code after this line, but remember to still write inside the Main() function code block { }
            // Declare a variable of type 'int' with the name 'speed' and the value 5

        }


    }

}