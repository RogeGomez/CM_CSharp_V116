using CodeMonkey.CSharpCourse.Companion;
using CodeMonkey.CSharpCourse.Interactive;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1090_Variables {

    [InitializeOnLoad]
    public class ExerciseCompletionTester {


        static ExerciseCompletionTester() {
            CodeMonkeyCompanion.OnCompilationFinished -= CodeMonkeyCompanion_OnCompilationFinished;
            CodeMonkeyCompanion.OnCompilationFinished += CodeMonkeyCompanion_OnCompilationFinished;
            CodeMonkeyCompanion.OnCompilerMessage -= CodeMonkeyCompanion_OnCompilerMessage;
            CodeMonkeyCompanion.OnCompilerMessage += CodeMonkeyCompanion_OnCompilerMessage;
        }

        private static void CodeMonkeyCompanion_OnCompilerMessage(object sender, System.EventArgs e) {
            CodeMonkeyCompanion.HandleCompilerMessage((CompilerMessage)sender);
        }

        private static void CodeMonkeyCompanion_OnCompilationFinished(object sender, System.EventArgs e) {
            LectureSO lectureSO = LectureSO.GetLectureSO("1090");
            string exerciseFilename = lectureSO.GetLectureFolderPath() + "Exercises/Exercise.cs";

            if (File.Exists(exerciseFilename)) {
                string exerciseFileText = File.ReadAllText(exerciseFilename);
                if (exerciseFileText.Contains("int speed = 5;")) {
                    // Success! Exercise completed!
                    CodeMonkeyInteractiveSO.SetState(CodeMonkeyInteractiveSO.GetActiveExerciseSO(), CodeMonkeyInteractiveSO.State.Completed);
                } else {
                    // Exercise not complete, any common reason?
                    if (exerciseFileText.ToLower().Contains("int speed") ||
                        exerciseFileText.ToLower().Contains("int sped") ||
                        exerciseFileText.ToLower().Contains("int spd") ||
                        exerciseFileText.ToLower().Contains("int speeed")) {
                        CodeMonkeyCompanion.SendCompanionMessage(
                            CodeMonkeyCompanion.MessageType.Warning,
                            "Did you accidentally write '<b>Speed</b>' or something other than '<b>speed</b>'?\nRemember how code is <b>case sensitive!</b>"
                        );
                    }
                    if (exerciseFileText.Contains("int speed")) {
                        CodeMonkeyCompanion.SendCompanionMessage(
                            CodeMonkeyCompanion.MessageType.Info,
                            "Remember to assign the value <b>5</b> to the 'speed' variable"
                        );
                    }
                    if (exerciseFileText.Contains("float speed")) {
                        CodeMonkeyCompanion.SendCompanionMessage(
                            CodeMonkeyCompanion.MessageType.Warning,
                            "The 'speed' variable is meant to be of type 'int' not 'float'"
                        );
                    }
                    if (exerciseFileText.Contains("double speed")) {
                        CodeMonkeyCompanion.SendCompanionMessage(
                            CodeMonkeyCompanion.MessageType.Warning,
                            "The 'speed' variable is meant to be of type 'int' not 'double'"
                        );
                    }
                }
            } else {
                // File does not exist, did you accidentally delete it?
            }
        }


    }

}