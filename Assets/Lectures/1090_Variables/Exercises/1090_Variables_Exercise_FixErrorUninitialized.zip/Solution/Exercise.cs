using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace CodeMonkey.CSharpCourse.L1090_Variables {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // This is a Comment, the code ignores these lines of code that start with //
            // Comments are covered in detail in a future lecture

            int age = 1;

            // Fix this error, place the mouse over the red line to see the error
            Debug.Log(age);
        }

    }

}
