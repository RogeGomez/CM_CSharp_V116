using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* COMPILATION BLOCKER
namespace CodeMonkey.CSharpCourse.L1090_Variables {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // This is a Comment, the code ignores these lines of code that start with //
            // Comments are covered in detail in a future lecture

            int age;

            // Fix this error, place the mouse over the red line to see the error
            Debug.Log(age);
        }

    }

}
COMPILATION BLOCKER */