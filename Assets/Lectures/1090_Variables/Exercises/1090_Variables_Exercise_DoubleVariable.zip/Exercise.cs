using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1090_Variables {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // This is a Comment, the code ignores these lines of code that start with //
            // Comments are covered in detail in a future lecture

            // int variable being initialized
            int age = 20;

            // Modify this line, set it to double the value stored inside age
            // Remember how you can use math
            int ageDouble = 0;

            // Press Play in Unity to test your code


            // Don't modify this line of code, it's for testing when the exercise is completed
            ExerciseSceneTester.Instance.Result(age, ageDouble);
        }

    }

}

