using CodeMonkey.CSharpCourse.Companion;
using CodeMonkey.CSharpCourse.Interactive;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1090_Variables {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string LECTURE_CODE = "1090";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private void Awake() {
            Instance = this;
        }

        public void Result(int age, int ageDouble) {
            if (ageDouble == age * 2) {
                textMeshUI.text = $"age: {age}\nageDouble:{ageDouble}\n\n<color=#00ff00>SUCCESS!</color>";

                LectureSO lectureSO = LectureSO.GetLectureSO(LECTURE_CODE);
                string exerciseFilename = lectureSO.GetLectureFolderPath() + "Exercises/Exercise.cs";

                if (File.Exists(exerciseFilename)) {
                    string exerciseFileText = File.ReadAllText(exerciseFilename);
                    if (exerciseFileText.Contains("age*") || exerciseFileText.Contains("age *") || exerciseFileText.Contains("age  *")) {
                        // Success! Exercise completed!
                        ExerciseCompletionTester.ExerciseCompleted();
                    } else {
                        textMeshUI.text += "\nHowever... while the result is accurate there doesn't seem to be any multiplication.\n" +
                            "Did you set ageDouble to a fixed value instead of multiplying by 2?";
                        textMeshUI.text += "\n" + ExerciseUtils.INCORRECT;
                    }
                }
            } else {
                textMeshUI.text = $"age: {age}\nageDouble:{ageDouble}\n\n<color=#aa1111>Incorrect!</color>";
            }
        }

    }

}