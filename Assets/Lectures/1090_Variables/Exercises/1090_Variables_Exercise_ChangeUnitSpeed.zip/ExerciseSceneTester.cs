using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1090_Variables {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Transform playerTransform;
        [SerializeField] private Transform targetTransform;


        private float playerSpeed;
        private float timer = 3f;


        private void Awake() {
            Instance = this;
        }

        private void Update() {
            if (timer > 0) {
                Vector3 moveDir = (targetTransform.position - playerTransform.position).normalized;
                playerTransform.position += moveDir * playerSpeed * Time.deltaTime;

                float distanceToTarget = Vector3.Distance(playerTransform.position, targetTransform.position);
                textMeshUI.text = "Player Speed: " + playerSpeed + "\n"+
                    "Distance: " + distanceToTarget.ToString("F2") + "\n" + 
                    "Timer: " + timer.ToString("F2");

                timer -= Time.deltaTime;
                if (timer <= 0f) {
                    // Timer elapsed
                    textMeshUI.text += "\n\n<color=#aa1111>Did not reach target in time!</color>";
                } else {
                    // Timer still counting
                    float minDistance = .1f;
                    if (distanceToTarget <= minDistance) {
                        // Reached target in time!
                        textMeshUI.text += "\n\n<color=#00ff00>SUCCESS!</color>";
                        ExerciseCompletionTester.ExerciseCompleted();
                        timer = 0f;
                    }
                }
            }
        }

        public void SetPlayerSpeed(float playerSpeed) {
            this.playerSpeed = playerSpeed;
        }

    }

}