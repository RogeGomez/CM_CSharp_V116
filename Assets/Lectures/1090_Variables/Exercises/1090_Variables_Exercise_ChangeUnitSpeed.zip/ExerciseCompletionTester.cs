using CodeMonkey.CSharpCourse.Companion;
using CodeMonkey.CSharpCourse.Interactive;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1090_Variables {

    [InitializeOnLoad]
    public class ExerciseCompletionTester {


        private const string LECTURE_CODE = "1090";



        static ExerciseCompletionTester() {
            CodeMonkeyCompanion.OnCompilationFinished -= CodeMonkeyCompanion_OnCompilationFinished;
            CodeMonkeyCompanion.OnCompilationFinished += CodeMonkeyCompanion_OnCompilationFinished;
            CodeMonkeyCompanion.OnCompilerMessage -= CodeMonkeyCompanion_OnCompilerMessage;
            CodeMonkeyCompanion.OnCompilerMessage += CodeMonkeyCompanion_OnCompilerMessage;

            ExerciseSO.TryRemoveCompilationBlockers();
        }

        private static void CodeMonkeyCompanion_OnCompilerMessage(object sender, System.EventArgs e) {
            CompilerMessage compilerMessage = (CompilerMessage)sender;

            // Default
            CodeMonkeyCompanion.HandleCompilerMessage(compilerMessage);
        }

        private static void CodeMonkeyCompanion_OnCompilationFinished(object sender, System.EventArgs e) {
            LectureSO lectureSO = LectureSO.GetLectureSO(LECTURE_CODE);
            string exerciseFilename = lectureSO.GetLectureFolderPath() + "Exercises/Exercise.cs";

            if (File.Exists(exerciseFilename)) {
                string exerciseFileText = File.ReadAllText(exerciseFilename);
                if (!exerciseFileText.Contains("ExerciseSceneTester.Instance.SetPlayerSpeed(playerSpeed);")) {
                    // User changed testing code
                    CodeMonkeyCompanion.SendCompanionMessage(
                        CodeMonkeyCompanion.MessageType.Error,
                        "Did you modify the testing code? It needs to call the testing function for the exercise to work.\n" +
                        "You can Stop and Restart the exercise to reset the state."
                    );
                }
            } else {
                // File does not exist, did you accidentally delete it?
            }
        }

        public static void ExerciseCompleted() {
            // Success! Exercise completed!
            CodeMonkeyInteractiveSO.SetState(CodeMonkeyInteractiveSO.GetActiveExerciseSO(), CodeMonkeyInteractiveSO.State.Completed);
        }

    }

}