using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1090_Variables {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // This is a Comment, the code ignores these lines of code that start with //
            // Comments are covered in detail in a future lecture

            // Set player speed
            float playerSpeed = 1f;

            // Press Play in Unity to test your code


            // Don't modify this line of code, it's for testing the exercise
            ExerciseSceneTester.Instance.SetPlayerSpeed(playerSpeed);
        }

    }

}
