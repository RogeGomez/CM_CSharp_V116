using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1090_Variables {


    public class Exercise {


        private void Main() {
            // This is a Comment, the code ignores these lines of code that start with //
            // Comments are covered in detail in a future lecture

            // Fix this error, place the mouse over the red line to see the error
            // or check the Unity console, or check the Code Monkey Companion window
            int speed = 5;
        }


    }

}

