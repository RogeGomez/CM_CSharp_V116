using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3220_Dynamic {


    public class Exercise {

        // Make a function called TestObject that receives a dynamic parameter.
        // Then inside it try to call a Test function inside that object.
        // But make sure it does NOT throw an exception if the object doesn't have a Test function.
        public void TestObject(dynamic objectDynamic) {
            try {
                objectDynamic.Test();
            } catch { }
        }

    }

}
