using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3220_Dynamic {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            Exercise exercise = new Exercise();

            MethodInfo testObjectMethodInfo =
                typeof(Exercise).GetMethod("TestObject", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

            if (testObjectMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find TestObject function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Found TestObject function...", ref timer);

            if (testObjectMethodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Function does not have one parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (testObjectMethodInfo.GetParameters()[0].ParameterType != typeof(object)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Function does not have a dynamic parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Correctly has one parameter...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestObject(obj) with an object that has NO Test function...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "It should NOT throw an exception...", ref timer);
            try {
                testObjectMethodInfo.Invoke(exercise, new object[] { new object() });
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Exception! {e}", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Correct...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestObject(obj) with an object that DOES have a Test function...", ref timer);
            bool calledTest = false;
            try {
                PlayerTest playerTest = new PlayerTest(() => calledTest = true);
                testObjectMethodInfo.Invoke(exercise, new object[] { playerTest });
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Exception! {e}", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!calledTest) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Test function was not called!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Test function was correctly called...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }


        public class PlayerTest {


            private Action action;


            public PlayerTest(Action action) {
                this.action = action;
            }

            public void Test() {
                action();
            }

        }
    }

}
