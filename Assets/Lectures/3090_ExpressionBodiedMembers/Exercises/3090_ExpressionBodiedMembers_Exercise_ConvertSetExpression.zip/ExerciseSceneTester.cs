using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3090_ExpressionBodiedMembers {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("3090", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not read Exercise.cs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for expression-bodied member...", ref timer);

            if (!lectureText.Contains("=>")) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find expression-bodied member!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found expression-bodied member...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling SetPlayerName('Code Monkey')...", ref timer);

            Exercise exercise = new Exercise();
            exercise.SetPlayerName("Code Monkey");

            ExerciseUtils.TimedMessage(textMeshUI, "Calling GetPlayerName()...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Got: " + exercise.GetPlayerName() + ", expected: Code Monkey", ref timer);

            if (exercise.GetPlayerName() != "Code Monkey") {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
