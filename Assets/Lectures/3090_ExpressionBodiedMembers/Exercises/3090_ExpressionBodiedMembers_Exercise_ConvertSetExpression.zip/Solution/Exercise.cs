using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3090_ExpressionBodiedMembers {


    public class Exercise {


        private string playerName;



        // Modify this function to use an expression-bodied member
        public void SetPlayerName(string playerName) => this.playerName = playerName;




        // Don't modify this function
        public string GetPlayerName() => playerName;

    }



}