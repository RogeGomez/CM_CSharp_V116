using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2160_Interfaces {


    public class Exercise {


        // Refactor this function to work with any IInteractable object
        public void Interact(IInteractable interactable) {
            interactable.Interact();
        }


        // Implement the IInteractable interface
        public class Button : IInteractable {

            public void Interact() {
                // ...
            }

        }

        // Implement the IInteractable interface
        public class Door : IInteractable {

            public void Interact() {
                // ...
            }

        }

        public interface IInteractable {

            public void Interact();

        }

    }

}
