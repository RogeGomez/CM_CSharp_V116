using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2160_Interfaces {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "...", ref timer, add: false);

            ExerciseUtils.TimedMessage(textMeshUI, "Checking Interact function parameters...", ref timer);

            MethodInfo interactMethodInfo = typeof(Exercise).GetMethod("Interact", BindingFlags.Instance | BindingFlags.Public);

            if (interactMethodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "Interact function does not have one parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (interactMethodInfo.GetParameters()[0].ParameterType != typeof(Exercise.IInteractable)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Interact function parameter is not of type IInteractable!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Interact function correctly has a parameter of type IInteractable...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\nTrying to Interact with a Button...", ref timer);
            
            Exercise.Button button = new Exercise.Button();

            if (!(button is Exercise.IInteractable)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Button does not implement IInteractable!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Button class does implement IInteractable...", ref timer);

            Exercise exercise = new Exercise();
            interactMethodInfo.Invoke(exercise, new object[] { button });

            ExerciseUtils.TimedMessage(textMeshUI, "Worked!", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "\nTrying to Interact with a Door...", ref timer);

            Exercise.Door door = new Exercise.Door();

            if (!(door is Exercise.IInteractable)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Door does not implement IInteractable!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Door class does implement IInteractable...", ref timer);

            interactMethodInfo.Invoke(exercise, new object[] { door });

            ExerciseUtils.TimedMessage(textMeshUI, "Worked!", ref timer);



            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
