using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2160_Interfaces {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "...", ref timer, add: false);

            Type damageableType = typeof(Exercise).GetNestedType("IDamageable", BindingFlags.Public | BindingFlags.NonPublic);

            Type enemyType = typeof(Exercise).GetNestedType("Enemy", BindingFlags.Public | BindingFlags.NonPublic);
            Type barrelType = typeof(Exercise).GetNestedType("Barrel", BindingFlags.Public | BindingFlags.NonPublic);

            if (damageableType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'IDamageable' interface!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found 'IDamageable' interface...", ref timer);

            if (enemyType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'Enemy' class!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found 'Enemy' class...", ref timer);

            if (barrelType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'Barrel' class!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found 'Barrel' class...", ref timer);


            if (enemyType.GetInterface("IDamageable") == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "'Enemy' class does not implement 'IDamageable'!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "'Enemy' class correctly implements 'IDamageable'...", ref timer);

            if (barrelType.GetInterface("IDamageable") == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "'Barrel' class does not implement 'IDamageable'!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "'Barrel' class correctly implements 'IDamageable'...", ref timer);


            MethodInfo takeDamageMethodInfo = damageableType.GetMethod("TakeDamage", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

            if (takeDamageMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'TakeDamage()' function!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found 'TakeDamage()' function...", ref timer);

            if (takeDamageMethodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "'TakeDamage()' does not have one parameter!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Creating Enemy object...", ref timer);

            object enemyObject = Activator.CreateInstance(enemyType);

            ExerciseUtils.TimedMessage(textMeshUI, $"Calling Enemy.TakeDamage(56);", ref timer);

            takeDamageMethodInfo.Invoke(enemyObject, new object[] { 56 });


            ExerciseUtils.TimedMessage(textMeshUI, $"Creating Barrel object...", ref timer);

            object barrelObject = Activator.CreateInstance(barrelType);

            ExerciseUtils.TimedMessage(textMeshUI, $"Calling Barrel.TakeDamage(32);", ref timer);

            takeDamageMethodInfo.Invoke(barrelObject, new object[] { 32 });



            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
