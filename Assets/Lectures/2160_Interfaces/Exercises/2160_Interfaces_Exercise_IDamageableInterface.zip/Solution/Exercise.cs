using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2160_Interfaces {


    public class Exercise : MonoBehaviour {


        // Define a IDamageable interface that has a function TakeDamage(int damageAmount);
        public interface IDamageable {

            public void TakeDamage(int damageAmount);

        }

        // Define a Enemy class that implements IDamageable
        public class Enemy : IDamageable {
            public void TakeDamage(int damageAmount) {
                Debug.Log($"Enemy.TakeDamage({damageAmount})");
            }
        }

        // Define a Barrel class that implements IDamageable
        public class Barrel : IDamageable {
            public void TakeDamage(int damageAmount) {
                Debug.Log($"Barrel.TakeDamage({damageAmount})");
            }
        }

    }

}
