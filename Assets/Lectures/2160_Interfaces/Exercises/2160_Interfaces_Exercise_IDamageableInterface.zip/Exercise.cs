using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2160_Interfaces {


    public class Exercise : MonoBehaviour {


        // Define a IDamageable interface that has a function TakeDamage(int damageAmount);


        // Define a Enemy class that implements IDamageable


        // Define a Barrel class that implements IDamageable



    }

}
