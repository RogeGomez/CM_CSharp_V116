using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2160_Interfaces {


    public class Exercise : MonoBehaviour {


        // Fix the error (on the Player class) by providing a default implementation to the Attack function
        public interface IAttackable {

            public void Attack() {
                // Attack...
            }

            public void TakeDamage();

        }


        // Do NOT modify this Player class!
        public class Player : IAttackable {
            public void TakeDamage() {
                Debug.Log("Player.TakeDamage");
            }
        }

    }

}
