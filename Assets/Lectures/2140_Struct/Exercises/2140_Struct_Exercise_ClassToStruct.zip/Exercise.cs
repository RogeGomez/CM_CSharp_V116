using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2140_Struct {


    public class Exercise : MonoBehaviour {

        // Change this from class to struct, don't change the name
        public class MyType {
            // ...
        }


        public MyType GetMyType() {
            // Then modify this code to not have an error and return an empty struct
            MyType myType = null;

            return myType;
        }

    }

}
