using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2140_Struct {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
        }

        private void Start() {
            Exercise.MyType myType = exercise.GetMyType();

            ExerciseUtils.TimedMessage(textMeshUI, "Function returned an object " + myType + "...", ref timer);

            try {
                bool isValueType = myType.GetType().IsValueType;
            } catch (NullReferenceException e) {
                ExerciseUtils.TimedMessage(textMeshUI, "Got null!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!myType.GetType().IsValueType) {
                ExerciseUtils.TimedMessage(textMeshUI, "MyType is not a struct!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "MyType is correctly a struct...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
