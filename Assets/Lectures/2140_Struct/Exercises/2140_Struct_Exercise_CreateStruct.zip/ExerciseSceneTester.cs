using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2140_Struct {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
        }

        private void Start() {
            FunctionTimer.Create(ValidateExercise, .01f);
        }

        private void ValidateExercise() {
            Type worldPositionType = typeof(Exercise).GetNestedType("WorldPosition", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (worldPositionType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find WorldPosition type!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found WorldPosition type!", ref timer);

            if (!worldPositionType.IsValueType || worldPositionType.IsClass) {
                ExerciseUtils.TimedMessage(textMeshUI, "WorldPosition is NOT a struct!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "WorldPosition is correctly a struct!", ref timer);

            FieldInfo xFieldInfo = worldPositionType.GetField("x", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (xFieldInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'x' field!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            if (xFieldInfo.FieldType != typeof(int)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Field 'x' is not an int!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "WorldPosition.x is correct!", ref timer);

            FieldInfo yFieldInfo = worldPositionType.GetField("y", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (yFieldInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'y' field!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            if (yFieldInfo.FieldType != typeof(int)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Field 'y' is not an int!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "WorldPosition.y is correct!", ref timer);

            FieldInfo worldPositionFieldInfo = null;
            foreach (FieldInfo fieldInfo in typeof(Exercise).GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)) {
                if (fieldInfo.FieldType == worldPositionType) {
                    worldPositionFieldInfo = fieldInfo;
                    break;
                }
            }

            if (worldPositionFieldInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find a field of type 'WorldPosition'!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found WorldPosition field!", ref timer);

            object worldPositionObject = worldPositionFieldInfo.GetValue(exercise);
            int x = (int)xFieldInfo.GetValue(worldPositionObject);
            int y = (int)yFieldInfo.GetValue(worldPositionObject);

            ExerciseUtils.TimedMessage(textMeshUI, "Testing values in WorldPosition object...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, $"worldPosition.x = {x}, expected 1", ref timer);
            if (x != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"worldPosition.y = {y}, expected 2", ref timer);
            if (y != 2) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
