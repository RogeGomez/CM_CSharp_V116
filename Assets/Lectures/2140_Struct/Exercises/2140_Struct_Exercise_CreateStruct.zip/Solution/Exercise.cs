using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2140_Struct {


    public class Exercise : MonoBehaviour {


        // Define a struct named WorldPosition, inside it define 2 fields, int x, int y
        private struct WorldPosition {
            public int x;
            public int y;
        }


        // Define a field of the WorldPosition type
        private WorldPosition worldPosition;


        private void Start() {
            // Create a WorldPosition object, assign x=1, y=2, assign that object to the field
            worldPosition = new WorldPosition {
                x = 1,
                y = 2,
            };

        }

    }

}
