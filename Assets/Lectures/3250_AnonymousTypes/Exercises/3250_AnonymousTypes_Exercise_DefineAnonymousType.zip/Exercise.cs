using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3250_AnonymousTypes {


    public class Exercise {

        // Define an Anonymous Type to hold a string PlayerName
        // and an int AttackPower, then call ExerciseValidate();
        public Exercise() {

        }



        private void ExerciseValidate(object anonymousObject) {
            ExerciseSceneTester.Instance.ExerciseValidate(anonymousObject);
        }

    }

}
