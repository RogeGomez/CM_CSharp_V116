using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3250_AnonymousTypes {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            ExerciseUtils.TimedMessage(textMeshUI, "Creating new Exercise()...", ref timer);
            new Exercise();
        }

        public void ExerciseValidate(object anonymousObject) {
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseValidate was called...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Inspecting Anonymous Type...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for PlayerName...", ref timer);
            PropertyInfo playerNamePropertyInfo = anonymousObject.GetType().GetProperty("PlayerName");

            if (playerNamePropertyInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find PlayerName inside anonymous type!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Found PlayerName property inside anonymous type...", ref timer);

            if (playerNamePropertyInfo.GetMethod.ReturnType != typeof(string)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"PlayerName does not return string!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "It does correctly return string...", ref timer);


            string playerName = (string)playerNamePropertyInfo.GetMethod.Invoke(anonymousObject, null);

            ExerciseUtils.TimedMessage(textMeshUI, $"PlayerName: {playerName}", ref timer);




            ExerciseUtils.TimedMessage(textMeshUI, "Looking for AttackPower...", ref timer);
            PropertyInfo attackPowerPropertyInfo = anonymousObject.GetType().GetProperty("AttackPower");

            if (attackPowerPropertyInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find AttackPower inside anonymous type!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Found AttackPower property inside anonymous type...", ref timer);

            if (attackPowerPropertyInfo.GetMethod.ReturnType != typeof(int)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"PlayerName does not return int!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "It does correctly return int...", ref timer);


            int attackPower = (int)attackPowerPropertyInfo.GetMethod.Invoke(anonymousObject, null);

            ExerciseUtils.TimedMessage(textMeshUI, $"AttackPower: {attackPower}", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
