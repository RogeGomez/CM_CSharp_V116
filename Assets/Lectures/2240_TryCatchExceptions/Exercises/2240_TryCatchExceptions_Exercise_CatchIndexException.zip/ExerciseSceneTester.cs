using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2240_TryCatchExceptions {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            FunctionTimer.Create(() => {
                ExerciseUtils.TimedMessage(textMeshUI, "Trying to get Item on index 0...", ref timer, add: false);

                ExerciseUtils.TimedMessage(textMeshUI, exercise.GetItem(0).ToString(), ref timer);

                ExerciseUtils.TimedMessage(textMeshUI, "Trying to get Item on index 1...", ref timer);

                ExerciseUtils.TimedMessage(textMeshUI, exercise.GetItem(1).ToString(), ref timer);

                ExerciseUtils.TimedMessage(textMeshUI, "Trying to get Item on index 9...", ref timer);

                FunctionTimer.Create(() => {
                    ExerciseUtils.TimedMessage(textMeshUI, exercise.GetItem(9) == null ? "null" : exercise.GetItem(9).ToString(), 0f);

                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);

                    FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
                }, timer);

                timer = 0f;
            }, .01f);
        }

    }

}
