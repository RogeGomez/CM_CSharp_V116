using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2240_TryCatchExceptions {


    public class Exercise : MonoBehaviour {


        public class Item {
            public string name;
            public override string ToString() {
                return name;
            }
        }

        private Item[] itemArray;


        private void Start() {
            // Don't modify this code
            itemArray = new Item[3];
            itemArray[0] = new Item { name = "Sword" };
            itemArray[1] = new Item { name = "Pistol" };
            itemArray[2] = new Item { name = "Katana" };
        }

        // Edit this function
        public Item GetItem(int index) {
            // Catch the IndexOutOfRangeException, return null instead

            return itemArray[index];
        }

    }

}
