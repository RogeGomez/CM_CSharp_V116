using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2240_TryCatchExceptions {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private bool gotDivideByZero;
        private bool gotIndexOutOfRange;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "...", ref timer, add: false);

            Exercise exercise = new Exercise();

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestFunction in a way that triggers no Exceptions...", ref timer);

            try {
                exercise.TestFunction(new int[] { 1 });
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, "Code threw an Exception!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Correctly did not throw an Exception...\n", ref timer);



            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestFunction in a way that triggers a IndexOutOfRangeException...", ref timer);

            try {
                exercise.TestFunction(new int[0]);
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, "Code threw an Exception!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!gotIndexOutOfRange) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not call ExerciseIndexOutOfRange()!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Correctly called ExerciseIndexOutOfRange()...\n", ref timer);




            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestFunction in a way that triggers a DivideByZeroException...", ref timer);

            try {
                exercise.TestFunction(new int[] { 0 });
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, "Code threw an Exception!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!gotIndexOutOfRange) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not call ExerciseDivideByZero()!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Correctly called ExerciseDivideByZero()...\n", ref timer);

            

            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }


        public void ExerciseDivideByZero() {
            gotDivideByZero = true;
        }

        public void ExerciseIndexOutOfRange() {
            gotIndexOutOfRange = true;
        }

    }

}
