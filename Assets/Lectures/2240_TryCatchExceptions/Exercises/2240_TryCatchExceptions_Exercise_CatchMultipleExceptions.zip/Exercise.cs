using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2240_TryCatchExceptions {


    public class Exercise {



        public void TestFunction(int[] intArray) {
            // Catch the exceptions DivideByZeroException and IndexOutOfRangeException, and call the related exercise functions.
            int math = 56 / intArray[0];
        }



        private void ExerciseDivideByZero() {
            ExerciseSceneTester.Instance.ExerciseDivideByZero();
        }

        private void ExerciseIndexOutOfRange() {
            ExerciseSceneTester.Instance.ExerciseIndexOutOfRange();
        }

    }

}
