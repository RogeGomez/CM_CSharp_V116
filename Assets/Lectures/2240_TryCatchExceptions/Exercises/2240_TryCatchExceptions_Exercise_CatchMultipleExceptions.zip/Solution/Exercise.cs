using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2240_TryCatchExceptions {


    public class Exercise {



        public void TestFunction(int[] intArray) {
            // Catch the exceptions DivideByZeroException and IndexOutOfRangeException, and call the related exercise functions.
            try {
                int math = 56 / intArray[0];
            } catch (DivideByZeroException e) {
                ExerciseDivideByZero();
            } catch (IndexOutOfRangeException e) {
                ExerciseIndexOutOfRange();
            }
        }

        private void ExerciseDivideByZero() {
            ExerciseSceneTester.Instance.ExerciseDivideByZero();
        }

        private void ExerciseIndexOutOfRange() {
            ExerciseSceneTester.Instance.ExerciseIndexOutOfRange();
        }

    }

}
