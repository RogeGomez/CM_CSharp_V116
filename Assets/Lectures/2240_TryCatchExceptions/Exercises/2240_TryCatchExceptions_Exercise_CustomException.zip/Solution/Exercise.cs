using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2240_TryCatchExceptions {


    public class Exercise {

        // Define a custom exception named 'InvalidInputException'
        public class InvalidInputException : Exception { }


        public void TestFunction(Player player) {
            // Test if player is null, if so throw an InvalidInputException
            if (player == null) {
                throw new InvalidInputException();
            }
            player.DoSomething();
        }


        public class Player {
            public void DoSomething() {
                // ...
            }
        }



    }

}
