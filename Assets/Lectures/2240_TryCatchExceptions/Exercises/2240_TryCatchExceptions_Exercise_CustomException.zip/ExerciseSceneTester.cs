using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2240_TryCatchExceptions {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "...", ref timer, add: false);

            Exercise exercise = new Exercise();

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestFunction with a Player object...", ref timer);

            try {
                exercise.TestFunction(new Exercise.Player());
            } catch (Exception e) {
                ExerciseUtils.TimedMessage(textMeshUI, "Function threw an Exception when it shouldn't!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Function correctly did not throw an Exception...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TestFunction with null...", ref timer);

            try {
                exercise.TestFunction(null);
            } catch (Exception e) {
                if (e.GetType().Name != "InvalidInputException") {
                    ExerciseUtils.TimedMessage(textMeshUI, "Fired exception is not an InvalidInputException!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "Got correct Exception...", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, e.ToString(), ref timer);
            }


            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
