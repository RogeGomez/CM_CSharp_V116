using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3280_CustomOverrideOperators {


    public class Exercise {


        public void Test() {
            PlayerStats playerStatsA = new PlayerStats {
                stat = Stat.Str,
                amount = 12,
            };
            PlayerStats playerStatsB = new PlayerStats {
                stat = Stat.Str,
                amount = 5,
            };

            // Fix the error by overriding the plus operator on PlayerStats
            /* COMPILATION BLOCKER
            PlayerStats playerStatsTotal = playerStatsA + playerStatsB;

            ExerciseValidate(playerStatsTotal);
            COMPILATION BLOCKER */
        }

        private void ExerciseValidate(PlayerStats playerStatsTotal) {
            ExerciseSceneTester.Instance.ExerciseValidate(playerStatsTotal);
        }

        public enum Stat {
            Str,
            Wis,
            Dex,
        }

        public class PlayerStats {

            public Stat stat;
            public int amount;

        }

    }

}
