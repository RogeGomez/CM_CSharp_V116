using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using static CodeMonkey.CSharpCourse.L3280_CustomOverrideOperators.Exercise;

namespace CodeMonkey.CSharpCourse.L3280_CustomOverrideOperators {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling Test() function...", ref timer);

            new Exercise().Test();
        }

        public void ExerciseValidate(PlayerStats playerStatsTotal) {
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseValidate() was called...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Checking amount...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, $"Got {playerStatsTotal.amount}, expected 17", ref timer);

            if (playerStatsTotal.amount != 12 + 5) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
