using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3280_CustomOverrideOperators {


    public class Exercise {


        public void Test() {
            PlayerStats playerStatsA = new PlayerStats {
                stat = Stat.Str,
                amount = 12,
            };
            PlayerStats playerStatsB = new PlayerStats {
                stat = Stat.Str,
                amount = 5,
            };

            // Fix the error by overriding the plus operator on PlayerStats
            PlayerStats playerStatsTotal = playerStatsA + playerStatsB;

            ExerciseValidate(playerStatsTotal);
        }

        private void ExerciseValidate(PlayerStats playerStatsTotal) {
            ExerciseSceneTester.Instance.ExerciseValidate(playerStatsTotal);
        }

        public enum Stat {
            Str,
            Wis,
            Dex,
        }

        public class PlayerStats {

            public Stat stat;
            public int amount;

            public static PlayerStats operator +(PlayerStats a, PlayerStats b) {
                return new PlayerStats {
                    stat = a.stat,
                    amount = a.amount + b.amount,
                };
            }
        }

    }

}
