using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1110_IfConditions {


    public class Exercise : MonoBehaviour {


        public void Start() {
            bool a = true;
            bool b = false;

            // Fix this incorrect AND
            if (a && b) {
                // Do something
            }
        }


    }

}
