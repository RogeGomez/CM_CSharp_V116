using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1110_IfConditions {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private bool exerciseJumpCalled;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Trying to jump with isJumpInputPressed == false and isGrounded == false", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Should NOT jump...", ref timer);

            exercise.TestFunction(false, false);

            if (exerciseJumpCalled) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "Trying to jump with isJumpInputPressed == true and isGrounded == false", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Should NOT jump...", ref timer);

            exercise.TestFunction(true, false);

            if (exerciseJumpCalled) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Trying to jump with isJumpInputPressed == true and isGrounded == true", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "It SHOULD jump...", ref timer);

            exercise.TestFunction(true, true);

            if (!exerciseJumpCalled) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void ExerciseJump() {
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseJump()", ref timer);
            exerciseJumpCalled = true;
        }

    }

}
