using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1110_IfConditions {


    public class Exercise : MonoBehaviour {


        public void TestFunction(bool isJumpInputPressed, bool isGrounded) {
            // Run ExerciseJump(); only if BOTH isJumpInputPressed AND isGrounded are true
            if (isJumpInputPressed && isGrounded) {
                ExerciseJump();
            }


            // Press Play in Unity to test your code

        }

        // Don't modify this code
        private void ExerciseJump() {
            ExerciseSceneTester.Instance.ExerciseJump();
        }



    }

}
