using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1110_IfConditions {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private bool expensiveFunctionRan;
        private bool isExerciseDone;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
        }

        private void Start() {
            FunctionTimer.Create(() => {
                if (!ExerciseUtils.TryGetLectureExerciseCSText("1110", out string lectureText)) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Could not read Exercise.cs! Did you move it?", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                if (!lectureText.Contains("ReallyExpensiveFunction())") && !lectureText.Contains("(ReallyExpensiveFunction()")) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Could not find ReallyExpensiveFunction() in the condition!\nDid you just remove it?", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                if (expensiveFunctionRan) {
                    ExerciseUtils.TimedMessage(textMeshUI, "Expensive function should NOT have run!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "Expensive function correctly did NOT run...", ref timer);

                if (!isExerciseDone) {
                    ExerciseUtils.TimedMessage(textMeshUI, "ExerciseDone() was not called!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }

                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
                FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
            }, .01f);
        }

        public void ReallyExpensiveFunction() {
            expensiveFunctionRan = true;
            ExerciseUtils.TimedMessage(textMeshUI, "ReallyExpensiveFunction()", ref timer);
        }

        public void ExerciseDone() {
            isExerciseDone = true;
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseDone()", ref timer);
        }

    }

}
