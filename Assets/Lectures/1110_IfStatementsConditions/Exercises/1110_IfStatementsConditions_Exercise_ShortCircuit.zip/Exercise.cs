using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1110_IfConditions {


    public class Exercise : MonoBehaviour {


        public void Start() {
            // Make sure the code inside the if runs AND ReallyExpensiveFunction() is included in the if condition but does NOT run
            if (ReallyExpensiveFunction()) {
                ExerciseSceneTester.Instance.ExerciseDone();
            }


            // Press Play in Unity to test your code

        }

        // Don't modify this code
        private bool ReallyExpensiveFunction() {
            ExerciseSceneTester.Instance.ReallyExpensiveFunction();
            return true;
        }



    }

}
