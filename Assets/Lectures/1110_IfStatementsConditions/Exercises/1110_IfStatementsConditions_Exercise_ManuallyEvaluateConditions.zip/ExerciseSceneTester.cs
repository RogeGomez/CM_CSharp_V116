using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1110_IfConditions {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private List<bool> conditionResultList;


        private void Awake() {
            Instance = this;

            conditionResultList = new List<bool>();

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
        }

        private void Start() {
            FunctionTimer.Create(() => {
                FunctionTimer.Create(() => {
                    if (conditionResultList.Count < 6) {
                        ExerciseUtils.TimedMessage(textMeshUI, "Did not test all 6 conditions!", ref timer);
                        ExerciseUtils.TimedMessage(textMeshUI, "Did you modify some of the testing code?", ref timer);
                        ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                    }
                }, timer);
            }, .01f);
        }

        public void TestConditions(bool condition, bool conditionResult) {
            ExerciseUtils.TimedMessage(textMeshUI, "Testing condition " + (conditionResultList.Count + 1), ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, condition + " " + conditionResult, ref timer);

            conditionResultList.Add(condition == conditionResult);
            if (condition == conditionResult) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            } else {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }
            ExerciseUtils.TimedMessage(textMeshUI, "", ref timer);

            if (conditionResultList.Count >= 6) {
                bool allTrue = true;
                foreach (bool conditionResultTest in conditionResultList) {
                    if (!conditionResultTest) {
                        // This one is false
                        allTrue = false;
                    }
                }

                if (allTrue) {
                    // All conditions are true, exercise success!
                    FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
                }
            }
        }

    }

}
