using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1110_IfConditions {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // This is a Comment, the code ignores these lines of code that start with //
            // Comments are covered in detail in a future lecture

            bool condition, conditionResult;

            // Modify only the 'conditionResult' variables, not the 'condition'


            // CONDITION 1
            condition = 6 > 3; // DON'T modify this line
            conditionResult = false; // Modify this one to 'true' or 'false' based on the condition above
            // Don't modify this line of code, it's for testing when the exercise is completed
            ExerciseSceneTester.Instance.TestConditions(condition, conditionResult);

            // CONDITION 2
            condition = 0 < -5; // DON'T modify this line
            conditionResult = false; // Modify this one to 'true' or 'false' based on the condition above
            // Don't modify this line of code, it's for testing when the exercise is completed
            ExerciseSceneTester.Instance.TestConditions(condition, conditionResult);

            // CONDITION 3
            condition = 10 == 10; // DON'T modify this line
            conditionResult = false; // Modify this one to 'true' or 'false' based on the condition above
            // Don't modify this line of code, it's for testing when the exercise is completed
            ExerciseSceneTester.Instance.TestConditions(condition, conditionResult);

            // CONDITION 4
            condition = 3 <= 3; // DON'T modify this line
            conditionResult = false; // Modify this one to 'true' or 'false' based on the condition above
            // Don't modify this line of code, it's for testing when the exercise is completed
            ExerciseSceneTester.Instance.TestConditions(condition, conditionResult);

            // CONDITION 5
            condition = 2 <= 3; // DON'T modify this line
            conditionResult = false; // Modify this one to 'true' or 'false' based on the condition above
            // Don't modify this line of code, it's for testing when the exercise is completed
            ExerciseSceneTester.Instance.TestConditions(condition, conditionResult);

            // CONDITION 6
            condition = 0 != 0; // DON'T modify this line
            conditionResult = false; // Modify this one to 'true' or 'false' based on the condition above
            // Don't modify this line of code, it's for testing when the exercise is completed
            ExerciseSceneTester.Instance.TestConditions(condition, conditionResult);



            // Press Play in Unity to test your code


        }

    }

}
