using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1110_IfConditions {


    public class Exercise : MonoBehaviour {


        public void TestFunction(bool state) {
            // Fix this if to run both function calls when state is true, and none when it's false
            if (state)
                ExerciseValidate();
                ExerciseValidate();

            // Press Play in Unity to test your code

        }

        // Don't modify this testing function
        private void ExerciseValidate() {
            ExerciseSceneTester.Instance.ExerciseValidate();
        }

    }

}
