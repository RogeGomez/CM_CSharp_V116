using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1110_IfConditions {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private int exerciseValidateAmount;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
        }

        private void Start() {
            exerciseValidateAmount = 0;

            ExerciseUtils.TimedMessage(textMeshUI, "Testing with state == false", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Expecting 0 x ExerciseValidate()...", ref timer);

            exercise.TestFunction(false);

            if (exerciseValidateAmount != 0) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Testing with state == true", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Expecting 2 x ExerciseValidate()...", ref timer);

            exercise.TestFunction(true);

            if (exerciseValidateAmount != 2) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void ExerciseValidate() {
            ExerciseUtils.TimedMessage(textMeshUI, "Got one ExerciseValidate()", ref timer);
            exerciseValidateAmount++;
        }

    }

}
