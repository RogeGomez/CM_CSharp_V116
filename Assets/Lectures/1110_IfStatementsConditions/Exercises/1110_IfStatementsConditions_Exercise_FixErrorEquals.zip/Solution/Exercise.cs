using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1110_IfConditions {


    public class Exercise : MonoBehaviour {


        public void TestExercise(int number) {
            int a = 56;

            // Fix this error
            if (a == 0) {
                // Do something
            }
        }


    }

}
