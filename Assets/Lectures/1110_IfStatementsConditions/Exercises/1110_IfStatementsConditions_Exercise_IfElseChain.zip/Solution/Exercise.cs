using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1110_IfConditions {


    public class Exercise : MonoBehaviour {


        public void TestExercise(int number) {
            // Do an if else on the number, call the functions depending on the number ExercisePositive(); ExerciseNegative(); ExerciseZero();
            if (number > 0) {
                ExercisePositive();
            } else if (number < 0) {
                ExerciseNegative();
            } else {
                ExerciseZero();
            }


            // Press Play in Unity to test your code

        }

        // Don't modify these testing functions
        private void ExercisePositive() {
            ExerciseSceneTester.Instance.ExercisePositive();
        }

        private void ExerciseNegative() {
            ExerciseSceneTester.Instance.ExerciseNegative();
        }

        private void ExerciseZero() {
            ExerciseSceneTester.Instance.ExerciseZero();
        }

    }

}
