using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1110_IfConditions {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;
        [SerializeField] private Exercise exercise;


        private float timer;
        private bool gotExercisePositive;
        private bool gotExerciseNegative;
        private bool gotExerciseZero;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Testing...", ref timer, add: false);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("1110", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Failed to read exercise file! Did you rename Exercise.cs?", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!lectureText.Contains("if") && lectureText.Contains("else")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not find any if-else chain in the code!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "calling TestExercise( 5 ); expecting ExercisePositive();", ref timer);
            exercise.TestExercise(5);

            if (!gotExercisePositive) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not get ExercisePositive()!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "calling TestExercise( -6 ); expecting ExerciseNegative();", ref timer);
            exercise.TestExercise(-6);

            if (!gotExerciseNegative) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not get ExerciseNegative()!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "calling TestExercise( 0 ); expecting ExerciseZero();", ref timer);
            exercise.TestExercise(0);

            if (!gotExerciseZero) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not get ExerciseZero()!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "All correct!", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        public void ExercisePositive() {
            gotExercisePositive = true;
            ExerciseUtils.TimedMessage(textMeshUI, "Got ExercisePositive();", ref timer);
        }

        public void ExerciseNegative() {
            gotExerciseNegative = true;
            ExerciseUtils.TimedMessage(textMeshUI, "Got ExerciseNegative();", ref timer);
        }

        public void ExerciseZero() {
            gotExerciseZero = true;
            ExerciseUtils.TimedMessage(textMeshUI, "Got ExerciseZero();", ref timer);
        }

    }

}
