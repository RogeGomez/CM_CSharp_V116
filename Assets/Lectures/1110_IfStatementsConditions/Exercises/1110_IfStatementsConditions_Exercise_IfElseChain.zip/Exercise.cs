using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1110_IfConditions {


    public class Exercise : MonoBehaviour {


        public void TestExercise(int number) {
            // Do an if else on the number, call the functions depending on the number ExercisePositive(); ExerciseNegative(); ExerciseZero();
            // You call a function by just writing the function name, the parenthesis and a semi-colon, just like this:
            // ExercisePositive();


            // Press Play in Unity to test your code

        }

        // Don't modify these testing functions
        private void ExercisePositive() {
            ExerciseSceneTester.Instance.ExercisePositive();
        }

        private void ExerciseNegative() {
            ExerciseSceneTester.Instance.ExerciseNegative();
        }

        private void ExerciseZero() {
            ExerciseSceneTester.Instance.ExerciseZero();
        }

    }

}
