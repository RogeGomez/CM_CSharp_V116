using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3240_Attributes {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for Attributes on Player class...", ref timer);
            object[] attributeObjectArray = typeof(Exercise.Player).GetCustomAttributes(false);

            object isPlayerAttributeObject = null;
            foreach (object attributeObject in attributeObjectArray) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Found {attributeObject.GetType().Name} attribute...", ref timer);
                if (attributeObject.GetType().Name == "IsPlayerAttribute") {
                    isPlayerAttributeObject = attributeObject;
                }
            }


            if (isPlayerAttributeObject == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find a IsPlayer attribute!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
