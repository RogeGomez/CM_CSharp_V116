using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3240_Attributes {


    public class Exercise {


        [IsPlayer]
        public class Player {
        }

        public class IsPlayerAttribute : Attribute {
        }

    }

}
