using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1100_DataTypes {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private void Awake() {
            Instance = this;
        }

        public void Result(string myString) {
            textMeshUI.text = "Received string: " + myString + "\n\n";
            if (myString.Contains('"')) {
                textMeshUI.text += SUCCESS;
                ExerciseCompletionTester.ExerciseCompleted();
            } else {
                textMeshUI.text += INCORRECT + "\nNo quote \" found, remember it's the double quote, not single";
            }
        }

    }

}
