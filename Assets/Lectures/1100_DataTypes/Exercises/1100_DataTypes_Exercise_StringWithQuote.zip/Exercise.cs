using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1100_DataTypes {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // This is a Comment, the code ignores these lines of code that start with //
            // Comments are covered in detail in a future lecture

            // Modify this string value to include a quote " inside the string
            string myString = "Code Monkey";

            // Press Play in Unity to test your code


            // Don't modify this line of code, it's for testing when the exercise is completed
            ExerciseSceneTester.Instance.Result(myString);
        }

    }

}
