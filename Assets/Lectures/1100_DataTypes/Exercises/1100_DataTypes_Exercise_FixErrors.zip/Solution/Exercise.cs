using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1100_DataTypes {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // This is a Comment, the code ignores these lines of code that start with //
            // Comments are covered in detail in a future lecture

            // Fix these various errors
            int myInt = 20;
            double myDouble = 45.0;
            float myFloat = 12.2f;
            string myString = "Code Monkey";
            bool myBool = true;
        }

    }

}
