using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* COMPILATION BLOCKER
namespace CodeMonkey.CSharpCourse.L1100_DataTypes {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // This is a Comment, the code ignores these lines of code that start with //
            // Comments are covered in detail in a future lecture

            // Fix these various errors
            int myInt = 20.2;
            double myDouble = 45m;
            float myFloat = 12.2;
            string myString = Code Monkey;
            bool myBool = True;
        }

    }

}
COMPILATION BLOCKER */