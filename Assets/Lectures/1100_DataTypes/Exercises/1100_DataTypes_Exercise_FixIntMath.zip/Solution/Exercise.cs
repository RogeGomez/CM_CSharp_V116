using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1100_DataTypes {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // This is a Comment, the code ignores these lines of code that start with //
            // Comments are covered in detail in a future lecture

            int healthAmount = 1;
            int healthAmountMax = 10;

            // Fix the issue with healthNormalized being 0 and not 0.1 like it should
            float healthNormalized = (float)healthAmount / healthAmountMax;


            // Press Play in Unity to test your code


            // Don't modify this line of code, it's for testing when the exercise is completed
            ExerciseSceneTester.Instance.Result(healthNormalized);
        }

    }

}
