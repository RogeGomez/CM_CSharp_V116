using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1100_DataTypes {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private void Awake() {
            Instance = this;
        }

        public void Result(float healthNormalized) {
            textMeshUI.text = "healthNormalized: " + healthNormalized + " == 0.1";
            if (healthNormalized == 0.1f) {
                textMeshUI.text += "\n\n<color=#00ff00>SUCCESS!</color>";
                ExerciseCompletionTester.ExerciseCompleted();
            } else {
                textMeshUI.text += "\n\n<color=#aa1111>Incorrect!</color>";
            }
        }

    }

}
