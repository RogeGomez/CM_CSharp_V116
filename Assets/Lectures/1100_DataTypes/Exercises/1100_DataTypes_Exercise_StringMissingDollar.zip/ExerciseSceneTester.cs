using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1100_DataTypes {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private void Awake() {
            Instance = this;
        }

        public void Result(string firstString, string secondString) {
            textMeshUI.text = "First string: " + firstString + "\n";
            textMeshUI.text += "Second string: " + secondString + "\n\n";
            if (firstString == secondString) {
                textMeshUI.text += SUCCESS;
                ExerciseCompletionTester.ExerciseCompleted();
            } else {
                textMeshUI.text += INCORRECT + "\nStrings are different";
            }
        }

    }

}
