using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1100_DataTypes {


    public class Exercise : MonoBehaviour {


        private void Start() {
            // This is a Comment, the code ignores these lines of code that start with //
            // Comments are covered in detail in a future lecture

            // Define variables here to fix the errors
            bool myBool = false;
            int myInt = 1;
            float myFloat = 3.5f;
            string myString = "Code Monkey";


            // Don't modify this line of code
            // This is a function to test when the exercise is completed
            Result(myBool, myInt, myFloat, myString);
        }

        private void Result(bool myBool, int myInt, float myFloat, string myString) {
        }

    }

}
