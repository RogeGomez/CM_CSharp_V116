using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2190_Delegates {


    public class Exercise : MonoBehaviour {


        // Define a delegate that returns void and has a string parameter
        public delegate void SayHelloDelegate(string str);


        private void Start() {
            // Create a variable of the delegate type
            // Then assign it to a function (either lambda or separate function)
            // That function should inside it do a Debug.Log($"Hello {name}!");

            SayHelloDelegate sayHello = (string name) => {
                Debug.Log($"Hello {name}!");
            };

            // Call the ExerciseValidate(); function and pass in the variable
            ExerciseValidate(sayHello);
        }



        private void ExerciseValidate(object sayHelloAction) {
            ExerciseSceneTester.Instance.ExerciseValidate(sayHelloAction);
        }

    }

}
