using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2190_Delegates {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private string lastLogMessage;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);
        }

        public void ExerciseValidate(object sayHelloAction) {
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseValidate() was called...", ref timer);

            Type delegateType = null;

            foreach (Type type in typeof(Exercise).GetNestedTypes(BindingFlags.Public | BindingFlags.NonPublic)) {
                if (type.IsSubclassOf(typeof(Delegate))) {
                    delegateType = type;
                }
            }

            if (delegateType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Did not find any delegate type!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found delegate type " + delegateType.Name + "...", ref timer);

            if (!(sayHelloAction is Delegate)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Function called with object as argument that is NOT a delegate!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Function called with a delegate object as an argument...", ref timer);

            MethodInfo methodInfo = ((Delegate)sayHelloAction).GetMethodInfo();

            if (methodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "Object passed in does not have one parameter!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (methodInfo.GetParameters()[0].ParameterType != typeof(string)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Object passed in does not have one parameter of type string!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Object passed in as argument correctly has one string parameter...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Calling delegate with parameter 'Code Monkey'...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Reading log...", ref timer);

            Application.logMessageReceived += Application_logMessageReceived;
            (sayHelloAction as Delegate).DynamicInvoke(new object[] { "Code Monkey" });
            Application.logMessageReceived -= Application_logMessageReceived;

            string result = lastLogMessage;
            ExerciseUtils.TimedMessage(textMeshUI, $"Result: '{result}', expected 'Hello Code Monkey!'", ref timer);

            if (result != "Hello Code Monkey!") {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            ExerciseCompletionTester.ExerciseCompleted();
        }

        private void Application_logMessageReceived(string condition, string stackTrace, LogType type) {
            lastLogMessage = condition;
        }

    }

}
