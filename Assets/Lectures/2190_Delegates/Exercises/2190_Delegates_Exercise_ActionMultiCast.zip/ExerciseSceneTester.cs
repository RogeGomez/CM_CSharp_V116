using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2190_Delegates {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private int exerciseValidateAmount;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "...", ref timer, add: false);

            Exercise exercise = new Exercise();

            Action action = exercise.TestExercise();

            ExerciseUtils.TimedMessage(textMeshUI, "Checking delegate invocation list...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, action.GetInvocationList().Length + ", expected: 4...", ref timer);

            if (action.GetInvocationList().Length != 4) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Calling action()...", ref timer);
            action();
            ExerciseUtils.TimedMessage(textMeshUI, "Checking ExerciseValidate() count...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, exerciseValidateAmount + ", expected: 3...", ref timer);

            if (exerciseValidateAmount != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            ExerciseCompletionTester.ExerciseCompleted();
        }

        public void ExerciseValidate() {
            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseValidate();", ref timer);
            exerciseValidateAmount++;
        }

    }

}
