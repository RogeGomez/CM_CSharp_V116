using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2190_Delegates {


    public class Exercise {


        public Action TestExercise() {
            Action action = () => { };

            // Add 3 function calls of ExerciseValidate() to action with multi-cast


            return action;
        }
    

        private void ExerciseValidate() {
            ExerciseSceneTester.Instance.ExerciseValidate();
        }

    }

}
