using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2190_Delegates {


    public class Exercise {

        // Don't modify this array
        private int[] intArray = new int[] { 1, 3, -5, 56, 8, 12 };


        public Exercise() {
            // Call ValidateElements and pass in a function to validate if a number if below 10 and above 0
            ValidateElements((int number) => number < 10 && number > 0);
        }


        public void ValidateElements(Func<int, bool> validateFunc) {
            foreach (int number in intArray) {
                if (validateFunc(number)) {
                    ExerciseSceneTester.Instance.ValidNumber(number);
                } else {
                    ExerciseSceneTester.Instance.InvalidNumber(number);
                }
            }
        }
    

    }

}
