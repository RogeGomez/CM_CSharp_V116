using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2190_Delegates {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private List<int> numberList = new List<int>();


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);

            new Exercise();

            ExerciseUtils.TimedMessage(textMeshUI, "Checking valid number count...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, numberList.Count + ", expected: 3...", ref timer);

            if (numberList.Count != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            ExerciseCompletionTester.ExerciseCompleted();
        }

        public void ValidNumber(int number) {
            ExerciseUtils.TimedMessage(textMeshUI, "Valid number: " + number, ref timer);
            numberList.Add(number);
        }

        public void InvalidNumber(int number) {
            ExerciseUtils.TimedMessage(textMeshUI, "Invalid number: " + number, ref timer);
        }

    }

}
