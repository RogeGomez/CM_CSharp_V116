using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2190_Delegates {


    public class Exercise {


        public Exercise() {
            // Call ExerciseSetup and pass in an Action (using a Lambda expression)
            // where inside that Action you do Debug.Log("Action"); and call ExerciseValidate();
            
        }
    

        private void ExerciseSetup(Action action) {
            ExerciseSceneTester.Instance.ExerciseSetup(action);
        }


        private void ExerciseValidate() {
            ExerciseSceneTester.Instance.ExerciseValidate();
        }

    }

}
