using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2190_Delegates {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private Action action;
        private string lastMessage;
        private bool gotExerciseValidate;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);

            if (!ExerciseUtils.TryGetLectureExerciseCSText("2190", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not read code file!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for Lambda expression in code...", ref timer);

            if (!lectureText.Contains("=>")) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find Lambda expression in code!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found Lambda expression...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "Constructing Exercise...", ref timer);

            Application.logMessageReceived += Application_logMessageReceived;
            Exercise exercise = new Exercise();
            action();
            Application.logMessageReceived -= Application_logMessageReceived;

            ExerciseUtils.TimedMessage(textMeshUI, "Expecting Debug.Log \"Action\"...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Message: " + lastMessage + "...", ref timer);

            if (lastMessage != "Action") {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!gotExerciseValidate) {
                ExerciseUtils.TimedMessage(textMeshUI, "ExerciseValidate() was not called!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "ExerciseValidate()...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            ExerciseCompletionTester.ExerciseCompleted();
        }

        private void Application_logMessageReceived(string condition, string stackTrace, LogType type) {
            lastMessage = condition;
        }

        public void ExerciseSetup(Action action) {
            this.action = action;
        }

        public void ExerciseValidate() {
            gotExerciseValidate = true;
        }

    }

}
