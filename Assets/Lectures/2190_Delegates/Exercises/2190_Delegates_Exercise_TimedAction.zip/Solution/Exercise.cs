using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2190_Delegates {


    public class Exercise {


        private int tick;
        private Action action;


        // Write a SetAction function that receives a Action and stores it in a field
        private void SetAction(Action action) {
            this.action = action;
        }


        // Write a TickTimer function, it should do tick--; and if tick <= 0 it should run the Action.
        private void TickTimer() {
            tick--;
            if (tick <= 0) {
                action();
            }
        }




        public void SetTick(int tick) {
            this.tick = tick;
        }

    }

}
