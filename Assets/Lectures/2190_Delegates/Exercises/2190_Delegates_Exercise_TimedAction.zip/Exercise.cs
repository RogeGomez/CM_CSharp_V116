using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2190_Delegates {


    public class Exercise {


        private int tick;


        // Write a SetAction function that receives a Action and stores it in a field
        


        // Write a TickTimer function, it should do tick--; and if tick <= 0 it should run the Action.




        public void SetTick(int tick) {
            this.tick = tick;
        }

    }

}
