using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2190_Delegates {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for SetAction function...", ref timer, add: false);

            MethodInfo setActionMethodInfo = typeof(Exercise).GetMethod("SetAction", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (setActionMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find SetAction function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found SetAction function...", ref timer);

            if (setActionMethodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "SetAction function does not have one parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            if (setActionMethodInfo.GetParameters()[0].ParameterType != typeof(Action)) {
                ExerciseUtils.TimedMessage(textMeshUI, "SetAction function does not have a Action parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "SetAction function correctly has one Action parameter...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling SetAction(() => ExerciseComplete())...", ref timer);

            Exercise exercise = new Exercise();
            bool hasExerciseCompleted = false;
            Action tickAction = () => hasExerciseCompleted = true;
            setActionMethodInfo.Invoke(exercise, new object[] { tickAction });




            ExerciseUtils.TimedMessage(textMeshUI, "Calling SetTick(3)...", ref timer);

            exercise.SetTick(3);



            MethodInfo tickTimerMethodInfo = typeof(Exercise).GetMethod("TickTimer", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (tickTimerMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find TickTimer function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found TickTimer function...", ref timer);

            if (tickTimerMethodInfo.GetParameters().Length != 0) {
                ExerciseUtils.TimedMessage(textMeshUI, "TickTimer has parameters!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\nTickTimer function correctly has no parameters...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TickTimer()...", ref timer);
            tickTimerMethodInfo.Invoke(exercise, new object[] { });

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TickTimer()...", ref timer);
            tickTimerMethodInfo.Invoke(exercise, new object[] { });

            ExerciseUtils.TimedMessage(textMeshUI, "Calling TickTimer()...", ref timer);
            tickTimerMethodInfo.Invoke(exercise, new object[] { });

            if (!hasExerciseCompleted) {
                ExerciseUtils.TimedMessage(textMeshUI, "Action did not run!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Action correctly ran...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            ExerciseCompletionTester.ExerciseCompleted();
        }

    }

}
