using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* COMPILATION BLOCKER
namespace CodeMonkey.CSharpCourse.L2190_Delegates {


    public class Exercise {



        public Exercise() {
            // Fix this error
            Func<int, int> isDeadFunc = (int healthAmount) => {
                return healthAmount <= 0;
            };

            // Don't modify this code
            int healthAmount = 56;
            if (isDeadFunc(healthAmount)) {
                // Is dead!
            }
        }    

    }

}
COMPILATION BLOCKER */