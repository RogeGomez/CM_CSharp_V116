using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2230_ConstantsReadonly {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;

        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for 'PLAYER_SPEED'...", ref timer, add: false);
            FieldInfo playerSpeedField = typeof(Exercise).GetField("PLAYER_SPEED", BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance);

            if (playerSpeedField == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'PLAYER_SPEED' constant!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (!playerSpeedField.IsLiteral || playerSpeedField.IsInitOnly) {
                ExerciseUtils.TimedMessage(textMeshUI, "'PLAYER_SPEED' is not a constant!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found constant 'PLAYER_SPEED'...", ref timer);

            if (playerSpeedField.FieldType != typeof(int)) {
                ExerciseUtils.TimedMessage(textMeshUI, "'PLAYER_SPEED' is not of type int!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            int playerSpeedValue = (int)playerSpeedField.GetValue(null);
            ExerciseUtils.TimedMessage(textMeshUI, $"Getting PLAYER_SPEED = {playerSpeedValue}, expected = 5", ref timer);

            if (playerSpeedValue != 5) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "constant PLAYER_SPEED correct!", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);





            ExerciseUtils.TimedMessage(textMeshUI, "Looking for 'DEFAULT_PLAYER'...", ref timer);
            FieldInfo defaultPlayerField = typeof(Exercise).GetField("DEFAULT_PLAYER", BindingFlags.Public | BindingFlags.Static);

            if (defaultPlayerField == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find static 'DEFAULT_PLAYER' field!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (defaultPlayerField.IsLiteral || !defaultPlayerField.IsInitOnly) {
                ExerciseUtils.TimedMessage(textMeshUI, "'DEFAULT_PLAYER' is not a readonly field!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found constant 'DEFAULT_PLAYER'...", ref timer);

            if (defaultPlayerField.FieldType != typeof(Exercise.Player)) {
                ExerciseUtils.TimedMessage(textMeshUI, "'DEFAULT_PLAYER' is not of type Player!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            Exercise.Player defaultPlayerValue = (Exercise.Player)defaultPlayerField.GetValue(null);
            ExerciseUtils.TimedMessage(textMeshUI, $"Getting DEFAULT_PLAYER = {defaultPlayerValue}", ref timer);

            if (defaultPlayerValue == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "DEFAULT_PLAYER is null!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "All correct!", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
