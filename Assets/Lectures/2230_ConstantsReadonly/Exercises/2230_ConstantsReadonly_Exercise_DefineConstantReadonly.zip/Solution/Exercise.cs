using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2230_ConstantsReadonly {


    public class Exercise : MonoBehaviour {

        // Define here an int constant PLAYER_SPEED with value of 5
        public const int PLAYER_SPEED = 5;


        // Define a static readonly Player field named DEFAULT_PLAYER and construct a new Player();
        public static readonly Player DEFAULT_PLAYER = new Player();






        // Used for testing
        public class Player { }

    }

}
