using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2230_ConstantsReadonly {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;

        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for 'DEFAULT_PLAYER'...", ref timer, add: false);

            Type exerciseType = null;
            foreach (Type type in Assembly.GetExecutingAssembly().GetTypes()) {
                if (type.ToString() == "CodeMonkey.CSharpCourse.L2230_ConstantsReadonly.Exercise") {
                    exerciseType = type;
                    break;
                }
            }

            FieldInfo defaultPlayerField = exerciseType.GetField("DEFAULT_PLAYER", BindingFlags.Public | BindingFlags.Static);

            if (defaultPlayerField == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find static 'DEFAULT_PLAYER' field!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (defaultPlayerField.IsLiteral || !defaultPlayerField.IsInitOnly) {
                ExerciseUtils.TimedMessage(textMeshUI, "'DEFAULT_PLAYER' is not a readonly field!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found constant 'DEFAULT_PLAYER'...", ref timer);

            Type playerType = exerciseType.GetNestedType("Player", BindingFlags.Instance | BindingFlags.Public);

            if (defaultPlayerField.FieldType != playerType) {
                ExerciseUtils.TimedMessage(textMeshUI, "'DEFAULT_PLAYER' is not of type Player!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Getting DEFAULT_PLAYER = {defaultPlayerField.GetValue(null)}", ref timer);

            if (defaultPlayerField.GetValue(null) == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "DEFAULT_PLAYER is null!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            ExerciseUtils.TimedMessage(textMeshUI, "All correct!", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
