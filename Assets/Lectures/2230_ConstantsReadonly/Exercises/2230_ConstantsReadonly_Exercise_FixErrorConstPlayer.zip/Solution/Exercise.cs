using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2230_ConstantsReadonly {


    public class Exercise : MonoBehaviour {



        // Fix this error
        public readonly static Player DEFAULT_PLAYER = new Player();






        public class Player { }

    }

}
