using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/* COMPILATION BLOCKER
namespace CodeMonkey.CSharpCourse.L2230_ConstantsReadonly {


    public class Exercise : MonoBehaviour {



        // Fix this error
        public const Player DEFAULT_PLAYER = new Player();






        public class Player { }

    }

}
COMPILATION BLOCKER */