using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3210_DataBoxing {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            MethodInfo boxMethodInfo =
                typeof(Exercise).GetMethod("Box", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);

            if (boxMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not find Box function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Found Box function...", ref timer);

            if (boxMethodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Box function does not have one parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (boxMethodInfo.GetParameters()[0].ParameterType != typeof(int)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Box function does not have an int parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Box function correctly has an int parameter...", ref timer);

            if (boxMethodInfo.ReturnType != typeof(object)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Box function does not return object!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Box function correctly returns object...", ref timer);

            Exercise exercise = new Exercise();
            ExerciseUtils.TimedMessage(textMeshUI, "Calling Box(56)...", ref timer);
            object obj = boxMethodInfo.Invoke(exercise, new object[] { 56 });
            if (!(obj is int)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Box function did not return a boxed object!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            int intValue = (int)obj;
            if (intValue != 56) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Box function did not box the int 56!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Box function correctly boxed 56...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}