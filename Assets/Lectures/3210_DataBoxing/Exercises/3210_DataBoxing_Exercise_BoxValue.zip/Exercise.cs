using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3210_DataBoxing {


    public class Exercise {

        // Define a function called Box that takes an int parameter, boxes it and returns the object.
        

    }

}
