using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3040_StaticConstructor {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private List<string> messageList;


        private void Awake() {
            Instance = this;

            messageList = new List<string>();
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Checking Log, should be empty...", ref timer, add: false);

            Application.logMessageReceived += Application_logMessageReceived;
            ExerciseUtils.TimedMessage(textMeshUI, "Calling Exercise.TestFunction()...", ref timer);

            Exercise.TestFunction();


            ExerciseUtils.TimedMessage(textMeshUI, "Constructing new Exercise()...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Should not log again...", ref timer);

            new Exercise();

            if (messageList.Count != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            Application.logMessageReceived -= Application_logMessageReceived;



            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        private void Application_logMessageReceived(string condition, string stackTrace, LogType type) {
            messageList.Add(condition);

            ExerciseUtils.TimedMessage(textMeshUI, "Log: " + condition, ref timer);
        }

    }

}
