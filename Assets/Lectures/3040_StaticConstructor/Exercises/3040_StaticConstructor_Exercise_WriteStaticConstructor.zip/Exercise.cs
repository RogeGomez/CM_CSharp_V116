using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3040_StaticConstructor {


    public class Exercise {

        // Define a static constructor and inside it call Debug.Log("Init");
        


        public Exercise() {
            // ...
        }

        public static void TestFunction() {
            // ...
        }


    }



}