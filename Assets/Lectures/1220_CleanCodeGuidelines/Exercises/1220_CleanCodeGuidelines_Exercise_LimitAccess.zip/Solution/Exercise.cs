using CodeMonkey.CSharpCourse.L2290_IntermediateProject;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1220_CleanCodeGuidelines {


    public class Exercise {


        // Only modify the access modifiers

        private int speed;
        private string playerName;


        public void SetPlayerName(string playerName) {
            this.playerName = playerName;
        }

        public void SetSpeed(int speed) {
            this.speed = speed;
        }

        public void DoPlayerLogic() {
            HandleMovement();
            HandleInteractions();
        }

        private void HandleMovement() {
            // ...
        }

        private void HandleInteractions() {
            // ...
        }

    }

}
