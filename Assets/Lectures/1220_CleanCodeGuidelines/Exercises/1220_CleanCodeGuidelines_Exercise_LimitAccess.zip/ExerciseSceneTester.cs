using System;
using CodeMonkey.CSharpCourse.Companion;
using CodeMonkey.CSharpCourse.Interactive;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using System.Reflection;
using CodeMonkey.Utils;
using UnityEngine.Windows;

namespace CodeMonkey.CSharpCourse.L1220_CleanCodeGuidelines {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string LECTURE_CODE = "1220";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;

        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            bool somethingWrong = false;

            ExerciseUtils.TimedMessage(textMeshUI, "Checking speed field", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Should be private so no one can modify it directly...", ref timer);

            FieldInfo fieldInfo = typeof(Exercise).GetField("speed", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (fieldInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find field!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (fieldInfo.IsPublic) {
                somethingWrong = true;
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Checking playerName field", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Should be private so no one can modify it directly...", ref timer);

            fieldInfo = typeof(Exercise).GetField("playerName", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (fieldInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find field!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (fieldInfo.IsPublic) {
                somethingWrong = true;
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }


            ExerciseUtils.TimedMessage(textMeshUI, "Checking SetPlayerName()", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Should be public so something like a UI class can change it...", ref timer);

            MethodInfo methodInfo = typeof(Exercise).GetMethod("SetPlayerName", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (methodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (methodInfo.IsPrivate) {
                somethingWrong = true;
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }



            ExerciseUtils.TimedMessage(textMeshUI, "Checking SetSpeed()", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Should be public so some kind of Upgrade class can modify it...", ref timer);

            methodInfo = typeof(Exercise).GetMethod("SetSpeed", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (methodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (methodInfo.IsPrivate) {
                somethingWrong = true;
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Checking DoPlayerLogic()", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Should be public so the GameHandler can tell the Player to take an action...", ref timer);

            methodInfo = typeof(Exercise).GetMethod("DoPlayerLogic", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (methodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (methodInfo.IsPrivate) {
                somethingWrong = true;
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Checking HandleMovement()", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Should be private because only the Player class should handle its own movement...", ref timer);

            methodInfo = typeof(Exercise).GetMethod("HandleMovement", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (methodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (methodInfo.IsPublic) {
                somethingWrong = true;
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }



            ExerciseUtils.TimedMessage(textMeshUI, "Checking HandleInteractions()", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Should be private because only the Player class should handle its own interactions...", ref timer);

            methodInfo = typeof(Exercise).GetMethod("HandleInteractions", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (methodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (methodInfo.IsPublic) {
                somethingWrong = true;
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
            }



            if (!somethingWrong) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
                FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
            }
        }

    }

}
