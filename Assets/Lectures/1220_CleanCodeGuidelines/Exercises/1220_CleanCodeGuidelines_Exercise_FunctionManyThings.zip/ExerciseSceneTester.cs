using System;
using CodeMonkey.CSharpCourse.Companion;
using CodeMonkey.CSharpCourse.Interactive;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using System.Reflection;
using CodeMonkey.Utils;

namespace CodeMonkey.CSharpCourse.L1220_CleanCodeGuidelines {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string LECTURE_CODE = "1220";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            MethodInfo[] methodInfoArray = typeof(Exercise).GetMethods(BindingFlags.Instance | BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.NonPublic);

            if (methodInfoArray.Length < 3) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find separate functions!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, $"Class correctly has {methodInfoArray.Length} functions...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
