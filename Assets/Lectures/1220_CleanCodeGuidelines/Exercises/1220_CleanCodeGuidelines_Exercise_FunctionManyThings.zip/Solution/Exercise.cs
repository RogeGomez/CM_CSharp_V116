using CodeMonkey.CSharpCourse.L2290_IntermediateProject;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1220_CleanCodeGuidelines {


    public class Exercise {


        public void TestExercise() {
            SetupPlayer();
            InitializeWorld();
            SpawnEnemies();
        }


        private void SetupPlayer() {
            // Setup Player
            Player player = new Player();
            player.SetHealth(100);
            player.SetSpeed(35f);
            player.SetSkillPoints(10);
        }

        private void InitializeWorld() {
            // Initialize World
            World world = new World();
            world.SetSize(10, 5);
            world.SetPopulationCap(300);
        }

        private void SpawnEnemies() {
            // Spawn Enemies
            int enemyAmount = 10;
            for (int i = 0; i < enemyAmount; i++) {
                new Enemy();
            }
        }



        private class Player {
            public void SetHealth(int healthAmount) { }
            public void SetSpeed(float speed) { }
            public void SetSkillPoints(int skillAmount) { }
        }

        private class World {
            public void SetSize(int width, int height) { }
            public void SetPopulationCap(int amount) { }
        }

        private class Enemy {
        }

    }

}
