using CodeMonkey.CSharpCourse.Companion;
using CodeMonkey.CSharpCourse.Interactive;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1220_CleanCodeGuidelines {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string LECTURE_CODE = "1220";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            textMeshUI.text = "Analyzing code...\n\n";

            LectureSO lectureSO = LectureSO.GetLectureSO(LECTURE_CODE);
            string exerciseFilename = lectureSO.GetLectureFolderPath() + "Exercises/Exercise.cs";

            if (File.Exists(exerciseFilename)) {
                string exerciseFileText = File.ReadAllText(exerciseFilename);
                string exerciseFileTextNoSpaces = exerciseFileText.Replace(" ", "");

                bool superDamageMultiplier = false;
                if (exerciseFileTextNoSpaces.Contains("damageAmount*=superDamageMultiplier;")) {
                    superDamageMultiplier = true;
                }
                bool attackDistance = false;
                if (exerciseFileTextNoSpaces.Contains("if(distance<attackDistance){")) {
                    attackDistance = true;
                }
                bool jumpDistance = false;
                if (exerciseFileTextNoSpaces.Contains("if(distance>jumpDistance){")) {
                    jumpDistance = true;
                }

                if (superDamageMultiplier && attackDistance && jumpDistance) {
                    // Success! Exercise completed!
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, .5f);
                    ExerciseCompletionTester.ExerciseCompleted();
                }
            }
        }

    }

}
