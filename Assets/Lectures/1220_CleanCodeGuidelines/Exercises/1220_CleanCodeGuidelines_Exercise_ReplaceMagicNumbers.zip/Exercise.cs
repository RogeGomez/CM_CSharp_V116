using CodeMonkey.CSharpCourse.L2290_IntermediateProject;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1220_CleanCodeGuidelines {


    public class Exercise : MonoBehaviour {


        // Refactor the code inside this function
        private void TakePlayerAction(Enemy enemy) {
            int damageAmount = 10;
            if (IsSuper()) {
                damageAmount *= 2; // 2 means superDamageMultiplier
            }
            float distance = Vector3.Distance(transform.position, enemy.GetPosition());
            if (distance < 5) { // 5 means attackDistance
                enemy.Attack(damageAmount);
            } else {
                // Enemy too far
                if (distance > 10) { // 10 means jumpDistance
                    Jump();
                } else {
                    MoveTowardsEnemy();
                }
            }
        }




        private void MoveTowardsEnemy() {
            // ...
        }

        private void Jump() {
            // ...
        }

        private bool IsSuper() {
            return true;
        }

        public class Enemy {

            public void Attack(int damageAmount) {
                // ...
            }

            public Vector3 GetPosition() {
                return Vector3.zero;
            }

        }

    }

}
