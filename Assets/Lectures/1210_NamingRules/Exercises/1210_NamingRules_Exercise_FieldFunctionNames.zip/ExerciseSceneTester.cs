using CodeMonkey.CSharpCourse.Interactive;
using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1210_NamingRules {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            textMeshUI.text = "Validating Naming Rules...\n\n";

            ValidateCodeNamingRules();
        }

        private void ValidateCodeNamingRules() {
            float timerIncrement = .5f;
            float timer = timerIncrement;

            // Validate fields
            bool fieldPlayerName = false;
            bool fieldMoveSpeed = false;
            bool fieldIsGrounded = false;
            foreach (FieldInfo fieldInfo in typeof(Exercise).GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)) {
                switch (fieldInfo.Name) {
                    case "playerName":
                        ExerciseUtils.TimedMessage(textMeshUI, "Found 'playerName' field!", timer);
                        timer += timerIncrement;
                        fieldPlayerName = true;
                        break;
                    case "moveSpeed":
                        ExerciseUtils.TimedMessage(textMeshUI, "Found 'moveSpeed' field!", timer);
                        timer += timerIncrement;
                        fieldMoveSpeed = true;
                        break;
                    case "isGrounded":
                        ExerciseUtils.TimedMessage(textMeshUI, "Found 'isGrounded' field!", timer);
                        timer += timerIncrement;
                        fieldIsGrounded = true;
                        break;
                }

                switch (fieldInfo.Name.ToLower()) {
                    case "playername":
                        break;
                }
            }

            // Validate functions
            bool functionTakeDamage = false;
            bool functionMove = false;
            bool functionJump = false;
            foreach (MethodInfo methodInfo in typeof(Exercise).GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)) {
                switch (methodInfo.Name) {
                    case "TakeDamage":
                        ExerciseUtils.TimedMessage(textMeshUI, "Found 'TakeDamage' function!", timer);
                        timer += timerIncrement;
                        functionTakeDamage = true;
                        break;
                    case "Move":
                        ExerciseUtils.TimedMessage(textMeshUI, "Found 'Move' function!", timer);
                        timer += timerIncrement;
                        functionMove = true;
                        break;
                    case "Jump":
                        ExerciseUtils.TimedMessage(textMeshUI, "Found 'Jump' function!", timer);
                        timer += timerIncrement;
                        functionJump = true;
                        break;
                }

                switch (methodInfo.Name.ToLower()) {
                    case "takedamage":
                        break;
                }
            }

            ExerciseUtils.TimedMessage(textMeshUI, "", timer);

            if (fieldPlayerName &&
                fieldMoveSpeed &&
                fieldIsGrounded &&
                functionTakeDamage &&
                functionMove &&
                functionJump) {
                // All found!
                timer += timerIncrement;
                ExerciseUtils.TimedMessage(textMeshUI, "All Naming Rules correct!", timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, timer);
                ExerciseCompletionTester.ExerciseCompleted();
            } else {
                // Missing some fields
                timer += timerIncrement;
                ExerciseUtils.TimedMessage(textMeshUI, "Some fields are not correctly named...", timer);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, timer);
            }
        }

    }

}
