using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1210_NamingRules {


    public class Exercise : MonoBehaviour {

        // Rename the fields to camelCase and the functions to PascalCase.


        private int PLAYERNAME;
        private float moveSpeed;
        private bool IS_Grounded;



        public void take_Damage() {
            // Take damage logic...
        }

        public void MOVE() {
            // Move logic...
        }

        public void Jump() {
            // Jump logic...
        }


    }

}
