using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1210_NamingRules {


    public class Exercise : MonoBehaviour {

        // Rename the fields to camelCase and the functions to PascalCase.


        private int playerName;
        private float moveSpeed;
        private bool isGrounded;



        public void TakeDamage() {
            // Take damage logic...
        }

        public void Move() {
            // Move logic...
        }

        public void Jump() {
            // Jump logic...
        }


    }

}
