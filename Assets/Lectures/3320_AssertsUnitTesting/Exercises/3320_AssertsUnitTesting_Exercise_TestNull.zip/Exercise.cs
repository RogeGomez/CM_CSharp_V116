using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3320_AssertsUnitTesting {


    public class Exercise {


        private string playerName;


        // Write an Assert to test if the playerName is not null
        // Use UnityEngine.Debug.Assert(); and not System.Diagnostics.Assert();
        public void SetPlayerName(string playerName) {
            this.playerName = playerName;
        }

    }

}
