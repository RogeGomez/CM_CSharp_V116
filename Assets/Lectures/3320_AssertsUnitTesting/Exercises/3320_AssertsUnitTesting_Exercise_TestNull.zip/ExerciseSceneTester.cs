using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3320_AssertsUnitTesting {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private string lastMessage = null;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            Exercise exercise = new Exercise();

            ExerciseUtils.TimedMessage(textMeshUI, "Calling SetPlayerName(null)...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "UnityEngine.Debug.Assert() should run and print a message...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "Unpause the game to continue...", ref timer);
            FunctionTimer.Create(() => {
                Application.logMessageReceived += Application_logMessageReceived;
                exercise.SetPlayerName(null);
                Application.logMessageReceived -= Application_logMessageReceived;

                if (lastMessage != null) {
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, .5f);
                    FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, .5f);
                }
            }, timer);

            /*
            if (!ExerciseUtils.TryGetLectureExerciseCSText("3130", out string lectureText)) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Could not read Exercise.cs!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }*/

            //ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            //FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

        private void Application_logMessageReceived(string condition, string stackTrace, LogType type) {
            lastMessage = condition;
            ExerciseUtils.TimedMessage(textMeshUI, $"Got message \"{lastMessage}\"...", 0f);
        }
    }

}
