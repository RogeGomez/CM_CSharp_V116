using System.Collections.Generic;

namespace CodeMonkey.CSharpCourse.L2260_Namespaces {


    public class Exercise {


        public Exercise() {
            // Fix this error
            List<string> nameList = new List<string>();

            nameList.Add("Code Monkey");
        }



    }

}
