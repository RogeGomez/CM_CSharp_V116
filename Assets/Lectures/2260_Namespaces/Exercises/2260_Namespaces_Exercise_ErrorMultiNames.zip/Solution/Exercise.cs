using System;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2260_Namespaces {


    public class Exercise {


        public Exercise() {
            // Fix this error, do not modify the 'using' statements
            float random = UnityEngine.Random.Range(0f, 12f);



            Action action = null;
        }



    }

}
