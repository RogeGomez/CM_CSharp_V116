using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace NamespaceExercise {

    // Place this class inside a namespace, 'NamespaceExercise'
    public class ExerciseNamespacesTest {



    }

}