using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2260_Namespaces {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Waiting...", ref timer, add: false);

            Type exerciseNamespacesTest = null;
            foreach (Type type in Assembly.GetExecutingAssembly().GetTypes()) {
                Debug.Log(type);
                if (type.Name == "ExerciseNamespacesTest") {
                    exerciseNamespacesTest = type;
                    break;
                }
            }

            if (exerciseNamespacesTest == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'ExerciseNamespacesTest'! Did you rename the class?", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found 'ExerciseNamespacesTest' class...", ref timer);

            string testNamespace = exerciseNamespacesTest.Namespace;

            ExerciseUtils.TimedMessage(textMeshUI, "Checking 'ExerciseNamespacesTest' namespace: " + (testNamespace == null ? "null" : testNamespace), ref timer);

            if (testNamespace == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
