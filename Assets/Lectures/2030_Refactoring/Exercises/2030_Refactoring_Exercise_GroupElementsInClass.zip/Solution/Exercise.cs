using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2030_Refactoring {


    public class Exercise : MonoBehaviour {


        public class PlayerStats {
            public int strength;
            public int wisdom;
            public int dexterity;
        }

        private void Start() {
            PlayerStats playerStats = new PlayerStats();
            playerStats.strength = 56;
            playerStats.wisdom = 12;
            playerStats.dexterity = 33;
        }

    }

}
