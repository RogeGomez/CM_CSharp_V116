using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2030_Refactoring {


    public class Exercise : MonoBehaviour {


        public int strength;
        public int wisdom;
        public int dexterity;


        private void Start() {
            strength = 56;
            wisdom = 12;
            dexterity = 33;
        }

    }

}
