using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2030_Refactoring {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            textMeshUI.text = "Looking for nested types...\n";

            float timerIncrease = .5f;
            float timer = timerIncrease;

            foreach (Type type in typeof(Exercise).GetNestedTypes(BindingFlags.Public | BindingFlags.NonPublic)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Found nested type: " + type, timer);
                timer += timerIncrease;

                bool foundStrength = false;
                FieldInfo strengthFieldInfo = type.GetField("strength", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (strengthFieldInfo != null) {
                    foundStrength = true;
                    ExerciseUtils.TimedMessage(textMeshUI, "Found strength field", timer);
                    timer += timerIncrease;
                }

                bool foundWisdom = false;
                FieldInfo wisdomFieldInfo = type.GetField("wisdom", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (wisdomFieldInfo != null) {
                    foundWisdom = true;
                    ExerciseUtils.TimedMessage(textMeshUI, "Found wisdom field", timer);
                    timer += timerIncrease;
                }

                bool foundDexterity = false;
                FieldInfo dexterityFieldInfo = type.GetField("dexterity", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (dexterityFieldInfo != null) {
                    foundDexterity = true;
                    ExerciseUtils.TimedMessage(textMeshUI, "Found dexterity field", timer);
                    timer += timerIncrease;
                }

                if (foundStrength && foundWisdom && foundDexterity) {
                    // Found all
                    ExerciseUtils.TimedMessage(textMeshUI, "Found all nested fields!", timer);
                    timer += timerIncrease;
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, timer);
                    timer += timerIncrease;
                    ExerciseCompletionTester.ExerciseCompleted();
                }
            }
        }

    }

}
