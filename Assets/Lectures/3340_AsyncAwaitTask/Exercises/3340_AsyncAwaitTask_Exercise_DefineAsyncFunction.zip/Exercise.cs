using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3340_AsyncAwaitTask {


    public class Exercise {

        // Modify the function DoSomethingHeavy(); to start ComplexTask();
        // but not get stuck waiting for it to complete
        public void DoSomethingHeavy() {
            ExerciseCompleteBefore();
            
            // Start ComplexTask here but don't freeze the program
            ComplexTask();

            ExerciseCompleteAfter();

            // Wait for ComplexTask to complete here

            ExerciseCompleteAfterComplexTask();
        }


        private void ExerciseCompleteBefore() {
            ExerciseSceneTester.Instance.ExerciseCompleteBefore();
        }

        private void ExerciseCompleteAfter() {
            ExerciseSceneTester.Instance.ExerciseCompleteAfter();
        }

        private void ExerciseCompleteAfterComplexTask() {
            ExerciseSceneTester.Instance.ExerciseCompleteAfterComplexTask();
        }

        private async Task ComplexTask() {
            await Task.Delay(1000);
        }

    }

}
