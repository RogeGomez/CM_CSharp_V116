using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L3340_AsyncAwaitTask {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;
        private float beforeTimer;
        private float afterTimer;
        private float afterComplexTaskTimer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Analyzing code...", ref timer, add: false);

            Exercise exercise = new Exercise();

            MethodInfo doSomethingHeavyMethodInfo = 
                typeof(Exercise).GetMethod("DoSomethingHeavy", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            Type asyncAttributeType = typeof(AsyncStateMachineAttribute);
            Attribute attribute = doSomethingHeavyMethodInfo.GetCustomAttribute(asyncAttributeType);

            if (attribute == null) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Function is not marked as async!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            ExerciseUtils.TimedMessage(textMeshUI, "Function is correctly marked as async...\n", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "Calling DoSomethingHeavy()...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "The program should NOT freeze between the first two calls...", ref timer);
            exercise.DoSomethingHeavy();

            ExerciseUtils.TimedMessage(textMeshUI, $"Before Timer: {beforeTimer.ToString("F2")}", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, $"After Timer: {afterTimer.ToString("F2")}", ref timer);

            if (afterTimer - beforeTimer > .1f) {
                ExerciseUtils.TimedMessage(textMeshUI, $"Program froze for {(afterTimer - beforeTimer).ToString("F2")} seconds!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Program correctly did not freeze between the first two calls...\n", ref timer);

            FunctionTimer.Create(() => {
                timer = 0f;
                ExerciseUtils.TimedMessage(textMeshUI, $"After Complex Task Timer: {afterComplexTaskTimer.ToString("F2")}", ref timer);

                if (afterComplexTaskTimer - afterTimer < .9f) {
                    ExerciseUtils.TimedMessage(textMeshUI, $"Program did not wait for ComplexTask() to end!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                    ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                    return;
                }
                ExerciseUtils.TimedMessage(textMeshUI, "Program correctly waited for ComplexTask() to end...", ref timer);


                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
                FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
            }, timer);
        }

        public void ExerciseCompleteBefore() {
            beforeTimer = Time.realtimeSinceStartup;
        }

        public void ExerciseCompleteAfter() {
            afterTimer = Time.realtimeSinceStartup;
        }

        public void ExerciseCompleteAfterComplexTask() {
            afterComplexTaskTimer = Time.realtimeSinceStartup;
        }

    }

}
