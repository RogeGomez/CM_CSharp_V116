using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2150_ClassIntermediate {


    public class Exercise {



        // Define a function named GetUnitList() that should return a List containing both a Player and an Enemy
        private List<Unit> GetUnitList() {
            return new List<Unit> {
                new Player(),
                new Enemy(),
            };
        }



        public class Enemy : Unit { }

        public class Player : Unit { }

        public class Unit { }


    }

}
