using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using System.Reflection;
using CodeMonkey.Utils;

namespace CodeMonkey.CSharpCourse.L2150_ClassIntermediate {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "...", ref timer, add: false);

            MethodInfo getUnitListMethodInfo = typeof(Exercise).GetMethod("GetUnitList", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (getUnitListMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find GetUnitList function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found GetUnitList function...", ref timer);

            if (getUnitListMethodInfo.GetParameters().Length != 0) {
                ExerciseUtils.TimedMessage(textMeshUI, "GetUnitList function has some parameters!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "GetUnitList correctly has no parameters...", ref timer);

            if (getUnitListMethodInfo.ReturnType != typeof(List<Exercise.Unit>)) {
                ExerciseUtils.TimedMessage(textMeshUI, "GetUnitList does not return List<Unit>!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "GetUnitList correctly returns List<Unit>...", ref timer);

            Exercise exercise = new Exercise();
            List<Exercise.Unit> unitList = (List<Exercise.Unit>) getUnitListMethodInfo.Invoke(exercise, new object[] { });

            bool foundPlayer = false;
            bool foundEnemy = false;

            foreach (Exercise.Unit unit in unitList) {
                if (unit is Exercise.Player) {
                    foundPlayer = true;
                }
                if (unit is Exercise.Enemy) {
                    foundEnemy = true;
                }
            }

            if (!foundPlayer) {
                ExerciseUtils.TimedMessage(textMeshUI, "Unit List does not contain a Player object!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Unit List contains a Player object...", ref timer);

            if (!foundEnemy) {
                ExerciseUtils.TimedMessage(textMeshUI, "Unit List does not contain a Enemy object!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Unit List contains a Enemy object...", ref timer);



            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }


    }

}
