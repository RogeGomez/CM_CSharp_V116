using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2150_ClassIntermediate {


    public class Exercise {



        // Define a function name 'MoveUnit' that takes one parameter which should work with a Player or Enemy or anything that extends Unit
        



        public class Enemy : Unit { }

        public class Player : Unit { }

        public class Unit { }


    }

}
