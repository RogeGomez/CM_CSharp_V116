using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using System.Reflection;
using CodeMonkey.Utils;

namespace CodeMonkey.CSharpCourse.L2150_ClassIntermediate {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "...", ref timer, add: false);

            MethodInfo moveUnitMethodInfo = typeof(Exercise).GetMethod("MoveUnit", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (moveUnitMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find MoveUnit function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found MoveUnit function...", ref timer);

            if (moveUnitMethodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "MoveUnit function does not have exactly one parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "MoveUnit function has exactly one parameter...", ref timer);

            if (moveUnitMethodInfo.GetParameters()[0].ParameterType != typeof(Exercise.Unit)) {
                ExerciseUtils.TimedMessage(textMeshUI, "MoveUnit function parameter is not of type Unit!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Parameter is correctly of type Unit...", ref timer);

            Exercise exercise = new Exercise();

            ExerciseUtils.TimedMessage(textMeshUI, "Calling function with a Player object...", ref timer);
            moveUnitMethodInfo.Invoke(exercise, new object[] { new Exercise.Player() });
            ExerciseUtils.TimedMessage(textMeshUI, "Worked!", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling function with a Enemy object...", ref timer);
            moveUnitMethodInfo.Invoke(exercise, new object[] { new Exercise.Enemy() });
            ExerciseUtils.TimedMessage(textMeshUI, "Worked!", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Calling function with a Unit object...", ref timer);
            moveUnitMethodInfo.Invoke(exercise, new object[] { new Exercise.Unit() });
            ExerciseUtils.TimedMessage(textMeshUI, "Worked!", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }


    }

}
