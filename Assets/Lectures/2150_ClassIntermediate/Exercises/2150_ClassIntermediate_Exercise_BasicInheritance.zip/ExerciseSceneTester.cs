using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using System.Reflection;
using CodeMonkey.Utils;

namespace CodeMonkey.CSharpCourse.L2150_ClassIntermediate {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "...", ref timer, add: false);

            Type unitType = typeof(Exercise).GetNestedType("Unit", BindingFlags.Public | BindingFlags.NonPublic);
            Type enemyType = typeof(Exercise).GetNestedType("Enemy", BindingFlags.Public | BindingFlags.NonPublic);
            Type playerType = typeof(Exercise).GetNestedType("Player", BindingFlags.Public | BindingFlags.NonPublic);

            if (unitType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'Unit' class!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found 'Unit' class...", ref timer);

            if (enemyType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'Enemy' class!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found 'Enemy' class...", ref timer);

            if (playerType == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'Player' class!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found 'Player' class...", ref timer);

            if (!enemyType.IsSubclassOf(unitType)) {
                ExerciseUtils.TimedMessage(textMeshUI, "'Enemy' class does not inherit 'Unit'!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "'Enemy' class correctly inherits from 'Unit'...", ref timer);

            if (!playerType.IsSubclassOf(unitType)) {
                ExerciseUtils.TimedMessage(textMeshUI, "'Player' class does not inherit 'Unit'!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "'Player' class correctly inherits from 'Unit'...", ref timer);

            MethodInfo getSpeedMethodInfo = unitType.GetMethod("GetSpeed", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

            if (getSpeedMethodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find 'GetSpeed()' function!", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found 'GetSpeed()' function...", ref timer);

            if (getSpeedMethodInfo.ReturnType != typeof(int)) {
                ExerciseUtils.TimedMessage(textMeshUI, "'GetSpeed()' does not return int", ref timer);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            object unitObject = Activator.CreateInstance(unitType);
            int speed = (int)getSpeedMethodInfo.Invoke(unitObject, new object[] { });

            ExerciseUtils.TimedMessage(textMeshUI, $"Calling 'Unit.GetSpeed()' = {speed}, expected 3", ref timer);

            if (speed != 3) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }


            object playerObject = Activator.CreateInstance(playerType);
            int playerSpeed = (int)getSpeedMethodInfo.Invoke(playerObject, new object[] { });

            ExerciseUtils.TimedMessage(textMeshUI, $"Calling 'Player.GetSpeed()' = {playerSpeed}, expected 5", ref timer);

            if (playerSpeed != 5) {
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }


    }

}
