using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2150_ClassIntermediate {


    public class Exercise : MonoBehaviour {


        // Define a base Unit class, with a int GetSpeed(); function that returns 3


        // Define a Enemy class that inherits from Unit


        // Define a Player class that inherits from Unit and overrides the GetSpeed(); function to return 5



    }

}
