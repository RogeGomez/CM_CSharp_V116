using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2080_Recursion {


    public class Exercise : MonoBehaviour {


        // Write a recursive function that calls itself
        // Inside it call ExerciseValidate();
        // Be careful not to write an infinite loop or Unity will crash!
        private void Recursion(int iteration) {
            if (iteration <= 0) {
                return;
            } else {
                ExerciseValidate();

                Recursion(iteration - 1);
            }
        }



        private void Start() {
            // Start the recursive function from here
            Recursion(3);
        }


        // Don't touch this one, it's used to make the Exercise work
        public void ExerciseValidate() {
            ExerciseSceneTester.Instance.ExerciseValidate();
        }

    }

}
