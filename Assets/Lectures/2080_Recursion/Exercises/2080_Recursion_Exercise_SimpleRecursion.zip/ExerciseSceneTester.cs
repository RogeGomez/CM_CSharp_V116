using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2080_Recursion {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private int iterations;
        private float timer;

        private void Awake() {
            Instance = this;

            iterations = 0;

            ExerciseUtils.TimedMessage(textMeshUI, "Waiting for function call...", ref timer, add: false);
        }

        private void Start() {
            FunctionTimer.Create(() => {
                ExerciseUtils.TimedMessage(textMeshUI, $"Got {iterations} iterations, expected 3\n", ref timer);

                if (iterations == 3) {
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
                    FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
                } else {
                    ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                }
            }, 0.01f);
        }

        public void ExerciseValidate() {
            iterations++;
            ExerciseUtils.TimedMessage(textMeshUI, $"Got iteration! ({iterations})", ref timer);
        }

    }

}
