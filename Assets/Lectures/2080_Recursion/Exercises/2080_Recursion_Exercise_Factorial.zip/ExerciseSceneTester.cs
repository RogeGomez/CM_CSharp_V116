using CodeMonkey.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2080_Recursion {


    public class ExerciseSceneTester : MonoBehaviour {


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;
        }

        private void Start() {
            ExerciseUtils.TimedMessage(textMeshUI, "Looking for a Factorial function...", ref timer, add: false);

            MethodInfo methodInfo = null;
            foreach (MethodInfo testMethodInfo in typeof(Exercise).GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)) {
                methodInfo = testMethodInfo;
                ExerciseUtils.TimedMessage(textMeshUI, "Found function " + methodInfo.Name, ref timer);
                break;
            }

            if (methodInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find any function!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            if (methodInfo.ReturnType != typeof(int)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Function does not return 'int'!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Function does correctly return 'int'...", ref timer);

            if (methodInfo.GetParameters().Length != 1) {
                ExerciseUtils.TimedMessage(textMeshUI, "Function does not have exactly 1 parameter!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }
            if (methodInfo.GetParameters()[0].ParameterType != typeof(int)) {
                ExerciseUtils.TimedMessage(textMeshUI, "Function parameter is not of type 'int'!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Function correctly returns 'int' and has a single 'int' parameter...", ref timer);

            ExerciseUtils.TimedMessage(textMeshUI, "Testing calling function with parameter 5...", ref timer);

            Exercise exercise = new Exercise();
            int result = (int)methodInfo.Invoke(exercise, new object[] { 5 });

            ExerciseUtils.TimedMessage(textMeshUI, "Result: " + result + ", expected: 120", ref timer);

            if (result != 120) {
                ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
