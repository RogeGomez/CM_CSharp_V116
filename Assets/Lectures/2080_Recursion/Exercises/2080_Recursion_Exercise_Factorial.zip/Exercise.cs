using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L2080_Recursion {


    public class Exercise {

        // Write a function that returns int and takes an int parameter
        // Inside the function, use recursion to calculate the Factorial of a given number
        // The Factorial is the product of all positive integers.
        // For example the factorial of 3 is: 3 * 2 * 1;
        // The factorial of n is: n * (n - 1) * (n - 2) * ... * 1;
        // Be CAREFUL not to make an infinite loop!



    }

}
