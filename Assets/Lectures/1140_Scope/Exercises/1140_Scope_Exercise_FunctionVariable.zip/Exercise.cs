using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* COMPILATION BLOCKER
namespace CodeMonkey.CSharpCourse.L1140_Scope {


    public class Exercise : MonoBehaviour {


        private void Start() {
            int age = 35;

            // Fix the error, modify the function to receive the variable as a parameter so it can be used in that scope.
            PrintAge();
        } 

        private void PrintAge() {
            Debug.Log(age);
        }


    }

}
COMPILATION BLOCKER */