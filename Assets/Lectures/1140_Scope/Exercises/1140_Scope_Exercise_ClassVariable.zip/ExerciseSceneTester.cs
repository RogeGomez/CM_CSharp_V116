using CodeMonkey.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace CodeMonkey.CSharpCourse.L1140_Scope {


    public class ExerciseSceneTester : MonoBehaviour {


        private const string SUCCESS = "<color=#00ff00>SUCCESS!</color>";
        private const string INCORRECT = "<color=#aa1111>Incorrect!</color>";


        public static ExerciseSceneTester Instance { get; private set; }


        [SerializeField] private TextMeshProUGUI textMeshUI;


        private float timer;


        private void Awake() {
            Instance = this;

            ExerciseUtils.TimedMessage(textMeshUI, "", ref timer, add: false);
        }

        private void Start() {
            Type exerciseType = typeof(ExerciseSceneTester).Assembly.GetType("CodeMonkey.CSharpCourse.L1140_Scope.Exercise");
            if (exerciseType == null) {
                return;
            }

            FieldInfo ageFieldInfo = exerciseType.GetField("age", BindingFlags.Public | BindingFlags.Instance | BindingFlags.NonPublic);

            ExerciseUtils.TimedMessage(textMeshUI, "Looking for a Class variable named 'age'...", ref timer);

            if (ageFieldInfo == null) {
                ExerciseUtils.TimedMessage(textMeshUI, "Could not find a Class variable named 'age'!", ref timer, color: ExerciseUtils.COLOR_WARNING);
                ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.INCORRECT, ref timer);
                return;
            }

            ExerciseUtils.TimedMessage(textMeshUI, "Found a Class variable named age...", ref timer);
            ExerciseUtils.TimedMessage(textMeshUI, "It is correctly accessible by any function...", ref timer);


            ExerciseUtils.TimedMessage(textMeshUI, "\n" + ExerciseUtils.SUCCESS, ref timer);
            FunctionTimer.Create(ExerciseCompletionTester.ExerciseCompleted, timer);
        }

    }

}
