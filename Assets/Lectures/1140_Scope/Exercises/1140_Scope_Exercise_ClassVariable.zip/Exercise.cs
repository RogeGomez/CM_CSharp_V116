using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* COMPILATION BLOCKER
namespace CodeMonkey.CSharpCourse.L1140_Scope {


    public class Exercise : MonoBehaviour {


        // Define a class variable to fix the error where 2 functions are trying to access it.
        // There's a detailed lecture on Classes later on in the course.


        private void Test() {
            age++;
        }

        private void PrintAge() {
            Debug.Log(age);
        }




    }

}
COMPILATION BLOCKER */